/* Canvas mockups (issue #606, round 9): live prototypes for a Coddy canvas.
 *
 * Each page sets <body data-page data-slide data-width> and loads this file.
 * The Files window, the board, its cards, edges, frames, mode switch, zoom
 * controls, prompt bar, menus and the question card are the markup of the
 * running web UI (FRAGS) over Coddy's own stylesheet (coddy.css); what #606
 * proposes (editing, Draw, sketches, Ask Coddy, link pulls) is drawn on the
 * same classes where Coddy has them (the markup window's toolbar, the
 * canvas's popover, the app's menu). Nothing here talks to a server: writes,
 * answers and files are scripted. */
(() => {
  "use strict";

  const FRAGS = {"root1280":"<div class=\"shell\" style=\"--rail-shell-track-width: 84px;\"><aside class=\"rail-column \" aria-label=\"Nav\"><div class=\"rail-pill \"><div class=\"rail-tip-host rail-brand-tip-host\"><a href=\"#/\" class=\"rail-brand\" aria-label=\"Coddy agent home\" data-testid=\"nav-home\"><span class=\"rail-brand-text\"><span class=\"rail-brand-title\">Coddy</span><span class=\"rail-brand-sub\">agent</span></span></a><span class=\"rail-tip\" role=\"tooltip\">New Chat</span></div><div class=\"rail-middle\"><div class=\"rail-tip-host\"><a href=\"#/history\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"History\" aria-pressed=\"false\" data-testid=\"nav-history\"><span class=\"rail-nav-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" aria-hidden=\"true\"><path d=\"M4 19.5A2.5 2.5 0 016.5 17H20\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M8 7h8M8 11h6\" stroke-linecap=\"round\"></path></svg></span></a><span class=\"rail-tip\" role=\"tooltip\">History</span></div><div class=\"rail-spacer rail-spacer-between\" aria-hidden=\"true\"></div><div class=\"rail-tip-host\"><a href=\"#/docs\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"Docs\" aria-pressed=\"false\" data-testid=\"nav-docs\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"9\"></circle><path d=\"M9.6 9.3a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.6\"></path><path d=\"M12 17.2h.01\"></path></svg></a><span class=\"rail-tip\" role=\"tooltip\">Docs</span></div><div class=\"rail-tip-host\"><a href=\"#/settings\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"Settings\" aria-pressed=\"false\" data-testid=\"nav-settings\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z\"></path><path d=\"M15 12a3 3 0 11-6 0 3 3 0 016 0z\"></path></svg></a><span class=\"rail-tip\" role=\"tooltip\">Settings</span></div><div class=\"rail-tip-host rail-env-host\"><button type=\"button\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow rail-env-btn \" aria-label=\"Environment: demo-host\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-testid=\"nav-environment\" data-env=\"local\" data-state=\"local\"><span class=\"rail-env-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><rect x=\"4.5\" y=\"5\" width=\"15\" height=\"10.5\" rx=\"1.5\"></rect><path d=\"M2.5 19h19\"></path></svg><span class=\"env-status rail-env-status\" aria-hidden=\"true\" data-state=\"local\"></span></span></button><span class=\"rail-tip\" role=\"tooltip\">Environment: demo-host</span></div></div></div></aside><div class=\"shell-main\"><div class=\"backdrop is-open\" aria-hidden=\"false\"></div><div class=\"files-dock-cluster\" data-testid=\"files-view\" role=\"dialog\" aria-label=\"Files\"><div class=\"files-header\"><div class=\"files-title-block\"><button type=\"button\" class=\"files-icon-btn is-active\" data-testid=\"files-toggle-tree\" aria-pressed=\"true\" aria-label=\"Hide the file tree\" title=\"Hide the file tree\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M2.5 3.5h1M2.5 8h1M2.5 12.5h1M6 3.5h7.5M6 8h7.5M6 12.5h7.5\"></path></svg></button><div class=\"files-title-text\"><h2 class=\"files-title\">Files</h2><p class=\"files-subtitle\" title=\"Workspace /srv/workspace\">workspace</p></div></div><div class=\"files-actions\"><div class=\"files-more-host\"><button type=\"button\" class=\"files-icon-btn\" data-testid=\"files-more\" aria-label=\"More actions\" title=\"More actions\" aria-haspopup=\"menu\" aria-expanded=\"false\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><circle cx=\"8\" cy=\"3.25\" r=\"0.6\" fill=\"currentColor\"></circle><circle cx=\"8\" cy=\"8\" r=\"0.6\" fill=\"currentColor\"></circle><circle cx=\"8\" cy=\"12.75\" r=\"0.6\" fill=\"currentColor\"></circle></svg></button></div><button type=\"button\" class=\"files-icon-btn\" data-testid=\"files-expand\" aria-pressed=\"false\" aria-label=\"Expand the window\" title=\"Expand the window\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M9.5 2.5h4v4M13.5 2.5 9 7M6.5 13.5h-4v-4M2.5 13.5 7 9\"></path></svg></button><button type=\"button\" class=\"sessions-close files-close\" data-testid=\"files-close\" aria-label=\"Close files\">×</button></div></div><div class=\"files-layout has-tree has-file\"><aside class=\"files-sidebar\"><div class=\"files-filter\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" class=\"files-filter-icon\"><circle cx=\"7\" cy=\"7\" r=\"4.25\"></circle><path d=\"m10.25 10.25 3.25 3.25\"></path></svg><input placeholder=\"Filter files\" aria-label=\"Filter files\" autocomplete=\"off\" spellcheck=\"false\" type=\"search\" value=\"\" style=\"\"></div><div class=\"files-tree\" data-testid=\"files-tree\"><ul class=\"files-tree-level\" role=\"tree\"><li role=\"none\"><button type=\"button\" role=\"treeitem\" aria-expanded=\"false\" aria-selected=\"false\" class=\"files-tree-row\" title=\"archive\" style=\"padding-left: 10px;\"><span class=\"files-tree-glyph\" aria-hidden=\"true\"><span class=\"coddy-chevron\" aria-hidden=\"true\"><svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg></span></span><span class=\"files-tree-name\">archive</span></button></li><li role=\"none\"><button type=\"button\" role=\"treeitem\" aria-expanded=\"false\" aria-selected=\"false\" class=\"files-tree-row\" title=\"canvas\" style=\"padding-left: 10px;\"><span class=\"files-tree-glyph\" aria-hidden=\"true\"><span class=\"coddy-chevron\" aria-hidden=\"true\"><svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg></span></span><span class=\"files-tree-name\">canvas</span></button></li><li role=\"none\"><button type=\"button\" role=\"treeitem\" aria-expanded=\"false\" aria-selected=\"false\" class=\"files-tree-row\" title=\"design\" style=\"padding-left: 10px;\"><span class=\"files-tree-glyph\" aria-hidden=\"true\"><span class=\"coddy-chevron\" aria-hidden=\"true\"><svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg></span></span><span class=\"files-tree-name\">design</span></button></li><li role=\"none\"><button type=\"button\" role=\"treeitem\" aria-expanded=\"false\" aria-selected=\"false\" class=\"files-tree-row\" title=\"notes\" style=\"padding-left: 10px;\"><span class=\"files-tree-glyph\" aria-hidden=\"true\"><span class=\"coddy-chevron\" aria-hidden=\"true\"><svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg></span></span><span class=\"files-tree-name\">notes</span></button></li><li role=\"none\"><button type=\"button\" role=\"treeitem\" aria-expanded=\"false\" aria-selected=\"false\" class=\"files-tree-row\" title=\"site\" style=\"padding-left: 10px;\"><span class=\"files-tree-glyph\" aria-hidden=\"true\"><span class=\"coddy-chevron\" aria-hidden=\"true\"><svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg></span></span><span class=\"files-tree-name\">site</span></button></li></ul></div></aside><section class=\"files-main\" aria-label=\"Open files\"><div class=\"files-tabs-bar\"><div class=\"files-tabs\" role=\"tablist\" aria-label=\"Open files\"><div class=\"files-tab is-active\" title=\"canvas/shop.canvas\"><button type=\"button\" role=\"tab\" aria-selected=\"true\" class=\"files-tab-name\">shop.canvas</button><button type=\"button\" class=\"files-tab-close\" aria-label=\"Close shop.canvas\">×</button></div></div></div><!--PANE--></section></div></div><main class=\"main is-empty\"><div class=\"hero\" id=\"hero\"><h1 class=\"hero-title\"><span class=\"hero-title-muted\">What do you want to <span class=\"hero-title-accent\" data-testid=\"hero-title-accent\">debug</span>?</span></h1><div class=\"hero-composer\"><footer class=\"composer-wrap\"><label class=\"sr-only\" for=\"composer\">Message</label><div class=\"workspace-bar workspace-bar--pick\" role=\"group\" aria-label=\"Where this chat works\" data-testid=\"workspace-bar\"><div class=\"workspace-bar-picks\"><button type=\"button\" class=\"workspace-bar-item workspace-bar-repo workspace-bar-pick\" data-testid=\"composer-workspace-chip\" title=\"/srv/workspace\" aria-haspopup=\"menu\" aria-expanded=\"false\"><svg class=\"workspace-bar-icon\" viewBox=\"0 0 16 16\" width=\"14\" height=\"14\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.3\" aria-hidden=\"true\"><path d=\"M1.75 3.25h4.1l1.5 1.5h6.9c.28 0 .5.22.5.5v7.5c0 .28-.22.5-.5.5H1.75a.5.5 0 0 1-.5-.5v-9c0-.28.22-.5.5-.5Z\" stroke-linejoin=\"round\"></path></svg><span class=\"workspace-bar-text\">ws</span></button></div></div><div class=\"composer-card composer-card--joined\"><div class=\"composer-field-wrap\"><button type=\"button\" class=\"composer-enhance-btn\" aria-label=\"Improve prompt\" title=\"Improve prompt\" data-testid=\"composer-enhance-btn\" disabled=\"\"><svg class=\"composer-enhance-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\" width=\"12\" height=\"12\" aria-hidden=\"true\"><path d=\"M9.5 1l.7 1.8L12 3.5l-1.8.7L9.5 6l-.7-1.8L7 3.5l1.8-.7L9.5 1zM3.2 5.6l.5 1.2 1.2.5-1.2.5-.5 1.2-.5-1.2L1.5 7.3l1.2-.5.5-1.2zM8.9 6.6a1 1 0 011.5 0l.9.9a1 1 0 010 1.5l-5.3 5.3a1 1 0 01-1.5 0l-.9-.9a1 1 0 010-1.5l5.3-5.3zm.8 1.5l-4.6 4.6.5.5 4.6-4.6-.5-.5z\"></path></svg></button><div class=\"composer-stack\"><textarea id=\"composer\" rows=\"5\" enterkeyhint=\"send\" placeholder=\"Plan, Build, / for skills, @ for files\" autocomplete=\"off\" style=\"height: 132px;\"></textarea></div></div><div class=\"composer-bar\"><div class=\"composer-tabs\" aria-label=\"Composer options\"><input multiple=\"\" class=\"sr-only\" aria-hidden=\"true\" tabindex=\"-1\" data-testid=\"composer-file-input\" type=\"file\" style=\"\"><button type=\"button\" class=\"composer-tab composer-attach-btn\" aria-label=\"Attach file\" title=\"Attach file\" data-testid=\"composer-attach-btn\"><svg viewBox=\"0 0 16 16\" width=\"14\" height=\"14\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M13.5 7.5l-6 6A4 4 0 012 8l7-7a2.5 2.5 0 013.5 3.5l-6 6A1 1 0 015 9l5-5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></button><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-agent\" aria-label=\"Mode\" title=\"Mode\" aria-haspopup=\"menu\" aria-expanded=\"false\">Agent</button></div><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-llm\" aria-label=\"Model\" title=\"YAML backend (metadata.model)\" aria-haspopup=\"menu\" aria-expanded=\"false\">demo</button></div><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-permission perm-ask\" aria-label=\"Permissions\" title=\"When tools ask for approval in this session (new sessions start in: Ask first)\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-testid=\"composer-permission\">Ask first</button></div></div><div class=\"composer-bar-actions\"><div class=\"composer-context-tip-host\" tabindex=\"0\" aria-label=\"Context usage\" aria-expanded=\"false\" data-testid=\"composer-context-ring-host\"><div class=\"context-ring\" role=\"img\" aria-hidden=\"true\"><svg viewBox=\"0 0 28 28\" width=\"30\" height=\"30\" aria-hidden=\"true\"><circle class=\"context-ring-inner\" cx=\"14\" cy=\"14\" r=\"7\"></circle></svg></div><span class=\"rail-tip composer-context-tip\" role=\"tooltip\">0.0% context used\nMax context 128000</span></div><button type=\"button\" class=\"composer-icon composer-run-icon composer-send-play composer-run-icon--play\" id=\"btn-send\" aria-label=\"Send\" disabled=\"\"><span class=\"composer-send-glyph\" aria-hidden=\"true\"><svg viewBox=\"0 0 12 12\" fill=\"currentColor\" width=\"17\" height=\"17\"><path d=\"M2 0L11 6L2 12Z\"></path></svg></span></button></div></div></div></footer></div><div class=\"hero-footer\"><a href=\"https://github.com/coddy-project/coddy-agent\" target=\"_blank\" rel=\"noopener\">GitHub</a><span class=\"hero-footer-sep\" aria-hidden=\"true\">|</span><a href=\"/docs/\" target=\"_blank\" rel=\"noopener\">API docs</a><span class=\"hero-footer-sep\" aria-hidden=\"true\">|</span><span class=\"hero-footer-version\">dev</span></div></div></main></div></div>","root390":"<div class=\"shell\" style=\"--rail-shell-track-width: 390px;\"><aside class=\"rail-column \" aria-label=\"Nav\"><div class=\"rail-pill \"><div class=\"rail-tip-host rail-brand-tip-host\"><a href=\"#/\" class=\"rail-brand\" aria-label=\"Coddy agent home\" data-testid=\"nav-home\"><span class=\"rail-brand-text\"><span class=\"rail-brand-title\">Coddy</span><span class=\"rail-brand-sub\">agent</span></span></a><span class=\"rail-tip\" role=\"tooltip\">New Chat</span></div><div class=\"rail-middle\"><div class=\"rail-tip-host\"><a href=\"#/history\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"History, 1 active session\" aria-pressed=\"false\" data-testid=\"nav-history\"><span class=\"rail-nav-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" aria-hidden=\"true\"><path d=\"M4 19.5A2.5 2.5 0 016.5 17H20\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M8 7h8M8 11h6\" stroke-linecap=\"round\"></path></svg></span></a><span class=\"rail-tip\" role=\"tooltip\">History</span></div><div class=\"rail-spacer rail-spacer-between\" aria-hidden=\"true\"></div><div class=\"rail-tip-host\"><a href=\"#/docs\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"Docs\" aria-pressed=\"false\" data-testid=\"nav-docs\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"9\"></circle><path d=\"M9.6 9.3a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.6\"></path><path d=\"M12 17.2h.01\"></path></svg></a><span class=\"rail-tip\" role=\"tooltip\">Docs</span></div><div class=\"rail-tip-host\"><a href=\"#/settings\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"Settings\" aria-pressed=\"false\" data-testid=\"nav-settings\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z\"></path><path d=\"M15 12a3 3 0 11-6 0 3 3 0 016 0z\"></path></svg></a><span class=\"rail-tip\" role=\"tooltip\">Settings</span></div><div class=\"rail-tip-host rail-env-host\"><button type=\"button\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow rail-env-btn \" aria-label=\"Environment: demo-host\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-testid=\"nav-environment\" data-env=\"local\" data-state=\"local\"><span class=\"rail-env-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><rect x=\"4.5\" y=\"5\" width=\"15\" height=\"10.5\" rx=\"1.5\"></rect><path d=\"M2.5 19h19\"></path></svg><span class=\"env-status rail-env-status\" aria-hidden=\"true\" data-state=\"local\"></span></span></button><span class=\"rail-tip\" role=\"tooltip\">Environment: demo-host</span></div></div></div></aside><div class=\"shell-main\"><div class=\"backdrop is-open\" aria-hidden=\"false\"></div><div class=\"files-dock-cluster\" data-testid=\"files-view\" role=\"dialog\" aria-label=\"Files\"><div class=\"files-header\"><div class=\"files-title-block\"><button type=\"button\" class=\"files-icon-btn\" data-testid=\"files-toggle-tree\" aria-pressed=\"false\" aria-label=\"Show the file tree\" title=\"Show the file tree\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M2.5 3.5h1M2.5 8h1M2.5 12.5h1M6 3.5h7.5M6 8h7.5M6 12.5h7.5\"></path></svg></button><div class=\"files-title-text\"><h2 class=\"files-title\">Files</h2><p class=\"files-subtitle\" title=\"Workspace /srv/workspace\">workspace</p></div></div><div class=\"files-actions\"><div class=\"files-more-host\"><button type=\"button\" class=\"files-icon-btn\" data-testid=\"files-more\" aria-label=\"More actions\" title=\"More actions\" aria-haspopup=\"menu\" aria-expanded=\"false\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><circle cx=\"8\" cy=\"3.25\" r=\"0.6\" fill=\"currentColor\"></circle><circle cx=\"8\" cy=\"8\" r=\"0.6\" fill=\"currentColor\"></circle><circle cx=\"8\" cy=\"12.75\" r=\"0.6\" fill=\"currentColor\"></circle></svg></button></div><button type=\"button\" class=\"files-icon-btn\" data-testid=\"files-expand\" aria-pressed=\"false\" aria-label=\"Expand the window\" title=\"Expand the window\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M9.5 2.5h4v4M13.5 2.5 9 7M6.5 13.5h-4v-4M2.5 13.5 7 9\"></path></svg></button><button type=\"button\" class=\"sessions-close files-close\" data-testid=\"files-close\" aria-label=\"Close files\">×</button></div></div><div class=\"files-layout has-file\"><section class=\"files-main\" aria-label=\"Open files\"><div class=\"files-tabs-bar\"><div class=\"files-tabs\" role=\"tablist\" aria-label=\"Open files\"><div class=\"files-tab is-active\" title=\"canvas/shop.canvas\"><button type=\"button\" role=\"tab\" aria-selected=\"true\" class=\"files-tab-name\">shop.canvas</button><button type=\"button\" class=\"files-tab-close\" aria-label=\"Close shop.canvas\">×</button></div></div></div><!--PANE--></section></div></div><main class=\"main\"><div class=\"chat-stack\" style=\"--chat-composer-reserve: 161px;\"><div class=\"chat-scroll\" id=\"messages\" aria-live=\"polite\"><div class=\"chat-scroll-sticky-head\" style=\"\"><div class=\"chat-title-column\"><header class=\"chat-header\"><div class=\"chat-title\" id=\"chat-title\"><button type=\"button\" class=\"chat-title-btn is-editable\" aria-label=\"Chat title\">On the canvas, `site/index.html` (640x400):\n\nElement `body &gt; main &gt; h1`:\n\n```html\n&lt;h1&gt;Welcome to the shop&lt;/h1&gt;\n```\n\nMake...</button></div><div class=\"chat-views\" role=\"toolbar\" aria-label=\"Views of this chat\" data-testid=\"chat-views\"><span class=\"chat-view-tip-host\"><button type=\"button\" class=\"chat-view-btn chat-view-btn--icon is-active\" data-testid=\"chat-views-files\" aria-pressed=\"true\" aria-label=\"Workspace files (Ctrl+Shift+F)\"><span class=\"chat-view-face\"><svg class=\"chat-view-icon\" width=\"18\" height=\"18\" viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M1.75 4.25c0-.83.67-1.5 1.5-1.5h3l1.5 1.75h5c.83 0 1.5.67 1.5 1.5v6.25c0 .83-.67 1.5-1.5 1.5h-9.5c-.83 0-1.5-.67-1.5-1.5z\"></path></svg></span></button><span class=\"chat-view-tip\" role=\"tooltip\">Workspace files (Ctrl+Shift+F)</span></span><span class=\"chat-view-tip-host\"><button type=\"button\" class=\"chat-view-btn chat-view-btn--tasks\" data-testid=\"chat-views-tasks\" aria-pressed=\"false\" aria-label=\"Background tasks: none yet\"><span class=\"chat-view-face\"><span class=\"bgtask-dot bgtask-dot--muted\" aria-hidden=\"true\"></span><span class=\"chat-view-label\" aria-hidden=\"true\">Tasks</span></span></button><span class=\"chat-view-tip\" role=\"tooltip\">Background tasks: none yet</span></span></div></header></div></div><div class=\"messages-inner\"><div class=\"msg-user-stack\" data-row-id=\"u_1\"><div class=\"msg msg-user\"><div class=\"msg-user-body\" data-testid=\"user-message-body\"><span><span><span>On the canvas, `site/index.html` (640x400):\n\nElement `body &gt; main &gt; h1`:\n\n```html\n&lt;h1&gt;Welcome to the shop&lt;/h1&gt;\n```\n\nMake the headline larger\n\nthe login form for the shop</span></span></span></div></div><div class=\"msg-user-foot\"><button type=\"button\" class=\"msg-copy-icon-btn\" aria-label=\"Copy message\" data-testid=\"user-message-copy\" title=\"Copy message\"><svg class=\"msg-copy-icon-btn__glyph\" width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><path fill=\"currentColor\" d=\"M4 2.5A1.5 1.5 0 015.5 1h6A1.5 1.5 0 0113 2.5v8a1.5 1.5 0 01-1.5 1.5H10v.5A1.5 1.5 0 018.5 14h-6A1.5 1.5 0 011 12.5v-8A1.5 1.5 0 012.5 3H4v-.5zm1 0V3h4A1.5 1.5 0 0110.5 4.5v7H11v-8h-6v-.5zM2.5 4a.5.5 0 00-.5.5v8a.5.5 0 00.5.5h6a.5.5 0 00.5-.5v-8a.5.5 0 00-.5-.5h-6z\"></path></svg></button><button type=\"button\" class=\"msg-copy-icon-btn msg-user-edit\" aria-label=\"Edit message\" title=\"Edit message\" data-testid=\"user-message-edit\"><svg class=\"msg-copy-icon-btn__glyph\" width=\"16\" height=\"16\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M3 12a9 9 0 1 0 9-9c-2.5 0-4.9 1-6.7 2.8L3 8\"></path><path d=\"M3 3v5h5\"></path></svg></button><time class=\"msg-user-time\" datetime=\"2026-10-29T22:07:38Z\" title=\"Thu, Oct 29, 2026, 11:07:38 PM GMT+01:00\">11:07 PM</time></div></div><div class=\"thinking-row coddy-tool-call-row\" data-kind=\"other\" data-status=\"in_progress\" data-row-id=\"tc_call_question_1\"><details class=\"thinking-details coddy-tool-details\" data-testid=\"tool-details-call_question_1\"><summary class=\"thinking-summary\" aria-label=\"Tool summary\"><span class=\"thinking-left\"><span class=\"coddy-chevron thinking-chevron\" aria-hidden=\"true\"><svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg></span><span class=\"thinking-head\"><span class=\"thinking-label\">asking</span></span></span></summary><div class=\"thinking-body coddy-tool-call-body coddy-tool-call-body--question\" aria-label=\"Tool call details\"><div class=\"question-prompt-resolved-body\" aria-label=\"Question tool timeline\"><div><div class=\"question-prompt-resolved-q\">I read a sign-in form: a title, email and password fields and a Sign in button. What should it become?</div><ul class=\"question-tool-offer\"><li class=\"question-tool-offer-row\"><span class=\"question-prompt-bubble\" aria-hidden=\"true\">A</span><span class=\"question-tool-offer-text\">A live page<span class=\"muted\"> - fits a screen best</span></span></li><li class=\"question-tool-offer-row\"><span class=\"question-prompt-bubble\" aria-hidden=\"true\">B</span><span class=\"question-tool-offer-text\">A Mermaid diagram<span class=\"muted\"> - one card</span></span></li><li class=\"question-tool-offer-row\"><span class=\"question-prompt-bubble\" aria-hidden=\"true\">C</span><span class=\"question-tool-offer-text\">A diagram of nodes<span class=\"muted\"> - boxes you can move</span></span></li><li class=\"question-tool-offer-row\"><span class=\"question-prompt-bubble\" aria-hidden=\"true\">D</span><span class=\"question-tool-offer-text\">A tidy picture<span class=\"muted\"> - an SVG file</span></span></li><li class=\"question-tool-offer-row\"><span class=\"question-prompt-bubble\" aria-hidden=\"true\">E</span><span class=\"question-tool-offer-text muted\">an answer of their own</span></li></ul><div class=\"question-prompt-resolved-a muted\">Awaiting answer</div></div></div></div></details></div><div class=\"message-row message-row-question\" data-row-id=\"qp_q_1793311658878046404\"><section class=\"question-prompt-frame\" data-test=\"question_prompt_section\"><div class=\"question-prompt-card\"><div class=\"question-prompt-head\"><div class=\"question-prompt-head-left\"><span class=\"question-prompt-icon\" aria-hidden=\"true\"></span><h3 class=\"question-prompt-title\">Questions</h3></div></div><div class=\"question-prompt-body\"><div><div class=\"question-prompt-qline\"><p class=\"question-prompt-qtext\">I read a sign-in form: a title, email and password fields and a Sign in button. What should it become?</p></div><ul class=\"question-prompt-rows\" aria-label=\"Options 1\"><li class=\"question-prompt-li\"><label class=\"question-prompt-row\"><input class=\"sr-only\" type=\"radio\" name=\"qp_q_1793311658878046404-pick-0\" style=\"\"><span class=\"question-prompt-bubble\">A</span><span class=\"question-prompt-row-text\">A live page<span class=\"muted\"> - fits a screen best</span></span></label></li><li class=\"question-prompt-li\"><label class=\"question-prompt-row\"><input class=\"sr-only\" type=\"radio\" name=\"qp_q_1793311658878046404-pick-0\" style=\"\"><span class=\"question-prompt-bubble\">B</span><span class=\"question-prompt-row-text\">A Mermaid diagram<span class=\"muted\"> - one card</span></span></label></li><li class=\"question-prompt-li\"><label class=\"question-prompt-row\"><input class=\"sr-only\" type=\"radio\" name=\"qp_q_1793311658878046404-pick-0\" style=\"\"><span class=\"question-prompt-bubble\">C</span><span class=\"question-prompt-row-text\">A diagram of nodes<span class=\"muted\"> - boxes you can move</span></span></label></li><li class=\"question-prompt-li\"><label class=\"question-prompt-row\"><input class=\"sr-only\" type=\"radio\" name=\"qp_q_1793311658878046404-pick-0\" style=\"\"><span class=\"question-prompt-bubble\">D</span><span class=\"question-prompt-row-text\">A tidy picture<span class=\"muted\"> - an SVG file</span></span></label></li><li class=\"question-prompt-li\"><label class=\"question-prompt-row question-prompt-row--other\"><input class=\"sr-only\" type=\"radio\" name=\"qp_q_1793311658878046404-pick-0\" style=\"\"><span class=\"question-prompt-bubble\">E</span><input class=\"question-prompt-other-input\" autocomplete=\"off\" spellcheck=\"false\" placeholder=\"Other…\" aria-label=\"Other, type your answer\" data-testid=\"question-other-0\" type=\"text\" value=\"\" style=\"\"></label></li></ul></div></div><div class=\"question-prompt-foot\"><button type=\"button\" class=\"question-prompt-skip\" data-testid=\"question-skip\">Skip<span class=\"question-prompt-kbd\">Esc</span></button><button type=\"button\" class=\"question-prompt-continue\" disabled=\"\" data-testid=\"question-submit\">Continue<span class=\"question-prompt-continue-ic\" aria-hidden=\"true\">↵</span></button></div></div></section></div><div class=\"msg-assistant-stack\" data-testid=\"typing-dots\"><div class=\"typing-dots\"><span class=\"typing-dots-dot\" aria-hidden=\"true\"></span><span class=\"typing-dots-dot\" aria-hidden=\"true\"></span><span class=\"typing-dots-dot\" aria-hidden=\"true\"></span><span class=\"typing-dots-status\" data-testid=\"typing-dots-status\"><span class=\"typing-dots-turn\"><span class=\"typing-dots-turn-item typing-dots-turn-time\" data-testid=\"typing-dots-turn-elapsed\" aria-hidden=\"true\">6s</span><span class=\"typing-dots-turn-item\" data-testid=\"typing-dots-turn-tokens\" aria-hidden=\"true\">80 tokens</span></span><span class=\"typing-dots-status-text\" role=\"status\" aria-live=\"polite\" aria-atomic=\"true\"><span class=\"typing-dots-status-verb\">Waiting for your answer</span></span></span></div></div></div><div class=\"chat-scroll-tail\" aria-hidden=\"true\"></div></div><div class=\"chat-bottom\"><div class=\"chat-bottom-inner\"><button type=\"button\" class=\"chat-scroll-bottom\" data-testid=\"chat-scroll-bottom\" data-visible=\"false\" aria-label=\"Scroll to the latest message\" aria-hidden=\"true\" inert=\"\" tabindex=\"-1\" title=\"Scroll to the latest message\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><path d=\"M8 3v9m0 0 4-4m-4 4-4-4\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></button><button type=\"button\" class=\"chat-expand-composer\" data-testid=\"composer-expand\" aria-pressed=\"false\" aria-label=\"Expand the message field\" title=\"Expand the message field\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><path d=\"M9.5 2.5h4v4M6.5 13.5h-4v-4M13.5 2.5l-4 4M2.5 13.5l4-4\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></button><footer class=\"composer-wrap composer-wrap-docked\"><label class=\"sr-only\" for=\"composer\">Message</label><div class=\"composer-card\"><div class=\"composer-field-wrap\"><button type=\"button\" class=\"composer-enhance-btn\" aria-label=\"Improve prompt\" title=\"Improve prompt\" data-testid=\"composer-enhance-btn\" disabled=\"\"><svg class=\"composer-enhance-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\" width=\"12\" height=\"12\" aria-hidden=\"true\"><path d=\"M9.5 1l.7 1.8L12 3.5l-1.8.7L9.5 6l-.7-1.8L7 3.5l1.8-.7L9.5 1zM3.2 5.6l.5 1.2 1.2.5-1.2.5-.5 1.2-.5-1.2L1.5 7.3l1.2-.5.5-1.2zM8.9 6.6a1 1 0 011.5 0l.9.9a1 1 0 010 1.5l-5.3 5.3a1 1 0 01-1.5 0l-.9-.9a1 1 0 010-1.5l5.3-5.3zm.8 1.5l-4.6 4.6.5.5 4.6-4.6-.5-.5z\"></path></svg></button><div class=\"composer-stack\"><textarea id=\"composer\" rows=\"2\" enterkeyhint=\"enter\" placeholder=\"Add a follow-up for the running turn\" autocomplete=\"off\" style=\"height: 76px;\"></textarea></div></div><div class=\"composer-bar\"><div class=\"composer-tabs\" aria-label=\"Composer options\"><input multiple=\"\" class=\"sr-only\" aria-hidden=\"true\" tabindex=\"-1\" data-testid=\"composer-file-input\" type=\"file\" style=\"\"><button type=\"button\" class=\"composer-tab composer-attach-btn\" aria-label=\"Attach file\" title=\"Attach file\" data-testid=\"composer-attach-btn\"><svg viewBox=\"0 0 16 16\" width=\"14\" height=\"14\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M13.5 7.5l-6 6A4 4 0 012 8l7-7a2.5 2.5 0 013.5 3.5l-6 6A1 1 0 015 9l5-5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></button><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-agent\" aria-label=\"Mode\" title=\"Mode\" aria-haspopup=\"menu\" aria-expanded=\"false\">Agent</button></div><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-llm\" aria-label=\"Model\" title=\"YAML backend (metadata.model)\" aria-haspopup=\"menu\" aria-expanded=\"false\">demo</button></div><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-permission perm-ask\" aria-label=\"Permissions\" title=\"When tools ask for approval in this session (new sessions start in: Ask first)\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-testid=\"composer-permission\">Ask first</button></div></div><div class=\"composer-bar-actions\"><div class=\"composer-context-tip-host\" tabindex=\"0\" aria-label=\"Context usage\" aria-expanded=\"false\" data-testid=\"composer-context-ring-host\"><div class=\"context-ring\" role=\"img\" aria-hidden=\"true\"><svg viewBox=\"0 0 28 28\" width=\"30\" height=\"30\" aria-hidden=\"true\"><circle class=\"context-ring-inner\" cx=\"14\" cy=\"14\" r=\"7\"></circle><circle class=\"context-ring-fg\" cx=\"14\" cy=\"14\" r=\"12\" stroke-dasharray=\"75.39822368615503\" stroke-dashoffset=\"63.1872457407332\"></circle></svg></div><span class=\"rail-tip composer-context-tip\" role=\"tooltip\">16.2% context used\nInput 1200\nOutput 80\nTotal 1280\nMax context 128000</span></div><button type=\"button\" class=\"composer-icon composer-run-icon composer-send-stop composer-run-icon--stop\" id=\"btn-send\" aria-label=\"Stop generation\"><span class=\"composer-send-glyph\" aria-hidden=\"true\"><span class=\"composer-stop-square\"></span></span></button></div></div></div></footer></div></div></div></main></div></div>","zoom":"<div class=\"zoom-controls\" role=\"group\" aria-label=\"Zoom\" data-testid=\"canvas-zoom\"><button type=\"button\" class=\"zoom-control\" data-testid=\"canvas-zoom-out\" aria-label=\"Zoom out (-)\" title=\"Zoom out (-)\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M6 12h12\"></path></svg></button><button type=\"button\" class=\"zoom-control zoom-control--level\" data-testid=\"canvas-fit\" aria-label=\"Fit everything on the canvas (0)\" title=\"Fit everything on the canvas (0)\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M4 9V5a1 1 0 0 1 1-1h4\"></path><path d=\"M15 4h4a1 1 0 0 1 1 1v4\"></path><path d=\"M20 15v4a1 1 0 0 1-1 1h-4\"></path><path d=\"M9 20H5a1 1 0 0 1-1-1v-4\"></path></svg></button><button type=\"button\" class=\"zoom-control\" data-testid=\"canvas-zoom-in\" aria-label=\"Zoom in (+)\" title=\"Zoom in (+)\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M12 6v12M6 12h12\"></path></svg></button></div>","popover":"<div class=\"canvas-popover\" data-testid=\"canvas-popover\" role=\"dialog\" aria-label=\"Comment on an element\"><p class=\"canvas-popover-target\"><code>h1</code></p><textarea class=\"canvas-popover-note\" data-testid=\"canvas-popover-note\" rows=\"2\" placeholder=\"What should change here?\"></textarea><div class=\"canvas-popover-actions\"><button type=\"button\" class=\"canvas-popover-cancel\">Cancel</button><button type=\"button\" class=\"canvas-popover-add\" data-testid=\"canvas-popover-add\">Add</button></div></div>","sendButton":"<button type=\"button\" class=\"canvas-bar-send\" data-testid=\"canvas-send\" disabled=\"\" aria-label=\"Send\" title=\"Send\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" aria-hidden=\"true\"><path d=\"M5 3.5v9l7-4.5z\" fill=\"currentColor\"></path></svg></button>","stopButton":"<button type=\"button\" class=\"canvas-bar-send composer-run-icon composer-run-icon--stop composer-send-stop\" data-testid=\"canvas-stop\" aria-label=\"Stop\" title=\"Stop\"><span class=\"composer-send-glyph\" aria-hidden=\"true\"><span class=\"composer-stop-square\"></span></span></button>","frameActions":"<span class=\"canvas-frame-menu-host\"><button type=\"button\" class=\"canvas-frame-btn\" aria-label=\"Size\" title=\"Size\" aria-haspopup=\"menu\" aria-expanded=\"false\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" aria-hidden=\"true\"><rect x=\"1.5\" y=\"3\" width=\"9\" height=\"7\" rx=\"1\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\"></rect><rect x=\"11\" y=\"5.5\" width=\"3.5\" height=\"7\" rx=\"0.8\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.4\"></rect><path d=\"M4 12.5h4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path></svg></button></span><button type=\"button\" class=\"canvas-frame-btn\" data-testid=\"canvas-frame-reload\" aria-label=\"Reload\" title=\"Reload\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" aria-hidden=\"true\"><path d=\"M13 8a5 5 0 1 1-1.46-3.54M13 2.5V5h-2.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></button><button type=\"button\" class=\"canvas-frame-btn\" data-testid=\"canvas-frame-remove\" aria-label=\"Remove from canvas\" title=\"Remove from canvas\">×</button>","mermaid":{"mermaid":"<div class=\"md\"><figure class=\"md-figure\" data-testid=\"md-figure\" data-kind=\"mermaid\" data-view=\"picture\"><div class=\"md-figure-head\"><span class=\"md-figure-label\">Mermaid diagram</span><div class=\"md-figure-actions\"><button type=\"button\" class=\"md-copy md-figure-format\" title=\"Download the source (.mmd)\" aria-label=\"Download the source (.mmd)\" data-testid=\"md-figure-download-mmd\"><span aria-hidden=\"true\">MMD</span></button><button type=\"button\" class=\"md-copy md-figure-format\" title=\"Download as SVG (.svg)\" aria-label=\"Download as SVG (.svg)\" data-testid=\"md-figure-download-svg\"><span aria-hidden=\"true\">SVG</span></button><button type=\"button\" class=\"md-copy md-figure-source-toggle\" aria-pressed=\"false\" title=\"Show the source code\" aria-label=\"Show the source code\" data-testid=\"md-figure-source-toggle\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" class=\"md-copy__glyph\"><path d=\"M5.5 4L1.5 8l4 4M10.5 4l4 4-4 4\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></button></div></div><button type=\"button\" class=\"md-figure-picture\" aria-label=\"Open the picture\" title=\"Open the picture\"><img alt=\"Mermaid diagram\" width=\"360\" height=\"402\" data-testid=\"md-figure-img\" src=\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20id%3D%22coddy-mermaid-1%22%20width%3D%22360%22%20class%3D%22flowchart%22%20viewBox%3D%224%204%20360%20402%22%20role%3D%22graphics-document%20document%22%20aria-roledescription%3D%22flowchart-v2%22%20height%3D%22402%22%3E%3Cstyle%3E%23coddy-mermaid-1%7Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bfont-size%3A14px%3Bfill%3A%23ffffff%3B%7D%40keyframes%20edge-animation-frame%7Bfrom%7Bstroke-dashoffset%3A0%3B%7D%7D%40keyframes%20dash%7Bto%7Bstroke-dashoffset%3A0%3B%7D%7D%23coddy-mermaid-1%20.edge-animation-slow%7Bstroke-dasharray%3A9%2C5!important%3Bstroke-dashoffset%3A900%3Banimation%3Adash%2050s%20linear%20infinite%3Bstroke-linecap%3Around%3B%7D%23coddy-mermaid-1%20.edge-animation-fast%7Bstroke-dasharray%3A9%2C5!important%3Bstroke-dashoffset%3A900%3Banimation%3Adash%2020s%20linear%20infinite%3Bstroke-linecap%3Around%3B%7D%23coddy-mermaid-1%20.error-icon%7Bfill%3A%2327303b%3B%7D%23coddy-mermaid-1%20.error-text%7Bfill%3A%23ffffff%3Bstroke%3A%23ffffff%3B%7D%23coddy-mermaid-1%20.edge-thickness-normal%7Bstroke-width%3A1px%3B%7D%23coddy-mermaid-1%20.edge-thickness-thick%7Bstroke-width%3A3.5px%3B%7D%23coddy-mermaid-1%20.edge-pattern-solid%7Bstroke-dasharray%3A0%3B%7D%23coddy-mermaid-1%20.edge-thickness-invisible%7Bstroke-width%3A0%3Bfill%3Anone%3B%7D%23coddy-mermaid-1%20.edge-pattern-dashed%7Bstroke-dasharray%3A3%3B%7D%23coddy-mermaid-1%20.edge-pattern-dotted%7Bstroke-dasharray%3A2%3B%7D%23coddy-mermaid-1%20.marker%7Bfill%3A%23b7b7b7%3Bstroke%3A%23b7b7b7%3B%7D%23coddy-mermaid-1%20.marker.cross%7Bstroke%3A%23b7b7b7%3B%7D%23coddy-mermaid-1%20svg%7Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bfont-size%3A14px%3B%7D%23coddy-mermaid-1%20p%7Bmargin%3A0%3B%7D%23coddy-mermaid-1%20.label%7Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-1%20.cluster-label%20text%7Bfill%3A%23ffffff%3B%7D%23coddy-mermaid-1%20.cluster-label%20span%7Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-1%20.cluster-label%20span%20p%7Bbackground-color%3Atransparent%3B%7D%23coddy-mermaid-1%20.label%20text%2C%23coddy-mermaid-1%20span%7Bfill%3A%23ffffff%3Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-1%20.node%20rect%2C%23coddy-mermaid-1%20.node%20circle%2C%23coddy-mermaid-1%20.node%20ellipse%2C%23coddy-mermaid-1%20.node%20polygon%2C%23coddy-mermaid-1%20.node%20path%7Bfill%3A%232c1740%3Bstroke%3A%239333ea%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-1%20.rough-node%20.label%20text%2C%23coddy-mermaid-1%20.node%20.label%20text%2C%23coddy-mermaid-1%20.image-shape%20.label%2C%23coddy-mermaid-1%20.icon-shape%20.label%7Btext-anchor%3Amiddle%3B%7D%23coddy-mermaid-1%20.node%20.katex%20path%7Bfill%3A%23000%3Bstroke%3A%23000%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-1%20.rough-node%20.label%2C%23coddy-mermaid-1%20.node%20.label%2C%23coddy-mermaid-1%20.image-shape%20.label%2C%23coddy-mermaid-1%20.icon-shape%20.label%7Btext-align%3Acenter%3B%7D%23coddy-mermaid-1%20.node.clickable%7Bcursor%3Apointer%3B%7D%23coddy-mermaid-1%20.root%20.anchor%20path%7Bfill%3A%23b7b7b7!important%3Bstroke-width%3A0%3Bstroke%3A%23b7b7b7%3B%7D%23coddy-mermaid-1%20.arrowheadPath%7Bfill%3A%23b7b7b7%3B%7D%23coddy-mermaid-1%20.edgePaths%20.path%7Bstroke%3A%23b7b7b7%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-1%20.flowchart-link%7Bstroke%3A%23b7b7b7%3Bfill%3Anone%3B%7D%23coddy-mermaid-1%20.edgeLabel%7Bbackground-color%3A%230f0f10%3Btext-align%3Acenter%3B%7D%23coddy-mermaid-1%20.edgeLabel%20p%7Bbackground-color%3A%230f0f10%3B%7D%23coddy-mermaid-1%20.edgeLabel%20rect%7Bopacity%3A0.5%3Bbackground-color%3A%230f0f10%3Bfill%3A%230f0f10%3B%7D%23coddy-mermaid-1%20.labelBkg%7Bbackground-color%3Argba(15%2C%2015%2C%2016%2C%200.5)%3B%7D%23coddy-mermaid-1%20.cluster%20rect%7Bfill%3A%231b1b1c%3Bstroke%3A%234b4b4c%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-1%20.cluster%20text%7Bfill%3A%23ffffff%3B%7D%23coddy-mermaid-1%20.cluster%20span%7Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-1%20.node%20.collapsed-indicator%7Bfill%3A%234b4b4c%3Bstroke%3Anone%3Bopacity%3A0.6%3B%7D%23coddy-mermaid-1%20.node%20.collapsed-separator%7Bstroke%3A%234b4b4c%3Bstroke-width%3A0.75px%3B%7D%23coddy-mermaid-1%20div.mermaidTooltip%7Bposition%3Aabsolute%3Btext-align%3Acenter%3Bmax-width%3A200px%3Bpadding%3A2px%3Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bfont-size%3A12px%3Bbackground%3A%2327303b%3Bborder%3A1px%20solid%20%2393c5fd%3Bborder-radius%3A2px%3Bpointer-events%3Anone%3Bz-index%3A100%3B%7D%23coddy-mermaid-1%20.flowchartTitleText%7Btext-anchor%3Amiddle%3Bfont-size%3A18px%3Bfill%3A%23ffffff%3B%7D%23coddy-mermaid-1%20rect.text%7Bfill%3Anone%3Bstroke-width%3A0%3B%7D%23coddy-mermaid-1%20.icon-shape%2C%23coddy-mermaid-1%20.image-shape%7Bbackground-color%3A%230f0f10%3Btext-align%3Acenter%3B%7D%23coddy-mermaid-1%20.icon-shape%20p%2C%23coddy-mermaid-1%20.image-shape%20p%7Bbackground-color%3A%230f0f10%3Bpadding%3A2px%3B%7D%23coddy-mermaid-1%20.icon-shape%20.label%20rect%2C%23coddy-mermaid-1%20.image-shape%20.label%20rect%7Bopacity%3A0.5%3Bbackground-color%3A%230f0f10%3Bfill%3A%230f0f10%3B%7D%23coddy-mermaid-1%20.label-icon%7Bdisplay%3Ainline-block%3Bheight%3A1em%3Boverflow%3Avisible%3Bvertical-align%3A-0.125em%3B%7D%23coddy-mermaid-1%20.node%20.label-icon%20path%7Bfill%3AcurrentColor%3Bstroke%3Arevert%3Bstroke-width%3Arevert%3B%7D%23coddy-mermaid-1%20.node%20.neo-node%7Bstroke%3A%239333ea%3B%7D%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.node%20rect%2C%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.cluster%20rect%2C%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.node%20polygon%7Bstroke%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.swimlane.cluster%20rect%7Bfilter%3Anone%3B%7D%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.node%20path%7Bstroke%3A%239333ea%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.node%20.outer-path%7Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.node%20.neo-line%20path%7Bstroke%3A%239333ea%3Bfilter%3Anone%3B%7D%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.node%20circle%7Bstroke%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.node%20circle%20.state-start%7Bfill%3A%23000000%3B%7D%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.icon-shape%20.icon%7Bfill%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-1%20%5Bdata-look%3D%22neo%22%5D.icon-shape%20.icon-neo%20path%7Bstroke%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-1%20.mindmap-node.section-root%20text%7Btext-anchor%3Amiddle%3B%7D%23coddy-mermaid-1%20%3Aroot%7B--mermaid-font-family%3A%22trebuchet%20ms%22%2Cverdana%2Carial%2Csans-serif%3B%7D%3C%2Fstyle%3E%3Cg%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-pointEnd%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%225%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%228%22%20markerHeight%3D%228%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%200%200%20L%2010%205%20L%200%2010%20z%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-pointStart%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%224.5%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%228%22%20markerHeight%3D%228%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%200%205%20L%2010%2010%20L%2010%200%20z%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-pointEnd-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2011.5%2014%22%20refX%3D%2211.5%22%20refY%3D%227%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2210.5%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%200%200%20L%2011.5%207%20L%200%2014%20z%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-pointStart-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2011.5%2014%22%20refX%3D%221%22%20refY%3D%227%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211.5%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Cpolygon%20points%3D%220%2C7%2011.5%2C14%2011.5%2C0%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-circleEnd%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%2211%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-circleStart%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%22-1%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-circleEnd-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refY%3D%225%22%20refX%3D%2212.25%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2214%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-circleStart-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%22-2%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2214%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-crossEnd%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2011%2011%22%20refX%3D%2212%22%20refY%3D%225.2%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20l%209%2C9%20M%2010%2C1%20l%20-9%2C9%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-crossStart%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2011%2011%22%20refX%3D%22-1%22%20refY%3D%225.2%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20l%209%2C9%20M%2010%2C1%20l%20-9%2C9%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-crossEnd-margin%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2015%2015%22%20refX%3D%2217.7%22%20refY%3D%227.5%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2212%22%20markerHeight%3D%2212%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20L%2014%2C14%20M%201%2C14%20L%2014%2C1%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202.5%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-1_flowchart-v2-crossStart-margin%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2015%2015%22%20refX%3D%22-3.5%22%20refY%3D%227.5%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2212%22%20markerHeight%3D%2212%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20L%2014%2C14%20M%201%2C14%20L%2014%2C1%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202.5%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cg%20class%3D%22root%22%3E%3Cg%20class%3D%22clusters%22%2F%3E%3Cg%20class%3D%22edges%20edgePaths%22%3E%3Cpath%20d%3D%22M184%2C52L184%2C88%22%20id%3D%22coddy-mermaid-1-L_O_P_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%2032%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_O_P_0%22%20data-points%3D%22W3sieCI6MTg0LCJ5Ijo1Mn0seyJ4IjoxODQsInkiOjkyfV0%3D%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-1_flowchart-v2-pointEnd-margin)%22%2F%3E%3Cpath%20d%3D%22M159.66666666666669%2C233.666654586792L159.66666666666669%2C258L159.66666666666669%2C270.9289321881345Q159.66666666666669%2C278%20152.5955988548012%2C278L95.07106781186548%2C278Q88%2C278%2088%2C285.0710678118655L88%2C353.99999809265137%22%20id%3D%22coddy-mermaid-1-L_P_S_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%20182.67172241210938%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_P_S_0%22%20data-points%3D%22W3sieCI6MTU5LjY2NjY2NjY2NjY2NjY5LCJ5IjoyMzMuNjY2NjU0NTg2NzkyfSx7IngiOjE1OS42NjY2NjY2NjY2NjY2OSwieSI6MjU4fSx7IngiOjE1OS42NjY2NjY2NjY2NjY2OSwieSI6Mjc4fSx7IngiOjg4LCJ5IjoyNzh9LHsieCI6ODgsInkiOjM1Ny45OTk5OTgwOTI2NTEzN31d%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-1_flowchart-v2-pointEnd-margin)%22%2F%3E%3Cpath%20d%3D%22M208.33333333333334%2C233.666654586792L208.33333333333334%2C258L208.33333333333334%2C270.9289321881345Q208.33333333333334%2C278%20215.40440114519882%2C278L272.9289321881345%2C278Q280%2C278%20280%2C285.0710678118655L280%2C353.99999809265137%22%20id%3D%22coddy-mermaid-1-L_P_R_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%20182.67172241210938%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_P_R_0%22%20data-points%3D%22W3sieCI6MjA4LjMzMzMzMzMzMzMzMzM0LCJ5IjoyMzMuNjY2NjU0NTg2NzkyfSx7IngiOjIwOC4zMzMzMzMzMzMzMzMzNCwieSI6MjU4fSx7IngiOjIwOC4zMzMzMzMzMzMzMzMzNCwieSI6Mjc4fSx7IngiOjI4MCwieSI6Mjc4fSx7IngiOjI4MCwieSI6MzU3Ljk5OTk5ODA5MjY1MTM3fV0%3D%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-1_flowchart-v2-pointEnd-margin)%22%2F%3E%3C%2Fg%3E%3Cg%20class%3D%22edgeLabels%22%3E%3Cg%20class%3D%22edgeLabel%22%20transform%3D%22translate(87.6015625%2C%20307.9999990463257)%22%3E%3Cg%20class%3D%22label%22%20data-id%3D%22L_P_S_0%22%20transform%3D%22translate(0%2C%20-9.000000476837158)%22%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22%22%20x%3D%22-14.1015625%22%20y%3D%22-0.9999990463256836%22%20width%3D%2228.203125%22%20height%3D%2219.999999046325684%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20text-anchor%3D%22middle%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%20text-anchor%3D%22middle%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3Eyes%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22edgeLabel%22%20transform%3D%22translate(279.7265625%2C%20307.9999990463257)%22%3E%3Cg%20class%3D%22label%22%20data-id%3D%22L_P_R_0%22%20transform%3D%22translate(0%2C%20-9.000000476837158)%22%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22%22%20x%3D%22-10.7265625%22%20y%3D%22-0.9999990463256836%22%20width%3D%2221.453125%22%20height%3D%2219.999999046325684%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20text-anchor%3D%22middle%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%20text-anchor%3D%22middle%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3Eno%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22nodes%22%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-1-flowchart-O-0%22%20data-look%3D%22neo%22%20transform%3D%22translate(184%2C%2032)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3EOrder%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-1-flowchart-P-1%22%20data-look%3D%22neo%22%20transform%3D%22translate(184%2C%20175)%22%3E%3Cpolygon%20points%3D%2282.99999952316284%2C0%20165.99999904632568%2C-82.99999952316284%2082.99999952316284%2C-165.99999904632568%200%2C-82.99999952316284%22%20class%3D%22label-container%22%20transform%3D%22translate(-82.49999952316284%2C%2082.99999952316284)%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3EPaid%3F%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-1-flowchart-S-3%22%20data-look%3D%22neo%22%20transform%3D%22translate(88%2C%20377.99999809265137)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3EShip%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-1-flowchart-R-5%22%20data-look%3D%22neo%22%20transform%3D%22translate(280%2C%20377.99999809265137)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3ERemind%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cdefs%3E%3Cfilter%20id%3D%22coddy-mermaid-1-drop-shadow%22%20height%3D%22130%25%22%20width%3D%22130%25%22%3E%3CfeDropShadow%20dx%3D%224%22%20dy%3D%224%22%20stdDeviation%3D%220%22%20flood-opacity%3D%220.06%22%20flood-color%3D%22%23000000%22%2F%3E%3C%2Ffilter%3E%3C%2Fdefs%3E%3Cdefs%3E%3Cfilter%20id%3D%22coddy-mermaid-1-drop-shadow-small%22%20height%3D%22150%25%22%20width%3D%22150%25%22%3E%3CfeDropShadow%20dx%3D%222%22%20dy%3D%222%22%20stdDeviation%3D%220%22%20flood-opacity%3D%220.06%22%20flood-color%3D%22%23000000%22%2F%3E%3C%2Ffilter%3E%3C%2Fdefs%3E%3C%2Fsvg%3E\"></button></figure></div>","mermaid-signin":"<div class=\"md\"><figure class=\"md-figure\" data-testid=\"md-figure\" data-kind=\"mermaid\" data-view=\"picture\"><div class=\"md-figure-head\"><span class=\"md-figure-label\">Mermaid diagram</span><div class=\"md-figure-actions\"><button type=\"button\" class=\"md-copy md-figure-format\" title=\"Download the source (.mmd)\" aria-label=\"Download the source (.mmd)\" data-testid=\"md-figure-download-mmd\"><span aria-hidden=\"true\">MMD</span></button><button type=\"button\" class=\"md-copy md-figure-format\" title=\"Download as SVG (.svg)\" aria-label=\"Download as SVG (.svg)\" data-testid=\"md-figure-download-svg\"><span aria-hidden=\"true\">SVG</span></button><button type=\"button\" class=\"md-copy md-figure-source-toggle\" aria-pressed=\"false\" title=\"Show the source code\" aria-label=\"Show the source code\" data-testid=\"md-figure-source-toggle\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" class=\"md-copy__glyph\"><path d=\"M5.5 4L1.5 8l4 4M10.5 4l4 4-4 4\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></button></div></div><button type=\"button\" class=\"md-figure-picture\" aria-label=\"Open the picture\" title=\"Open the picture\"><img alt=\"Mermaid diagram\" width=\"185.98\" height=\"296\" data-testid=\"md-figure-img\" src=\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20id%3D%22coddy-mermaid-2%22%20width%3D%22185.98%22%20class%3D%22flowchart%22%20viewBox%3D%224%204%20185.9794464111328%20296%22%20role%3D%22graphics-document%20document%22%20aria-roledescription%3D%22flowchart-v2%22%20height%3D%22296%22%3E%3Cstyle%3E%23coddy-mermaid-2%7Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bfont-size%3A14px%3Bfill%3A%23ffffff%3B%7D%40keyframes%20edge-animation-frame%7Bfrom%7Bstroke-dashoffset%3A0%3B%7D%7D%40keyframes%20dash%7Bto%7Bstroke-dashoffset%3A0%3B%7D%7D%23coddy-mermaid-2%20.edge-animation-slow%7Bstroke-dasharray%3A9%2C5!important%3Bstroke-dashoffset%3A900%3Banimation%3Adash%2050s%20linear%20infinite%3Bstroke-linecap%3Around%3B%7D%23coddy-mermaid-2%20.edge-animation-fast%7Bstroke-dasharray%3A9%2C5!important%3Bstroke-dashoffset%3A900%3Banimation%3Adash%2020s%20linear%20infinite%3Bstroke-linecap%3Around%3B%7D%23coddy-mermaid-2%20.error-icon%7Bfill%3A%2327303b%3B%7D%23coddy-mermaid-2%20.error-text%7Bfill%3A%23ffffff%3Bstroke%3A%23ffffff%3B%7D%23coddy-mermaid-2%20.edge-thickness-normal%7Bstroke-width%3A1px%3B%7D%23coddy-mermaid-2%20.edge-thickness-thick%7Bstroke-width%3A3.5px%3B%7D%23coddy-mermaid-2%20.edge-pattern-solid%7Bstroke-dasharray%3A0%3B%7D%23coddy-mermaid-2%20.edge-thickness-invisible%7Bstroke-width%3A0%3Bfill%3Anone%3B%7D%23coddy-mermaid-2%20.edge-pattern-dashed%7Bstroke-dasharray%3A3%3B%7D%23coddy-mermaid-2%20.edge-pattern-dotted%7Bstroke-dasharray%3A2%3B%7D%23coddy-mermaid-2%20.marker%7Bfill%3A%23b7b7b7%3Bstroke%3A%23b7b7b7%3B%7D%23coddy-mermaid-2%20.marker.cross%7Bstroke%3A%23b7b7b7%3B%7D%23coddy-mermaid-2%20svg%7Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bfont-size%3A14px%3B%7D%23coddy-mermaid-2%20p%7Bmargin%3A0%3B%7D%23coddy-mermaid-2%20.label%7Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-2%20.cluster-label%20text%7Bfill%3A%23ffffff%3B%7D%23coddy-mermaid-2%20.cluster-label%20span%7Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-2%20.cluster-label%20span%20p%7Bbackground-color%3Atransparent%3B%7D%23coddy-mermaid-2%20.label%20text%2C%23coddy-mermaid-2%20span%7Bfill%3A%23ffffff%3Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-2%20.node%20rect%2C%23coddy-mermaid-2%20.node%20circle%2C%23coddy-mermaid-2%20.node%20ellipse%2C%23coddy-mermaid-2%20.node%20polygon%2C%23coddy-mermaid-2%20.node%20path%7Bfill%3A%232c1740%3Bstroke%3A%239333ea%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-2%20.rough-node%20.label%20text%2C%23coddy-mermaid-2%20.node%20.label%20text%2C%23coddy-mermaid-2%20.image-shape%20.label%2C%23coddy-mermaid-2%20.icon-shape%20.label%7Btext-anchor%3Amiddle%3B%7D%23coddy-mermaid-2%20.node%20.katex%20path%7Bfill%3A%23000%3Bstroke%3A%23000%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-2%20.rough-node%20.label%2C%23coddy-mermaid-2%20.node%20.label%2C%23coddy-mermaid-2%20.image-shape%20.label%2C%23coddy-mermaid-2%20.icon-shape%20.label%7Btext-align%3Acenter%3B%7D%23coddy-mermaid-2%20.node.clickable%7Bcursor%3Apointer%3B%7D%23coddy-mermaid-2%20.root%20.anchor%20path%7Bfill%3A%23b7b7b7!important%3Bstroke-width%3A0%3Bstroke%3A%23b7b7b7%3B%7D%23coddy-mermaid-2%20.arrowheadPath%7Bfill%3A%23b7b7b7%3B%7D%23coddy-mermaid-2%20.edgePaths%20.path%7Bstroke%3A%23b7b7b7%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-2%20.flowchart-link%7Bstroke%3A%23b7b7b7%3Bfill%3Anone%3B%7D%23coddy-mermaid-2%20.edgeLabel%7Bbackground-color%3A%230f0f10%3Btext-align%3Acenter%3B%7D%23coddy-mermaid-2%20.edgeLabel%20p%7Bbackground-color%3A%230f0f10%3B%7D%23coddy-mermaid-2%20.edgeLabel%20rect%7Bopacity%3A0.5%3Bbackground-color%3A%230f0f10%3Bfill%3A%230f0f10%3B%7D%23coddy-mermaid-2%20.labelBkg%7Bbackground-color%3Argba(15%2C%2015%2C%2016%2C%200.5)%3B%7D%23coddy-mermaid-2%20.cluster%20rect%7Bfill%3A%231b1b1c%3Bstroke%3A%234b4b4c%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-2%20.cluster%20text%7Bfill%3A%23ffffff%3B%7D%23coddy-mermaid-2%20.cluster%20span%7Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-2%20.node%20.collapsed-indicator%7Bfill%3A%234b4b4c%3Bstroke%3Anone%3Bopacity%3A0.6%3B%7D%23coddy-mermaid-2%20.node%20.collapsed-separator%7Bstroke%3A%234b4b4c%3Bstroke-width%3A0.75px%3B%7D%23coddy-mermaid-2%20div.mermaidTooltip%7Bposition%3Aabsolute%3Btext-align%3Acenter%3Bmax-width%3A200px%3Bpadding%3A2px%3Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bfont-size%3A12px%3Bbackground%3A%2327303b%3Bborder%3A1px%20solid%20%2393c5fd%3Bborder-radius%3A2px%3Bpointer-events%3Anone%3Bz-index%3A100%3B%7D%23coddy-mermaid-2%20.flowchartTitleText%7Btext-anchor%3Amiddle%3Bfont-size%3A18px%3Bfill%3A%23ffffff%3B%7D%23coddy-mermaid-2%20rect.text%7Bfill%3Anone%3Bstroke-width%3A0%3B%7D%23coddy-mermaid-2%20.icon-shape%2C%23coddy-mermaid-2%20.image-shape%7Bbackground-color%3A%230f0f10%3Btext-align%3Acenter%3B%7D%23coddy-mermaid-2%20.icon-shape%20p%2C%23coddy-mermaid-2%20.image-shape%20p%7Bbackground-color%3A%230f0f10%3Bpadding%3A2px%3B%7D%23coddy-mermaid-2%20.icon-shape%20.label%20rect%2C%23coddy-mermaid-2%20.image-shape%20.label%20rect%7Bopacity%3A0.5%3Bbackground-color%3A%230f0f10%3Bfill%3A%230f0f10%3B%7D%23coddy-mermaid-2%20.label-icon%7Bdisplay%3Ainline-block%3Bheight%3A1em%3Boverflow%3Avisible%3Bvertical-align%3A-0.125em%3B%7D%23coddy-mermaid-2%20.node%20.label-icon%20path%7Bfill%3AcurrentColor%3Bstroke%3Arevert%3Bstroke-width%3Arevert%3B%7D%23coddy-mermaid-2%20.node%20.neo-node%7Bstroke%3A%239333ea%3B%7D%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.node%20rect%2C%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.cluster%20rect%2C%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.node%20polygon%7Bstroke%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.swimlane.cluster%20rect%7Bfilter%3Anone%3B%7D%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.node%20path%7Bstroke%3A%239333ea%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.node%20.outer-path%7Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.node%20.neo-line%20path%7Bstroke%3A%239333ea%3Bfilter%3Anone%3B%7D%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.node%20circle%7Bstroke%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.node%20circle%20.state-start%7Bfill%3A%23000000%3B%7D%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.icon-shape%20.icon%7Bfill%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-2%20%5Bdata-look%3D%22neo%22%5D.icon-shape%20.icon-neo%20path%7Bstroke%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-2%20.mindmap-node.section-root%20text%7Btext-anchor%3Amiddle%3B%7D%23coddy-mermaid-2%20%3Aroot%7B--mermaid-font-family%3A%22trebuchet%20ms%22%2Cverdana%2Carial%2Csans-serif%3B%7D%3C%2Fstyle%3E%3Cg%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-pointEnd%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%225%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%228%22%20markerHeight%3D%228%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%200%200%20L%2010%205%20L%200%2010%20z%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-pointStart%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%224.5%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%228%22%20markerHeight%3D%228%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%200%205%20L%2010%2010%20L%2010%200%20z%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-pointEnd-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2011.5%2014%22%20refX%3D%2211.5%22%20refY%3D%227%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2210.5%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%200%200%20L%2011.5%207%20L%200%2014%20z%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-pointStart-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2011.5%2014%22%20refX%3D%221%22%20refY%3D%227%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211.5%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Cpolygon%20points%3D%220%2C7%2011.5%2C14%2011.5%2C0%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-circleEnd%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%2211%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-circleStart%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%22-1%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-circleEnd-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refY%3D%225%22%20refX%3D%2212.25%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2214%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-circleStart-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%22-2%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2214%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-crossEnd%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2011%2011%22%20refX%3D%2212%22%20refY%3D%225.2%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20l%209%2C9%20M%2010%2C1%20l%20-9%2C9%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-crossStart%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2011%2011%22%20refX%3D%22-1%22%20refY%3D%225.2%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20l%209%2C9%20M%2010%2C1%20l%20-9%2C9%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-crossEnd-margin%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2015%2015%22%20refX%3D%2217.7%22%20refY%3D%227.5%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2212%22%20markerHeight%3D%2212%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20L%2014%2C14%20M%201%2C14%20L%2014%2C1%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202.5%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-2_flowchart-v2-crossStart-margin%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2015%2015%22%20refX%3D%22-3.5%22%20refY%3D%227.5%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2212%22%20markerHeight%3D%2212%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20L%2014%2C14%20M%201%2C14%20L%2014%2C1%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202.5%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cg%20class%3D%22root%22%3E%3Cg%20class%3D%22clusters%22%2F%3E%3Cg%20class%3D%22edges%20edgePaths%22%3E%3Cpath%20d%3D%22M96.9897232055664%2C52L96.9897232055664%2C88%22%20id%3D%22coddy-mermaid-2-L_T_E_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%2032%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_T_E_0%22%20data-points%3D%22W3sieCI6OTYuOTg5NzIzMjA1NTY2NCwieSI6NTJ9LHsieCI6OTYuOTg5NzIzMjA1NTY2NCwieSI6OTJ9XQ%3D%3D%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-2_flowchart-v2-pointEnd-margin)%22%2F%3E%3Cpath%20d%3D%22M96.9897232055664%2C132L96.9897232055664%2C168%22%20id%3D%22coddy-mermaid-2-L_E_W_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%2032%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_E_W_0%22%20data-points%3D%22W3sieCI6OTYuOTg5NzIzMjA1NTY2NCwieSI6MTMyfSx7IngiOjk2Ljk4OTcyMzIwNTU2NjQsInkiOjE3Mn1d%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-2_flowchart-v2-pointEnd-margin)%22%2F%3E%3Cpath%20d%3D%22M96.9897232055664%2C212L96.9897232055664%2C248%22%20id%3D%22coddy-mermaid-2-L_W_B_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%2032%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_W_B_0%22%20data-points%3D%22W3sieCI6OTYuOTg5NzIzMjA1NTY2NCwieSI6MjEyfSx7IngiOjk2Ljk4OTcyMzIwNTU2NjQsInkiOjI1Mn1d%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-2_flowchart-v2-pointEnd-margin)%22%2F%3E%3C%2Fg%3E%3Cg%20class%3D%22edgeLabels%22%2F%3E%3Cg%20class%3D%22nodes%22%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-2-flowchart-T-0%22%20data-look%3D%22neo%22%20transform%3D%22translate(96.9897232055664%2C%2032)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3ESign%3C%2Ftspan%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3E%20in%3C%2Ftspan%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3E%20to%3C%2Ftspan%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3E%20Acme%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-2-flowchart-E-1%22%20data-look%3D%22neo%22%20transform%3D%22translate(96.9897232055664%2C%20112)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3EEmail%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-2-flowchart-W-3%22%20data-look%3D%22neo%22%20transform%3D%22translate(96.9897232055664%2C%20192)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3EPassword%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-2-flowchart-B-5%22%20data-look%3D%22neo%22%20transform%3D%22translate(96.9897232055664%2C%20272)%22%3E%3Cg%20class%3D%22basic%20label-container%20outer-path%22%3E%3Cpath%20d%3D%22M-65.00000035762787%20-19.999999523162842%20C-34.00515979473008%20-19.999999523162842%2C%20-3.010319231832298%20-19.999999523162842%2C%2065.00000035762787%20-19.999999523162842%20C65.00000035762787%20-19.999999523162842%2C%2065.00000035762787%20-19.999999523162842%2C%2065.00000035762787%20-19.999999523162842%20C65.48552721477581%20-19.984429621874803%2C%2065.97105407192376%20-19.968859720586764%2C%2066.28140472669106%20-19.95890737914928%20C66.74191089987623%20-19.91448290246181%2C%2067.2024170730614%20-19.870058425774342%2C%2067.5575435303414%20-19.835799803542592%20C67.97591118319535%20-19.768161365918772%2C%2068.39427883604931%20-19.700522928294948%2C%2068.82317284050377%20-19.63118267177743%20C69.31832190764821%20-19.51816812835134%2C%2069.81347097479264%20-19.405153584925255%2C%2070.07309191486608%20-19.345896799538455%20C70.5629922104259%20-19.200496963355423%2C%2071.05289250598574%20-19.055097127172395%2C%2071.30216456784497%20-18.98111448766833%20C71.56961907874464%20-18.882688755334854%2C%2071.83707358964432%20-18.784263023001376%2C%2072.5053402762741%20-18.538334704932083%20C72.76242474931252%20-18.424531034857914%2C%2073.01950922235092%20-18.310727364783745%2C%2073.67767493308715%20-18.019376928432948%20C74.12498283967278%20-17.786016680081612%2C%2074.57229074625842%20-17.552656431730277%2C%2074.81435116371426%20-17.426373666990656%20C75.10412608281281%20-17.250710408126672%2C%2075.39390100191136%20-17.075047149262687%2C%2075.91069812170753%20-16.761761698205262%20C76.13321138890633%20-16.606546075451465%2C%2076.35572465610514%20-16.45133045269767%2C%2076.96221068225086%20-16.02827205521534%20C77.23588347027095%20-15.810025289508058%2C%2077.50955625829104%20-15.591778523800777%2C%2077.96456795468424%20-15.228918804296963%20C78.32610248607818%20-14.900582708564512%2C%2078.68763701747211%20-14.572246612832062%2C%2078.91365103797031%20-14.36698665941889%20C79.26508822202334%20-14.004098913354724%2C%2079.61652540607638%20-13.641211167290557%2C%2079.80555994614213%20-13.446017484648294%20C80.07013904376396%20-13.135227821604543%2C%2080.33471814138579%20-12.824438158560794%2C%2080.63662963418216%20-12.469795739871566%20C80.92974913301069%20-12.077042315177039%2C%2081.2228686318392%20-11.68428889048251%2C%2081.40344505847838%20-11.442332929636915%20C81.64649919954033%20-11.068936499790334%2C%2081.88955334060228%20-10.695540069943753%2C%2082.10285520997094%20-10.367851119021664%20C82.30986230415834%20-10.00028906155064%2C%2082.51686939834573%20-9.63272700407962%2C%2082.73198606232438%20-9.250765584261261%20C82.927693986664%20-8.844373891891289%2C%2083.12340191100361%20-8.437982199521317%2C%2083.2882523819182%20-8.095666669432141%20C83.42143327667567%20-7.766707284503761%2C%2083.55461417143314%20-7.43774789957538%2C%2083.76936835112646%20-6.907300923743271%20C83.91499052411709%20-6.468710140437901%2C%2084.06061269710771%20-6.030119357132531%2C%2084.17335696123263%20-5.690551596947329%20C84.28785864962124%20-5.253907033775854%2C%2084.40236033800987%20-4.817262470604379%2C%2084.49855813638248%20-4.45041857302004%20C84.55957217287965%20-4.137124390928255%2C%2084.62058620937682%20-3.8238302088364704%2C%2084.74363555519191%20-3.1919978245644316%20C84.80340333077669%20-2.728450759611104%2C%2084.86317110636148%20-2.264903694657776%2C%2084.90758214197808%20-1.9204604723662921%20C84.93501677290924%20-1.4931439507780715%2C%2084.96245140384039%20-1.0658274291898509%2C%2084.98972420504946%20-0.6410315361497202%20C84.98972420504946%20-0.1673887038242266%2C%2084.98972420504946%200.306254128501267%2C%2084.98972420504946%200.6410315361497153%20C84.97034789432917%200.9428332158948121%2C%2084.95097158360886%201.244634895639909%2C%2084.90758214197808%201.9204604723662784%20C84.86581918400647%202.2443657273652824%2C%2084.82405622603486%202.568270982364287%2C%2084.74363555519191%203.191997824564418%20C84.68900049100019%203.4725373320640514%2C%2084.63436542680846%203.7530768395636844%2C%2084.49855813638248%204.450418573020036%20C84.37292777278101%204.929501597976446%2C%2084.24729740917955%205.408584622932857%2C%2084.17335696123263%205.690551596947316%20C84.06349880735367%206.0214268529109605%2C%2083.9536406534747%206.352302108874604%2C%2083.76936835112646%206.907300923743258%20C83.59990015170551%207.325890652757745%2C%2083.43043195228456%207.744480381772233%2C%2083.2882523819182%208.095666669432136%20C83.14883727162352%208.385165128964523%2C%2083.00942216132886%208.67466358849691%2C%2082.73198606232438%209.250765584261258%20C82.54090306811113%209.590052789738202%2C%2082.34982007389789%209.929339995215146%2C%2082.10285520997095%2010.36785111902166%20C81.84163334098473%2010.769158057677952%2C%2081.5804114719985%2011.170464996334243%2C%2081.40344505847838%2011.442332929636905%20C81.11954025718904%2011.822739499105131%2C%2080.83563545589972%2012.203146068573357%2C%2080.63662963418216%2012.469795739871563%20C80.38666518836871%2012.763418201303937%2C%2080.13670074255526%2013.05704066273631%2C%2079.80555994614213%2013.446017484648284%20C79.49781145928299%2013.763793063951008%2C%2079.19006297242386%2014.081568643253734%2C%2078.91365103797031%2014.366986659418885%20C78.5464935107344%2014.70042941119871%2C%2078.17933598349848%2015.033872162978538%2C%2077.96456795468427%2015.228918804296951%20C77.68039191279958%2015.455541635457925%2C%2077.39621587091489%2015.682164466618898%2C%2076.96221068225087%2016.028272055215336%20C76.5805001763293%2016.294536780164748%2C%2076.19878967040772%2016.56080150511416%2C%2075.91069812170754%2016.76176169820526%20C75.48102246403424%2017.022233606941253%2C%2075.05134680636095%2017.282705515677247%2C%2074.81435116371426%2017.426373666990653%20C74.56840805535226%2017.554682029089033%2C%2074.32246494699025%2017.68299039118741%2C%2073.67767493308715%2018.019376928432948%20C73.39638207346248%2018.14389693313258%2C%2073.1150892138378%2018.26841693783221%2C%2072.50534027627411%2018.53833470493208%20C72.10862722044979%2018.684328776650716%2C%2071.71191416462547%2018.830322848369352%2C%2071.30216456784498%2018.98111448766832%20C70.9328901708571%2019.090713190333457%2C%2070.56361577386924%2019.200311892998595%2C%2070.0730919148661%2019.34589679953845%20C69.7126124186157%2019.428173892209053%2C%2069.3521329223653%2019.510450984879654%2C%2068.82317284050379%2019.631182671777427%20C68.52337664494092%2019.67965139572181%2C%2068.22358044937808%2019.728120119666194%2C%2067.55754353034142%2019.83579980354259%20C67.12464392778918%2019.877561107562858%2C%2066.69174432523694%2019.919322411583128%2C%2066.28140472669106%2019.95890737914928%20C65.85044914715333%2019.97272728578091%2C%2065.41949356761558%2019.986547192412534%2C%2065.00000035762787%2019.999999523162842%20C65.00000035762787%2019.999999523162842%2C%2065.00000035762787%2019.999999523162842%2C%2065.00000035762787%2019.999999523162842%20C14.163571303381822%2019.999999523162842%2C%20-36.672857750864225%2019.999999523162842%2C%20-65.00000035762787%2019.999999523162842%20C-65.32315912279535%2019.989636450554297%2C%20-65.64631788796282%2019.979273377945756%2C%20-66.28140472669105%2019.95890737914928%20C-66.59817790144766%2019.928348651955993%2C%20-66.91495107620426%2019.897789924762705%2C%20-67.5575435303414%2019.83579980354259%20C-67.9633739136194%2019.77018829443583%2C%20-68.36920429689741%2019.70457678532907%2C%20-68.82317284050377%2019.631182671777427%20C-69.17520279135721%2019.550834132705248%2C%20-69.52723274221064%2019.470485593633065%2C%20-70.07309191486608%2019.345896799538455%20C-70.46798234450509%2019.22869539284376%2C%20-70.86287277414411%2019.111493986149068%2C%20-71.30216456784497%2018.981114487668332%20C-71.71758814010869%2018.828234772941876%2C%20-72.13301171237241%2018.67535505821542%2C%20-72.5053402762741%2018.538334704932083%20C-72.95089012790613%2018.341103002381338%2C%20-73.39643997953817%2018.143871299830593%2C%20-73.67767493308713%2018.01937692843295%20C-74.00609789775181%2017.848038878132332%2C%20-74.3345208624165%2017.676700827831716%2C%20-74.81435116371425%2017.426373666990656%20C-75.19952126583487%2017.192881287574366%2C%20-75.5846913679555%2016.959388908158076%2C%20-75.91069812170751%2016.76176169820527%20C-76.14513262317199%2016.598230338489653%2C%20-76.37956712463647%2016.434698978774037%2C%20-76.96221068225086%2016.02827205521534%20C-77.36315134454014%2015.708532546518748%2C%20-77.76409200682943%2015.388793037822158%2C%20-77.96456795468424%2015.228918804296965%20C-78.28004090065774%2014.942414621720586%2C%20-78.59551384663123%2014.655910439144208%2C%20-78.9136510379703%2014.366986659418899%20C-79.09770028899027%2014.176940697016246%2C%20-79.28174954001024%2013.986894734613594%2C%20-79.80555994614213%2013.446017484648289%20C-79.98448084189371%2013.235846819611098%2C%20-80.16340173764529%2013.025676154573906%2C%20-80.63662963418216%2012.469795739871568%20C-80.90906366027373%2012.104758964159231%2C%20-81.18149768636529%2011.739722188446894%2C%20-81.40344505847838%2011.442332929636917%20C-81.61908261113521%2011.111055741965417%2C%20-81.83472016379204%2010.779778554293916%2C%20-82.10285520997094%2010.367851119021672%20C-82.31768877078417%209.98639237754079%2C%20-82.53252233159742%209.604933636059908%2C%20-82.73198606232438%209.250765584261263%20C-82.92662368605237%208.846596394012117%2C%20-83.12126130978034%208.44242720376297%2C%20-83.2882523819182%208.095666669432145%20C-83.40967736412405%207.795744615791358%2C%20-83.5311023463299%207.495822562150571%2C%20-83.76936835112646%206.907300923743273%20C-83.85190172409011%206.658723554283934%2C%20-83.93443509705376%206.410146184824593%2C%20-84.17335696123263%205.690551596947323%20C-84.25552914531316%205.377193445398376%2C%20-84.3377013293937%205.063835293849429%2C%20-84.49855813638248%204.450418573020043%20C-84.58220936158575%204.020887211293937%2C%20-84.66586058678904%203.591355849567831%2C%20-84.74363555519191%203.191997824564434%20C-84.80392836911115%202.7243786659696245%2C%20-84.86422118303038%202.2567595073748157%2C%20-84.90758214197808%201.9204604723663035%20C-84.93167203571488%201.5452409324034346%2C%20-84.95576192945168%201.170021392440566%2C%20-84.98972420504946%200.6410315361497226%20C-84.98972420504946%200.23403444476056945%2C%20-84.98972420504946%20-0.17296264662858374%2C%20-84.98972420504946%20-0.641031536149713%20C-84.96239997694649%20-1.0666284445733507%2C%20-84.93507574884353%20-1.4922253529969887%2C%20-84.90758214197808%20-1.920460472366276%20C-84.85939004356482%20-2.2942288710533814%2C%20-84.81119794515155%20-2.6679972697404866%2C%20-84.74363555519191%20-3.1919978245644245%20C-84.66159894141312%20-3.6132384978740695%2C%20-84.57956232763432%20-4.0344791711837145%2C%20-84.49855813638248%20-4.450418573020033%20C-84.42684285421011%20-4.723900025543206%2C%20-84.35512757203773%20-4.997381478066378%2C%20-84.17335696123263%20-5.690551596947313%20C-84.08308581803028%20-5.962433897519347%2C%20-83.99281467482793%20-6.2343161980913795%2C%20-83.76936835112647%20-6.9073009237432474%20C-83.64669961080055%20-7.210295083987022%2C%20-83.52403087047463%20-7.513289244230796%2C%20-83.2882523819182%20-8.095666669432134%20C-83.1527040406046%20-8.377135700439721%2C%20-83.017155699291%20-8.658604731447307%2C%20-82.73198606232438%20-9.250765584261254%20C-82.5731471670547%20-9.532800126994825%2C%20-82.41430827178502%20-9.814834669728398%2C%20-82.10285520997094%20-10.367851119021667%20C-81.9573206066157%20-10.591431351288257%2C%20-81.81178600326045%20-10.815011583554845%2C%20-81.40344505847838%20-11.44233292963691%20C-81.14359940800388%20-11.790502428847004%2C%20-80.88375375752938%20-12.138671928057096%2C%20-80.63662963418217%20-12.469795739871563%20C-80.45080917629066%20-12.688071023194517%2C%20-80.26498871839915%20-12.906346306517472%2C%20-79.80555994614213%20-13.446017484648284%20C-79.5693457365079%20-13.689928049642901%2C%20-79.33313152687367%20-13.933838614637517%2C%20-78.91365103797031%20-14.366986659418878%20C-78.56761181820082%20-14.681250323117503%2C%20-78.22157259843131%20-14.995513986816126%2C%20-77.96456795468427%20-15.228918804296947%20C-77.64416417127059%20-15.484432295266602%2C%20-77.3237603878569%20-15.739945786236257%2C%20-76.96221068225087%20-16.028272055215332%20C-76.74859257636628%20-16.177282798501665%2C%20-76.53497447048169%20-16.326293541787994%2C%20-75.91069812170754%20-16.761761698205255%20C-75.6874913407411%20-16.89707096053575%2C%20-75.46428455977467%20-17.032380222866244%2C%20-74.81435116371426%20-17.426373666990653%20C-74.58584832796565%20-17.545583450037654%2C%20-74.35734549221704%20-17.664793233084655%2C%20-73.67767493308715%20-18.019376928432948%20C-73.41431990218342%20-18.135956388464603%2C%20-73.15096487127968%20-18.25253584849626%2C%20-72.50534027627411%20-18.53833470493208%20C-72.10502966388249%20-18.68565271072293%2C%20-71.70471905149088%20-18.832970716513778%2C%20-71.30216456784498%20-18.98111448766832%20C-70.90233108703815%20-19.09978296600302%2C%20-70.50249760623133%20-19.21845144433772%2C%20-70.07309191486611%20-19.345896799538448%20C-69.80868047182966%20-19.406246985965602%2C%20-69.54426902879321%20-19.466597172392753%2C%20-68.82317284050379%20-19.631182671777424%20C-68.40953187887476%20-19.698056934620038%2C%20-67.99589091724573%20-19.764931197462655%2C%20-67.55754353034142%20-19.83579980354259%20C-67.22881689581003%20-19.867511666624214%2C%20-66.90009026127863%20-19.899223529705836%2C%20-66.28140472669106%20-19.95890737914928%20C-65.8662005076597%20-19.97222217030763%2C%20-65.45099628862833%20-19.985536961465982%2C%20-65.00000035762787%20-19.999999523162842%20C-65.00000035762787%20-19.999999523162842%2C%20-65.00000035762787%20-19.999999523162842%2C%20-65.00000035762787%20-19.999999523162842%22%20stroke%3D%22none%22%20stroke-width%3D%220%22%20fill%3D%22%232c1740%22%20style%3D%22%22%2F%3E%3Cpath%20d%3D%22M-65.00000035762787%20-19.999999523162842%20C-13.678281742156344%20-19.999999523162842%2C%2037.64343687331518%20-19.999999523162842%2C%2065.00000035762787%20-19.999999523162842%20M-65.00000035762787%20-19.999999523162842%20C-37.429623710664174%20-19.999999523162842%2C%20-9.859247063700487%20-19.999999523162842%2C%2065.00000035762787%20-19.999999523162842%20M65.00000035762787%20-19.999999523162842%20C65.00000035762787%20-19.999999523162842%2C%2065.00000035762787%20-19.999999523162842%2C%2065.00000035762787%20-19.999999523162842%20M65.00000035762787%20-19.999999523162842%20C65.00000035762787%20-19.999999523162842%2C%2065.00000035762787%20-19.999999523162842%2C%2065.00000035762787%20-19.999999523162842%20M65.00000035762787%20-19.999999523162842%20C65.41552546205574%20-19.98667444183439%2C%2065.83105056648363%20-19.97334936050594%2C%2066.28140472669106%20-19.95890737914928%20M65.00000035762787%20-19.999999523162842%20C65.29399525639234%20-19.99057167898582%2C%2065.5879901551568%20-19.9811438348088%2C%2066.28140472669106%20-19.95890737914928%20M66.28140472669106%20-19.95890737914928%20C66.60136917051209%20-19.92804079406741%2C%2066.92133361433312%20-19.89717420898554%2C%2067.5575435303414%20-19.835799803542592%20M66.28140472669106%20-19.95890737914928%20C66.78487634030998%20-19.91033807809667%2C%2067.28834795392889%20-19.86176877704406%2C%2067.5575435303414%20-19.835799803542592%20M67.5575435303414%20-19.835799803542592%20C67.93380581746807%20-19.77496863491757%2C%2068.31006810459475%20-19.714137466292545%2C%2068.82317284050377%20-19.63118267177743%20M67.5575435303414%20-19.835799803542592%20C67.94261621631279%20-19.77354423795802%2C%2068.32768890228415%20-19.71128867237345%2C%2068.82317284050377%20-19.63118267177743%20M68.82317284050377%20-19.63118267177743%20C69.20489718652819%20-19.54405658078151%2C%2069.58662153255258%20-19.45693048978559%2C%2070.07309191486608%20-19.345896799538455%20M68.82317284050377%20-19.63118267177743%20C69.0746938927199%20-19.573774632937354%2C%2069.32621494493603%20-19.516366594097278%2C%2070.07309191486608%20-19.345896799538455%20M70.07309191486608%20-19.345896799538455%20C70.52723993706557%20-19.21110805042126%2C%2070.98138795926508%20-19.076319301304064%2C%2071.30216456784497%20-18.98111448766833%20M70.07309191486608%20-19.345896799538455%20C70.40125866940728%20-19.24849862937307%2C%2070.7294254239485%20-19.151100459207687%2C%2071.30216456784497%20-18.98111448766833%20M71.30216456784497%20-18.98111448766833%20C71.78161937736247%20-18.804670685734212%2C%2072.26107418687997%20-18.6282268838001%2C%2072.5053402762741%20-18.538334704932083%20M71.30216456784497%20-18.98111448766833%20C71.57033002512915%20-18.882427120493436%2C%2071.83849548241334%20-18.783739753318542%2C%2072.5053402762741%20-18.538334704932083%20M72.5053402762741%20-18.538334704932083%20C72.88169569547055%20-18.371733325040655%2C%2073.25805111466703%20-18.20513194514923%2C%2073.67767493308715%20-18.019376928432948%20M72.5053402762741%20-18.538334704932083%20C72.81649058575793%20-18.400597692869578%2C%2073.12764089524177%20-18.262860680807076%2C%2073.67767493308715%20-18.019376928432948%20M73.67767493308715%20-18.019376928432948%20C74.03239097518976%20-17.834321796474487%2C%2074.38710701729235%20-17.64926666451603%2C%2074.81435116371426%20-17.426373666990656%20M73.67767493308715%20-18.019376928432948%20C74.0653663709047%20-17.81711855365175%2C%2074.45305780872225%20-17.61486017887055%2C%2074.81435116371426%20-17.426373666990656%20M74.81435116371426%20-17.426373666990656%20C75.06091770605381%20-17.27690358003858%2C%2075.30748424839337%20-17.12743349308651%2C%2075.91069812170753%20-16.761761698205262%20M74.81435116371426%20-17.426373666990656%20C75.19149679185932%20-17.1977457708554%2C%2075.56864242000438%20-16.969117874720137%2C%2075.91069812170753%20-16.761761698205262%20M75.91069812170753%20-16.761761698205262%20C76.20431494454463%20-16.556947313061503%2C%2076.49793176738173%20-16.352132927917744%2C%2076.96221068225086%20-16.02827205521534%20M75.91069812170753%20-16.761761698205262%20C76.16786494215245%20-16.582373256835115%2C%2076.42503176259737%20-16.40298481546497%2C%2076.96221068225086%20-16.02827205521534%20M76.96221068225086%20-16.02827205521534%20C77.22599649328929%20-15.817909890547424%2C%2077.48978230432773%20-15.60754772587951%2C%2077.96456795468424%20-15.228918804296963%20M76.96221068225086%20-16.02827205521534%20C77.35273799297018%20-15.716836917284867%2C%2077.74326530368951%20-15.405401779354396%2C%2077.96456795468424%20-15.228918804296963%20M77.96456795468424%20-15.228918804296963%20C78.23699612105014%20-14.98150675165775%2C%2078.50942428741604%20-14.734094699018538%2C%2078.91365103797031%20-14.36698665941889%20M77.96456795468424%20-15.228918804296963%20C78.23729782421341%20-14.981232752827491%2C%2078.51002769374259%20-14.73354670135802%2C%2078.91365103797031%20-14.36698665941889%20M78.91365103797031%20-14.36698665941889%20C79.10584622910271%20-14.168529345056038%2C%2079.29804142023511%20-13.970072030693187%2C%2079.80555994614213%20-13.446017484648294%20M78.91365103797031%20-14.36698665941889%20C79.2268251863845%20-14.043608639105479%2C%2079.53999933479868%20-13.720230618792067%2C%2079.80555994614213%20-13.446017484648294%20M79.80555994614213%20-13.446017484648294%20C80.01103651395631%20-13.204653016145821%2C%2080.2165130817705%20-12.963288547643348%2C%2080.63662963418216%20-12.469795739871566%20M79.80555994614213%20-13.446017484648294%20C80.11963956707777%20-13.077081690260568%2C%2080.43371918801341%20-12.708145895872843%2C%2080.63662963418216%20-12.469795739871566%20M80.63662963418216%20-12.469795739871566%20C80.82966671813638%20-12.211143633413037%2C%2081.0227038020906%20-11.95249152695451%2C%2081.40344505847838%20-11.442332929636915%20M80.63662963418216%20-12.469795739871566%20C80.88450459765815%20-12.13766587068747%2C%2081.13237956113413%20-11.805536001503377%2C%2081.40344505847838%20-11.442332929636915%20M81.40344505847838%20-11.442332929636915%20C81.66980828191508%20-11.033127489897716%2C%2081.93617150535177%20-10.623922050158518%2C%2082.10285520997094%20-10.367851119021664%20M81.40344505847838%20-11.442332929636915%20C81.61045550762807%20-11.124309289654043%2C%2081.81746595677777%20-10.806285649671171%2C%2082.10285520997094%20-10.367851119021664%20M82.10285520997094%20-10.367851119021664%20C82.23595957318231%20-10.131510843861568%2C%2082.36906393639369%20-9.895170568701472%2C%2082.73198606232438%20-9.250765584261261%20M82.10285520997094%20-10.367851119021664%20C82.26686611196045%20-10.076633154634564%2C%2082.43087701394997%20-9.785415190247464%2C%2082.73198606232438%20-9.250765584261261%20M82.73198606232438%20-9.250765584261261%20C82.90057371472575%20-8.900689716851922%2C%2083.06916136712711%20-8.550613849442582%2C%2083.2882523819182%20-8.095666669432141%20M82.73198606232438%20-9.250765584261261%20C82.92593100082208%20-8.848034769713887%2C%2083.11987593931977%20-8.445303955166514%2C%2083.2882523819182%20-8.095666669432141%20M83.2882523819182%20-8.095666669432141%20C83.46945448534883%20-7.64809397065413%2C%2083.65065658877947%20-7.200521271876118%2C%2083.76936835112646%20-6.907300923743271%20M83.2882523819182%20-8.095666669432141%20C83.4649806447656%20-7.659144443390541%2C%2083.64170890761301%20-7.222622217348941%2C%2083.76936835112646%20-6.907300923743271%20M83.76936835112646%20-6.907300923743271%20C83.90174598331893%20-6.508600587090939%2C%2084.03412361551142%20-6.1099002504386055%2C%2084.17335696123263%20-5.690551596947329%20M83.76936835112646%20-6.907300923743271%20C83.91671321764268%20-6.463521662012764%2C%2084.0640580841589%20-6.019742400282256%2C%2084.17335696123263%20-5.690551596947329%20M84.17335696123263%20-5.690551596947329%20C84.25651754637329%20-5.373424243780422%2C%2084.33967813151393%20-5.056296890613515%2C%2084.49855813638248%20-4.45041857302004%20M84.17335696123263%20-5.690551596947329%20C84.2857332689231%20-5.262012031523745%2C%2084.39810957661355%20-4.833472466100162%2C%2084.49855813638248%20-4.45041857302004%20M84.49855813638248%20-4.45041857302004%20C84.58599938757956%20-4.001426228838027%2C%2084.67344063877664%20-3.552433884656014%2C%2084.74363555519191%20-3.1919978245644316%20M84.49855813638248%20-4.45041857302004%20C84.59409692224791%20-3.959847099730602%2C%2084.68963570811334%20-3.469275626441163%2C%2084.74363555519191%20-3.1919978245644316%20M84.74363555519191%20-3.1919978245644316%20C84.80061751962303%20-2.750056960798274%2C%2084.85759948405415%20-2.3081160970321166%2C%2084.90758214197808%20-1.9204604723662921%20M84.74363555519191%20-3.1919978245644316%20C84.77985140837993%20-2.911114818867336%2C%2084.81606726156794%20-2.6302318131702407%2C%2084.90758214197808%20-1.9204604723662921%20M84.90758214197808%20-1.9204604723662921%20C84.92653880639449%20-1.625195122536617%2C%2084.9454954708109%20-1.329929772706942%2C%2084.98972420504946%20-0.6410315361497202%20M84.90758214197808%20-1.9204604723662921%20C84.92920169737413%20-1.583718446081818%2C%2084.95082125277018%20-1.246976419797344%2C%2084.98972420504946%20-0.6410315361497202%20M84.98972420504946%20-0.6410315361497202%20C84.98972420504946%20-0.2796781878031116%2C%2084.98972420504946%200.081675160543497%2C%2084.98972420504946%200.6410315361497153%20M84.98972420504946%20-0.6410315361497202%20C84.98972420504946%20-0.35719695239417687%2C%2084.98972420504946%20-0.07336236863863355%2C%2084.98972420504946%200.6410315361497153%20M84.98972420504946%200.6410315361497153%20C84.96326707547972%201.0531226850090603%2C%2084.93680994590997%201.4652138338684053%2C%2084.90758214197808%201.9204604723662784%20M84.98972420504946%200.6410315361497153%20C84.97048590265084%200.9406836248863318%2C%2084.95124760025223%201.2403357136229483%2C%2084.90758214197808%201.9204604723662784%20M84.90758214197808%201.9204604723662784%20C84.86100333615579%202.281716492298458%2C%2084.81442453033348%202.642972512230638%2C%2084.74363555519191%203.191997824564418%20M84.90758214197808%201.9204604723662784%20C84.87299147746745%202.1887388356114434%2C%2084.83840081295682%202.457017198856609%2C%2084.74363555519191%203.191997824564418%20M84.74363555519191%203.191997824564418%20C84.64875491102565%203.6791898793269584%2C%2084.55387426685938%204.166381934089499%2C%2084.49855813638248%204.450418573020036%20M84.74363555519191%203.191997824564418%20C84.68621206980569%203.4868552855647668%2C%2084.62878858441945%203.781712746565116%2C%2084.49855813638248%204.450418573020036%20M84.49855813638248%204.450418573020036%20C84.4079497835752%204.795947492182713%2C%2084.31734143076793%205.1414764113453915%2C%2084.17335696123263%205.690551596947316%20M84.49855813638248%204.450418573020036%20C84.4141393891499%204.77234384353437%2C%2084.32972064191732%205.0942691140487035%2C%2084.17335696123263%205.690551596947316%20M84.17335696123263%205.690551596947316%20C84.05237402914835%206.054932912372659%2C%2083.93139109706408%206.419314227798003%2C%2083.76936835112646%206.907300923743258%20M84.17335696123263%205.690551596947316%20C84.05468282096356%206.047979199281264%2C%2083.9360086806945%206.4054068016152135%2C%2083.76936835112646%206.907300923743258%20M83.76936835112646%206.907300923743258%20C83.60941641525162%207.302385297814434%2C%2083.44946447937676%207.69746967188561%2C%2083.2882523819182%208.095666669432136%20M83.76936835112646%206.907300923743258%20C83.61131855073998%207.297686986382882%2C%2083.4532687503535%207.688073049022505%2C%2083.2882523819182%208.095666669432136%20M83.2882523819182%208.095666669432136%20C83.11293669825501%208.459713437713443%2C%2082.93762101459184%208.823760205994752%2C%2082.73198606232438%209.250765584261258%20M83.2882523819182%208.095666669432136%20C83.14819841771548%208.386491722773869%2C%2083.00814445351276%208.677316776115601%2C%2082.73198606232438%209.250765584261258%20M82.73198606232438%209.250765584261258%20C82.54848852801429%209.576584037569035%2C%2082.36499099370421%209.902402490876812%2C%2082.10285520997095%2010.36785111902166%20M82.73198606232438%209.250765584261258%20C82.53247516394187%209.605017387008566%2C%2082.33296426555937%209.959269189755872%2C%2082.10285520997095%2010.36785111902166%20M82.10285520997095%2010.36785111902166%20C81.8261030927469%2010.79301668942682%2C%2081.54935097552286%2011.21818225983198%2C%2081.40344505847838%2011.442332929636905%20M82.10285520997095%2010.36785111902166%20C81.84534652557925%2010.763453609011101%2C%2081.58783784118754%2011.159056099000544%2C%2081.40344505847838%2011.442332929636905%20M81.40344505847838%2011.442332929636905%20C81.20250092305959%2011.711579764710757%2C%2081.00155678764078%2011.980826599784608%2C%2080.63662963418216%2012.469795739871563%20M81.40344505847838%2011.442332929636905%20C81.13085197717233%2011.807582824846437%2C%2080.85825889586626%2012.172832720055968%2C%2080.63662963418216%2012.469795739871563%20M80.63662963418216%2012.469795739871563%20C80.39679729827867%2012.751516448470307%2C%2080.15696496237518%2013.03323715706905%2C%2079.80555994614213%2013.446017484648284%20M80.63662963418216%2012.469795739871563%20C80.3449593167284%2012.812408291263962%2C%2080.05328899927466%2013.155020842656361%2C%2079.80555994614213%2013.446017484648284%20M79.80555994614213%2013.446017484648284%20C79.55607433174292%2013.703631864665338%2C%2079.30658871734371%2013.961246244682393%2C%2078.91365103797031%2014.366986659418885%20M79.80555994614213%2013.446017484648284%20C79.61641336011184%2013.641326863948079%2C%2079.42726677408155%2013.836636243247874%2C%2078.91365103797031%2014.366986659418885%20M78.91365103797031%2014.366986659418885%20C78.65122335212632%2014.605316540246324%2C%2078.38879566628232%2014.843646421073762%2C%2077.96456795468427%2015.228918804296951%20M78.91365103797031%2014.366986659418885%20C78.57410729291038%2014.675351304847121%2C%2078.23456354785046%2014.983715950275357%2C%2077.96456795468427%2015.228918804296951%20M77.96456795468427%2015.228918804296951%20C77.64612541865849%2015.482868252665737%2C%2077.3276828826327%2015.736817701034525%2C%2076.96221068225087%2016.028272055215336%20M77.96456795468427%2015.228918804296951%20C77.71897358462564%2015.424773778878041%2C%2077.47337921456702%2015.62062875345913%2C%2076.96221068225087%2016.028272055215336%20M76.96221068225087%2016.028272055215336%20C76.7477085162016%2016.177899480602203%2C%2076.53320635015231%2016.327526905989068%2C%2075.91069812170754%2016.76176169820526%20M76.96221068225087%2016.028272055215336%20C76.56942769021262%2016.302260467159538%2C%2076.17664469817437%2016.576248879103744%2C%2075.91069812170754%2016.76176169820526%20M75.91069812170754%2016.76176169820526%20C75.6159437782723%2016.940443513364492%2C%2075.32118943483705%2017.119125328523726%2C%2074.81435116371426%2017.426373666990653%20M75.91069812170754%2016.76176169820526%20C75.49033765352159%2017.01658668433189%2C%2075.06997718533565%2017.271411670458527%2C%2074.81435116371426%2017.426373666990653%20M74.81435116371426%2017.426373666990653%20C74.492125942934%2017.594478358276614%2C%2074.16990072215374%2017.762583049562572%2C%2073.67767493308715%2018.019376928432948%20M74.81435116371426%2017.426373666990653%20C74.51241183428654%2017.58389522175173%2C%2074.2104725048588%2017.741416776512807%2C%2073.67767493308715%2018.019376928432948%20M73.67767493308715%2018.019376928432948%20C73.42133934678179%2018.13284908856533%2C%2073.16500376047644%2018.246321248697708%2C%2072.50534027627411%2018.53833470493208%20M73.67767493308715%2018.019376928432948%20C73.38309836142292%2018.149777238405175%2C%2073.08852178975869%2018.280177548377402%2C%2072.50534027627411%2018.53833470493208%20M72.50534027627411%2018.53833470493208%20C72.0713927030658%2018.69803142324013%2C%2071.63744512985748%2018.85772814154818%2C%2071.30216456784498%2018.98111448766832%20M72.50534027627411%2018.53833470493208%20C72.25657817406103%2018.629881458078156%2C%2072.00781607184796%2018.721428211224232%2C%2071.30216456784498%2018.98111448766832%20M71.30216456784498%2018.98111448766832%20C70.90196043069484%2019.0998929748601%2C%2070.50175629354472%2019.218671462051876%2C%2070.0730919148661%2019.34589679953845%20M71.30216456784498%2018.98111448766832%20C70.95871037395557%2019.083049889586846%2C%2070.61525618006617%2019.18498529150537%2C%2070.0730919148661%2019.34589679953845%20M70.0730919148661%2019.34589679953845%20C69.73886128769692%2019.422182759131143%2C%2069.40463066052776%2019.498468718723835%2C%2068.82317284050379%2019.631182671777427%20M70.0730919148661%2019.34589679953845%20C69.65198616471287%2019.442011439039096%2C%2069.23088041455964%2019.53812607853974%2C%2068.82317284050379%2019.631182671777427%20M68.82317284050379%2019.631182671777427%20C68.46140854457964%2019.689669917618428%2C%2068.09964424865551%2019.748157163459425%2C%2067.55754353034142%2019.83579980354259%20M68.82317284050379%2019.631182671777427%20C68.43179050789318%2019.69445833209859%2C%2068.04040817528256%2019.75773399241975%2C%2067.55754353034142%2019.83579980354259%20M67.55754353034142%2019.83579980354259%20C67.21265237098847%2019.86907103889306%2C%2066.86776121163552%2019.902342274243537%2C%2066.28140472669106%2019.95890737914928%20M67.55754353034142%2019.83579980354259%20C67.06968791368178%2019.882862648149523%2C%2066.58183229702212%2019.92992549275646%2C%2066.28140472669106%2019.95890737914928%20M66.28140472669106%2019.95890737914928%20C65.77231548760336%2019.975232880164732%2C%2065.26322624851566%2019.991558381180184%2C%2065.00000035762787%2019.999999523162842%20M66.28140472669106%2019.95890737914928%20C65.91350923821653%2019.970705071399532%2C%2065.545613749742%2019.982502763649784%2C%2065.00000035762787%2019.999999523162842%20M65.00000035762787%2019.999999523162842%20C65.00000035762787%2019.999999523162842%2C%2065.00000035762787%2019.999999523162842%2C%2065.00000035762787%2019.999999523162842%20M65.00000035762787%2019.999999523162842%20C65.00000035762787%2019.999999523162842%2C%2065.00000035762787%2019.999999523162842%2C%2065.00000035762787%2019.999999523162842%20M65.00000035762787%2019.999999523162842%20C28.940612216739638%2019.999999523162842%2C%20-7.1187759241485935%2019.999999523162842%2C%20-65.00000035762787%2019.999999523162842%20M65.00000035762787%2019.999999523162842%20C34.63006504951434%2019.999999523162842%2C%204.26012974140081%2019.999999523162842%2C%20-65.00000035762787%2019.999999523162842%20M-65.00000035762787%2019.999999523162842%20C-65.3140811501289%2019.98992756346851%2C%20-65.62816194262993%2019.979855603774176%2C%20-66.28140472669105%2019.95890737914928%20M-65.00000035762787%2019.999999523162842%20C-65.31804068023695%2019.9898005890447%2C%20-65.63608100284603%2019.97960165492656%2C%20-66.28140472669105%2019.95890737914928%20M-66.28140472669105%2019.95890737914928%20C-66.59726044566708%2019.928437157811743%2C%20-66.91311616464309%2019.897966936474205%2C%20-67.5575435303414%2019.83579980354259%20M-66.28140472669105%2019.95890737914928%20C-66.63733570064576%2019.924571146161494%2C%20-66.99326667460046%2019.89023491317371%2C%20-67.5575435303414%2019.83579980354259%20M-67.5575435303414%2019.83579980354259%20C-68.02724951256852%2019.759861382960406%2C%20-68.49695549479563%2019.683922962378222%2C%20-68.82317284050377%2019.631182671777427%20M-67.5575435303414%2019.83579980354259%20C-67.90433254158653%2019.779733645593428%2C%20-68.25112155283165%2019.723667487644263%2C%20-68.82317284050377%2019.631182671777427%20M-68.82317284050377%2019.631182671777427%20C-69.1878821407632%2019.547940153943816%2C%20-69.55259144102261%2019.46469763611021%2C%20-70.07309191486608%2019.345896799538455%20M-68.82317284050377%2019.631182671777427%20C-69.15011768679445%2019.55655964412609%2C%20-69.47706253308512%2019.481936616474755%2C%20-70.07309191486608%2019.345896799538455%20M-70.07309191486608%2019.345896799538455%20C-70.34264882703499%2019.26589372293983%2C%20-70.6122057392039%2019.185890646341203%2C%20-71.30216456784497%2018.981114487668332%20M-70.07309191486608%2019.345896799538455%20C-70.43014018929715%2019.23992674587195%2C%20-70.78718846372821%2019.13395669220545%2C%20-71.30216456784497%2018.981114487668332%20M-71.30216456784497%2018.981114487668332%20C-71.7528600261073%2018.81525439284465%2C%20-72.20355548436963%2018.649394298020965%2C%20-72.5053402762741%2018.538334704932083%20M-71.30216456784497%2018.981114487668332%20C-71.59326616955424%2018.873986407325614%2C%20-71.88436777126351%2018.76685832698289%2C%20-72.5053402762741%2018.538334704932083%20M-72.5053402762741%2018.538334704932083%20C-72.76130545760947%2018.425026512092238%2C%20-73.01727063894485%2018.311718319252396%2C%20-73.67767493308713%2018.01937692843295%20M-72.5053402762741%2018.538334704932083%20C-72.8257826002838%2018.396484393676793%2C%20-73.14622492429352%2018.2546340824215%2C%20-73.67767493308713%2018.01937692843295%20M-73.67767493308713%2018.01937692843295%20C-73.91041975816594%2017.89795410226951%2C%20-74.14316458324475%2017.77653127610607%2C%20-74.81435116371425%2017.426373666990656%20M-73.67767493308713%2018.01937692843295%20C-73.94469515584204%2017.88007264925633%2C%20-74.21171537859695%2017.740768370079707%2C%20-74.81435116371425%2017.426373666990656%20M-74.81435116371425%2017.426373666990656%20C-75.06557198205434%2017.274082130575493%2C%20-75.31679280039444%2017.121790594160327%2C%20-75.91069812170751%2016.76176169820527%20M-74.81435116371425%2017.426373666990656%20C-75.07024071880257%2017.27125191492218%2C%20-75.32613027389088%2017.1161301628537%2C%20-75.91069812170751%2016.76176169820527%20M-75.91069812170751%2016.76176169820527%20C-76.14442870821902%2016.598721359088852%2C%20-76.37815929473054%2016.43568101997244%2C%20-76.96221068225086%2016.02827205521534%20M-75.91069812170751%2016.76176169820527%20C-76.13009888642173%2016.608717222446653%2C%20-76.34949965113597%2016.455672746688037%2C%20-76.96221068225086%2016.02827205521534%20M-76.96221068225086%2016.02827205521534%20C-77.27472829809291%2015.779047573024332%2C%20-77.58724591393495%2015.529823090833325%2C%20-77.96456795468424%2015.228918804296965%20M-76.96221068225086%2016.02827205521534%20C-77.29540819035059%2015.762555909263881%2C%20-77.6286056984503%2015.496839763312423%2C%20-77.96456795468424%2015.228918804296965%20M-77.96456795468424%2015.228918804296965%20C-78.26448744507644%2014.956539858557644%2C%20-78.56440693546863%2014.68416091281832%2C%20-78.9136510379703%2014.366986659418899%20M-77.96456795468424%2015.228918804296965%20C-78.30168758772122%2014.922755673269496%2C%20-78.63880722075818%2014.616592542242024%2C%20-78.9136510379703%2014.366986659418899%20M-78.9136510379703%2014.366986659418899%20C-79.2004195380642%2014.070874638940225%2C%20-79.48718803815811%2013.774762618461551%2C%20-79.80555994614213%2013.446017484648289%20M-78.9136510379703%2014.366986659418899%20C-79.1347795873958%2014.138653277145519%2C%20-79.35590813682131%2013.910319894872137%2C%20-79.80555994614213%2013.446017484648289%20M-79.80555994614213%2013.446017484648289%20C-80.10167343191095%2013.098185734929567%2C%20-80.39778691767977%2012.750353985210843%2C%20-80.63662963418216%2012.469795739871568%20M-79.80555994614213%2013.446017484648289%20C-80.04812716621814%2013.161084225481169%2C%20-80.29069438629416%2012.87615096631405%2C%20-80.63662963418216%2012.469795739871568%20M-80.63662963418216%2012.469795739871568%20C-80.83485867019628%2012.204186890649341%2C%20-81.0330877062104%2011.938578041427116%2C%20-81.40344505847838%2011.442332929636917%20M-80.63662963418216%2012.469795739871568%20C-80.81180685351939%2012.235074224932676%2C%20-80.98698407285661%2012.000352709993784%2C%20-81.40344505847838%2011.442332929636917%20M-81.40344505847838%2011.442332929636917%20C-81.66275115823171%2011.04396912697841%2C%20-81.92205725798505%2010.645605324319902%2C%20-82.10285520997094%2010.367851119021672%20M-81.40344505847838%2011.442332929636917%20C-81.59235141911111%2011.152122031244556%2C%20-81.78125777974384%2010.861911132852196%2C%20-82.10285520997094%2010.367851119021672%20M-82.10285520997094%2010.367851119021672%20C-82.3321408315526%209.960731280216606%2C%20-82.56142645313427%209.55361144141154%2C%20-82.73198606232438%209.250765584261263%20M-82.10285520997094%2010.367851119021672%20C-82.2871105830982%2010.0406870461545%2C%20-82.47136595622547%209.713522973287327%2C%20-82.73198606232438%209.250765584261263%20M-82.73198606232438%209.250765584261263%20C-82.86180044827103%208.981203234260137%2C%20-82.99161483421769%208.711640884259014%2C%20-83.2882523819182%208.095666669432145%20M-82.73198606232438%209.250765584261263%20C-82.8830101543263%208.937160825821378%2C%20-83.0340342463282%208.623556067381495%2C%20-83.2882523819182%208.095666669432145%20M-83.2882523819182%208.095666669432145%20C-83.42194443179686%207.765444721471895%2C%20-83.55563648167553%207.435222773511645%2C%20-83.76936835112646%206.907300923743273%20M-83.2882523819182%208.095666669432145%20C-83.47742724978312%207.628401088358529%2C%20-83.66660211764804%207.1611355072849125%2C%20-83.76936835112646%206.907300923743273%20M-83.76936835112646%206.907300923743273%20C-83.92684470083637%206.433007248865996%2C%20-84.08432105054628%205.958713573988719%2C%20-84.17335696123263%205.690551596947323%20M-83.76936835112646%206.907300923743273%20C-83.87451091467904%206.590628274515412%2C%20-83.97965347823163%206.2739556252875515%2C%20-84.17335696123263%205.690551596947323%20M-84.17335696123263%205.690551596947323%20C-84.25721753320279%205.370754890623304%2C%20-84.34107810517294%205.050958184299285%2C%20-84.49855813638248%204.450418573020043%20M-84.17335696123263%205.690551596947323%20C-84.25945667467913%205.362216073723978%2C%20-84.34555638812562%205.0338805505006325%2C%20-84.49855813638248%204.450418573020043%20M-84.49855813638248%204.450418573020043%20C-84.59648453822972%203.947587196286895%2C%20-84.69441094007693%203.4447558195537473%2C%20-84.74363555519191%203.191997824564434%20M-84.49855813638248%204.450418573020043%20C-84.54801559048342%204.196464999048405%2C%20-84.59747304458435%203.9425114250767663%2C%20-84.74363555519191%203.191997824564434%20M-84.74363555519191%203.191997824564434%20C-84.80256711470842%202.734936286307034%2C%20-84.86149867422495%202.2778747480496335%2C%20-84.90758214197808%201.9204604723663035%20M-84.74363555519191%203.191997824564434%20C-84.7814708323476%202.8985548863655377%2C%20-84.81930610950327%202.6051119481666416%2C%20-84.90758214197808%201.9204604723663035%20M-84.90758214197808%201.9204604723663035%20C-84.92792703210166%201.6035723865917406%2C%20-84.94827192222525%201.286684300817178%2C%20-84.98972420504946%200.6410315361497226%20M-84.90758214197808%201.9204604723663035%20C-84.93236146808762%201.5345024666982134%2C%20-84.95714079419716%201.1485444610301234%2C%20-84.98972420504946%200.6410315361497226%20M-84.98972420504946%200.6410315361497226%20C-84.98972420504946%200.20275328369317275%2C%20-84.98972420504946%20-0.23552496876337714%2C%20-84.98972420504946%20-0.641031536149713%20M-84.98972420504946%200.6410315361497226%20C-84.98972420504946%200.24391275036911492%2C%20-84.98972420504946%20-0.1532060354114928%2C%20-84.98972420504946%20-0.641031536149713%20M-84.98972420504946%20-0.641031536149713%20C-84.95972358754946%20-1.1083153697747798%2C%20-84.92972297004945%20-1.5755992033998467%2C%20-84.90758214197808%20-1.920460472366276%20M-84.98972420504946%20-0.641031536149713%20C-84.96986159802239%20-0.9504076734041562%2C%20-84.94999899099531%20-1.2597838106585995%2C%20-84.90758214197808%20-1.920460472366276%20M-84.90758214197808%20-1.920460472366276%20C-84.86406102493945%20-2.2580016619013317%2C%20-84.82053990790081%20-2.595542851436387%2C%20-84.74363555519191%20-3.1919978245644245%20M-84.90758214197808%20-1.920460472366276%20C-84.86039248344471%20-2.286454145299063%2C%20-84.81320282491133%20-2.6524478182318503%2C%20-84.74363555519191%20-3.1919978245644245%20M-84.74363555519191%20-3.1919978245644245%20C-84.6585186768611%20-3.629055005334531%2C%20-84.5734017985303%20-4.066112186104638%2C%20-84.49855813638248%20-4.450418573020033%20M-84.74363555519191%20-3.1919978245644245%20C-84.6792287754419%20-3.522713026203041%2C%20-84.61482199569188%20-3.8534282278416576%2C%20-84.49855813638248%20-4.450418573020033%20M-84.49855813638248%20-4.450418573020033%20C-84.38956614234282%20-4.866052283722328%2C%20-84.28057414830315%20-5.281685994424622%2C%20-84.17335696123263%20-5.690551596947313%20M-84.49855813638248%20-4.450418573020033%20C-84.39985503420328%20-4.826816279824403%2C%20-84.30115193202408%20-5.203213986628771%2C%20-84.17335696123263%20-5.690551596947313%20M-84.17335696123263%20-5.690551596947313%20C-84.03977980250818%20-6.092864716395349%2C%20-83.90620264378374%20-6.495177835843384%2C%20-83.76936835112647%20-6.9073009237432474%20M-84.17335696123263%20-5.690551596947313%20C-84.03360362044545%20-6.111466392727311%2C%20-83.89385027965828%20-6.532381188507309%2C%20-83.76936835112647%20-6.9073009237432474%20M-83.76936835112647%20-6.9073009237432474%20C-83.64123238079661%20-7.223799247798476%2C%20-83.51309641046673%20-7.540297571853705%2C%20-83.2882523819182%20-8.095666669432134%20M-83.76936835112647%20-6.9073009237432474%20C-83.60546326194071%20-7.312149662921393%2C%20-83.44155817275495%20-7.71699840209954%2C%20-83.2882523819182%20-8.095666669432134%20M-83.2882523819182%20-8.095666669432134%20C-83.16206228303537%20-8.357703109797928%2C%20-83.03587218415252%20-8.61973955016372%2C%20-82.73198606232438%20-9.250765584261254%20M-83.2882523819182%20-8.095666669432134%20C-83.13155878849636%20-8.42104426887838%2C%20-82.97486519507453%20-8.746421868324624%2C%20-82.73198606232438%20-9.250765584261254%20M-82.73198606232438%20-9.250765584261254%20C-82.50300092656353%20-9.657351880063983%2C%20-82.27401579080268%20-10.063938175866713%2C%20-82.10285520997094%20-10.367851119021667%20M-82.73198606232438%20-9.250765584261254%20C-82.48529972910218%20-9.688782148597213%2C%20-82.23861339587998%20-10.126798712933171%2C%20-82.10285520997094%20-10.367851119021667%20M-82.10285520997094%20-10.367851119021667%20C-81.8506384250029%20-10.75532383042239%2C%20-81.59842164003487%20-11.142796541823111%2C%20-81.40344505847838%20-11.44233292963691%20M-82.10285520997094%20-10.367851119021667%20C-81.92852523033703%20-10.635668781893495%2C%20-81.7541952507031%20-10.903486444765324%2C%20-81.40344505847838%20-11.44233292963691%20M-81.40344505847838%20-11.44233292963691%20C-81.12980715967825%20-11.80898278510368%2C%20-80.8561692608781%20-12.17563264057045%2C%20-80.63662963418217%20-12.469795739871563%20M-81.40344505847838%20-11.44233292963691%20C-81.22075837804834%20-11.687116438314193%2C%20-81.0380716976183%20-11.931899946991475%2C%20-80.63662963418217%20-12.469795739871563%20M-80.63662963418217%20-12.469795739871563%20C-80.45251710521774%20-12.686064792692855%2C%20-80.26840457625332%20-12.902333845514148%2C%20-79.80555994614213%20-13.446017484648284%20M-80.63662963418217%20-12.469795739871563%20C-80.46232356357383%20-12.67454556870451%2C%20-80.28801749296548%20-12.879295397537456%2C%20-79.80555994614213%20-13.446017484648284%20M-79.80555994614213%20-13.446017484648284%20C-79.62168542103218%20-13.635883028203565%2C%20-79.43781089592224%20-13.825748571758847%2C%20-78.91365103797031%20-14.366986659418878%20M-79.80555994614213%20-13.446017484648284%20C-79.55426323668358%20-13.705501969007775%2C%20-79.30296652722504%20-13.964986453367265%2C%20-78.91365103797031%20-14.366986659418878%20M-78.91365103797031%20-14.366986659418878%20C-78.62821555374671%20-14.62621161398169%2C%20-78.34278006952312%20-14.8854365685445%2C%20-77.96456795468427%20-15.228918804296947%20M-78.91365103797031%20-14.366986659418878%20C-78.69179106111991%20-14.568474020301087%2C%20-78.46993108426953%20-14.769961381183297%2C%20-77.96456795468427%20-15.228918804296947%20M-77.96456795468427%20-15.228918804296947%20C-77.67792560969737%20-15.457508446550849%2C%20-77.39128326471047%20-15.686098088804751%2C%20-76.96221068225087%20-16.028272055215332%20M-77.96456795468427%20-15.228918804296947%20C-77.67763107487289%20-15.457743330235475%2C%20-77.3906941950615%20-15.686567856174001%2C%20-76.96221068225087%20-16.028272055215332%20M-76.96221068225087%20-16.028272055215332%20C-76.62437269314181%20-16.26393321164697%2C%20-76.28653470403276%20-16.49959436807861%2C%20-75.91069812170754%20-16.761761698205255%20M-76.96221068225087%20-16.028272055215332%20C-76.58674828175035%20-16.290178372299142%2C%20-76.21128588124982%20-16.55208468938295%2C%20-75.91069812170754%20-16.761761698205255%20M-75.91069812170754%20-16.761761698205255%20C-75.5271911832265%20-16.994245858049393%2C%20-75.14368424474547%20-17.22673001789353%2C%20-74.81435116371426%20-17.426373666990653%20M-75.91069812170754%20-16.761761698205255%20C-75.66300229064763%20-16.911916366616055%2C%20-75.4153064595877%20-17.062071035026854%2C%20-74.81435116371426%20-17.426373666990653%20M-74.81435116371426%20-17.426373666990653%20C-74.43437494527272%20-17.62460701676522%2C%20-74.05439872683118%20-17.82284036653979%2C%20-73.67767493308715%20-18.019376928432948%20M-74.81435116371426%20-17.426373666990653%20C-74.4777065252511%20-17.602000959245704%2C%20-74.14106188678794%20-17.777628251500754%2C%20-73.67767493308715%20-18.019376928432948%20M-73.67767493308715%20-18.019376928432948%20C-73.37940221235048%20-18.15141341395718%2C%20-73.08112949161381%20-18.283449899481408%2C%20-72.50534027627411%20-18.53833470493208%20M-73.67767493308715%20-18.019376928432948%20C-73.43183149755451%20-18.128204524656837%2C%20-73.18598806202189%20-18.237032120880727%2C%20-72.50534027627411%20-18.53833470493208%20M-72.50534027627411%20-18.53833470493208%20C-72.06692222866226%20-18.699676599145246%2C%20-71.62850418105042%20-18.861018493358408%2C%20-71.30216456784498%20-18.98111448766832%20M-72.50534027627411%20-18.53833470493208%20C-72.13528461747032%20-18.67451860812889%2C%20-71.76522895866651%20-18.810702511325694%2C%20-71.30216456784498%20-18.98111448766832%20M-71.30216456784498%20-18.98111448766832%20C-70.89911941354269%20-19.100736173838058%2C%20-70.4960742592404%20-19.22035786000779%2C%20-70.07309191486611%20-19.345896799538448%20M-71.30216456784498%20-18.98111448766832%20C-70.91169342693775%20-19.097004272664748%2C%20-70.52122228603051%20-19.212894057661174%2C%20-70.07309191486611%20-19.345896799538448%20M-70.07309191486611%20-19.345896799538448%20C-69.60870573773799%20-19.451889914064928%2C%20-69.14431956060987%20-19.557883028591412%2C%20-68.82317284050379%20-19.631182671777424%20M-70.07309191486611%20-19.345896799538448%20C-69.72401792031144%20-19.425570660874854%2C%20-69.37494392575678%20-19.50524452221126%2C%20-68.82317284050379%20-19.631182671777424%20M-68.82317284050379%20-19.631182671777424%20C-68.42852779108458%20-19.694985822849457%2C%20-68.03388274166537%20-19.758788973921487%2C%20-67.55754353034142%20-19.83579980354259%20M-68.82317284050379%20-19.631182671777424%20C-68.56384135337247%20-19.673109375471096%2C%20-68.30450986624115%20-19.71503607916477%2C%20-67.55754353034142%20-19.83579980354259%20M-67.55754353034142%20-19.83579980354259%20C-67.06654828677422%20-19.88316552418134%2C%20-66.57555304320702%20-19.930531244820095%2C%20-66.28140472669106%20-19.95890737914928%20M-67.55754353034142%20-19.83579980354259%20C-67.0662887878274%20-19.883190557732647%2C%20-66.5750340453134%20-19.930581311922708%2C%20-66.28140472669106%20-19.95890737914928%20M-66.28140472669106%20-19.95890737914928%20C-65.95566500969427%20-19.96935321785947%2C%20-65.62992529269746%20-19.979799056569664%2C%20-65.00000035762787%20-19.999999523162842%20M-66.28140472669106%20-19.95890737914928%20C-65.97551447574833%20-19.968716684117762%2C%20-65.66962422480557%20-19.97852598908624%2C%20-65.00000035762787%20-19.999999523162842%20M-65.00000035762787%20-19.999999523162842%20C-65.00000035762787%20-19.999999523162842%2C%20-65.00000035762787%20-19.999999523162842%2C%20-65.00000035762787%20-19.999999523162842%20M-65.00000035762787%20-19.999999523162842%20C-65.00000035762787%20-19.999999523162842%2C%20-65.00000035762787%20-19.999999523162842%2C%20-65.00000035762787%20-19.999999523162842%22%20stroke%3D%22%239333ea%22%20stroke-width%3D%221.3%22%20fill%3D%22none%22%20stroke-dasharray%3D%220%200%22%20style%3D%22%22%2F%3E%3C%2Fg%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3ESign%3C%2Ftspan%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3E%20in%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cdefs%3E%3Cfilter%20id%3D%22coddy-mermaid-2-drop-shadow%22%20height%3D%22130%25%22%20width%3D%22130%25%22%3E%3CfeDropShadow%20dx%3D%224%22%20dy%3D%224%22%20stdDeviation%3D%220%22%20flood-opacity%3D%220.06%22%20flood-color%3D%22%23000000%22%2F%3E%3C%2Ffilter%3E%3C%2Fdefs%3E%3Cdefs%3E%3Cfilter%20id%3D%22coddy-mermaid-2-drop-shadow-small%22%20height%3D%22150%25%22%20width%3D%22150%25%22%3E%3CfeDropShadow%20dx%3D%222%22%20dy%3D%222%22%20stdDeviation%3D%220%22%20flood-opacity%3D%220.06%22%20flood-color%3D%22%23000000%22%2F%3E%3C%2Ffilter%3E%3C%2Fdefs%3E%3C%2Fsvg%3E\"></button></figure></div>","mermaid-refund":"<div class=\"md\"><figure class=\"md-figure\" data-testid=\"md-figure\" data-kind=\"mermaid\" data-view=\"picture\"><div class=\"md-figure-head\"><span class=\"md-figure-label\">Mermaid diagram</span><div class=\"md-figure-actions\"><button type=\"button\" class=\"md-copy md-figure-format\" title=\"Download the source (.mmd)\" aria-label=\"Download the source (.mmd)\" data-testid=\"md-figure-download-mmd\"><span aria-hidden=\"true\">MMD</span></button><button type=\"button\" class=\"md-copy md-figure-format\" title=\"Download as SVG (.svg)\" aria-label=\"Download as SVG (.svg)\" data-testid=\"md-figure-download-svg\"><span aria-hidden=\"true\">SVG</span></button><button type=\"button\" class=\"md-copy md-figure-source-toggle\" aria-pressed=\"false\" title=\"Show the source code\" aria-label=\"Show the source code\" data-testid=\"md-figure-source-toggle\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" class=\"md-copy__glyph\"><path d=\"M5.5 4L1.5 8l4 4M10.5 4l4 4-4 4\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></button></div></div><button type=\"button\" class=\"md-figure-picture\" aria-label=\"Open the picture\" title=\"Open the picture\"><img alt=\"Mermaid diagram\" width=\"552\" height=\"402\" data-testid=\"md-figure-img\" src=\"data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20id%3D%22coddy-mermaid-3%22%20width%3D%22552%22%20class%3D%22flowchart%22%20viewBox%3D%224%204%20552%20402%22%20role%3D%22graphics-document%20document%22%20aria-roledescription%3D%22flowchart-v2%22%20height%3D%22402%22%3E%3Cstyle%3E%23coddy-mermaid-3%7Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bfont-size%3A14px%3Bfill%3A%23ffffff%3B%7D%40keyframes%20edge-animation-frame%7Bfrom%7Bstroke-dashoffset%3A0%3B%7D%7D%40keyframes%20dash%7Bto%7Bstroke-dashoffset%3A0%3B%7D%7D%23coddy-mermaid-3%20.edge-animation-slow%7Bstroke-dasharray%3A9%2C5!important%3Bstroke-dashoffset%3A900%3Banimation%3Adash%2050s%20linear%20infinite%3Bstroke-linecap%3Around%3B%7D%23coddy-mermaid-3%20.edge-animation-fast%7Bstroke-dasharray%3A9%2C5!important%3Bstroke-dashoffset%3A900%3Banimation%3Adash%2020s%20linear%20infinite%3Bstroke-linecap%3Around%3B%7D%23coddy-mermaid-3%20.error-icon%7Bfill%3A%2327303b%3B%7D%23coddy-mermaid-3%20.error-text%7Bfill%3A%23ffffff%3Bstroke%3A%23ffffff%3B%7D%23coddy-mermaid-3%20.edge-thickness-normal%7Bstroke-width%3A1px%3B%7D%23coddy-mermaid-3%20.edge-thickness-thick%7Bstroke-width%3A3.5px%3B%7D%23coddy-mermaid-3%20.edge-pattern-solid%7Bstroke-dasharray%3A0%3B%7D%23coddy-mermaid-3%20.edge-thickness-invisible%7Bstroke-width%3A0%3Bfill%3Anone%3B%7D%23coddy-mermaid-3%20.edge-pattern-dashed%7Bstroke-dasharray%3A3%3B%7D%23coddy-mermaid-3%20.edge-pattern-dotted%7Bstroke-dasharray%3A2%3B%7D%23coddy-mermaid-3%20.marker%7Bfill%3A%23b7b7b7%3Bstroke%3A%23b7b7b7%3B%7D%23coddy-mermaid-3%20.marker.cross%7Bstroke%3A%23b7b7b7%3B%7D%23coddy-mermaid-3%20svg%7Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bfont-size%3A14px%3B%7D%23coddy-mermaid-3%20p%7Bmargin%3A0%3B%7D%23coddy-mermaid-3%20.label%7Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-3%20.cluster-label%20text%7Bfill%3A%23ffffff%3B%7D%23coddy-mermaid-3%20.cluster-label%20span%7Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-3%20.cluster-label%20span%20p%7Bbackground-color%3Atransparent%3B%7D%23coddy-mermaid-3%20.label%20text%2C%23coddy-mermaid-3%20span%7Bfill%3A%23ffffff%3Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-3%20.node%20rect%2C%23coddy-mermaid-3%20.node%20circle%2C%23coddy-mermaid-3%20.node%20ellipse%2C%23coddy-mermaid-3%20.node%20polygon%2C%23coddy-mermaid-3%20.node%20path%7Bfill%3A%232c1740%3Bstroke%3A%239333ea%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-3%20.rough-node%20.label%20text%2C%23coddy-mermaid-3%20.node%20.label%20text%2C%23coddy-mermaid-3%20.image-shape%20.label%2C%23coddy-mermaid-3%20.icon-shape%20.label%7Btext-anchor%3Amiddle%3B%7D%23coddy-mermaid-3%20.node%20.katex%20path%7Bfill%3A%23000%3Bstroke%3A%23000%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-3%20.rough-node%20.label%2C%23coddy-mermaid-3%20.node%20.label%2C%23coddy-mermaid-3%20.image-shape%20.label%2C%23coddy-mermaid-3%20.icon-shape%20.label%7Btext-align%3Acenter%3B%7D%23coddy-mermaid-3%20.node.clickable%7Bcursor%3Apointer%3B%7D%23coddy-mermaid-3%20.root%20.anchor%20path%7Bfill%3A%23b7b7b7!important%3Bstroke-width%3A0%3Bstroke%3A%23b7b7b7%3B%7D%23coddy-mermaid-3%20.arrowheadPath%7Bfill%3A%23b7b7b7%3B%7D%23coddy-mermaid-3%20.edgePaths%20.path%7Bstroke%3A%23b7b7b7%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-3%20.flowchart-link%7Bstroke%3A%23b7b7b7%3Bfill%3Anone%3B%7D%23coddy-mermaid-3%20.edgeLabel%7Bbackground-color%3A%230f0f10%3Btext-align%3Acenter%3B%7D%23coddy-mermaid-3%20.edgeLabel%20p%7Bbackground-color%3A%230f0f10%3B%7D%23coddy-mermaid-3%20.edgeLabel%20rect%7Bopacity%3A0.5%3Bbackground-color%3A%230f0f10%3Bfill%3A%230f0f10%3B%7D%23coddy-mermaid-3%20.labelBkg%7Bbackground-color%3Argba(15%2C%2015%2C%2016%2C%200.5)%3B%7D%23coddy-mermaid-3%20.cluster%20rect%7Bfill%3A%231b1b1c%3Bstroke%3A%234b4b4c%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-3%20.cluster%20text%7Bfill%3A%23ffffff%3B%7D%23coddy-mermaid-3%20.cluster%20span%7Bcolor%3A%23ffffff%3B%7D%23coddy-mermaid-3%20.node%20.collapsed-indicator%7Bfill%3A%234b4b4c%3Bstroke%3Anone%3Bopacity%3A0.6%3B%7D%23coddy-mermaid-3%20.node%20.collapsed-separator%7Bstroke%3A%234b4b4c%3Bstroke-width%3A0.75px%3B%7D%23coddy-mermaid-3%20div.mermaidTooltip%7Bposition%3Aabsolute%3Btext-align%3Acenter%3Bmax-width%3A200px%3Bpadding%3A2px%3Bfont-family%3Asystem-ui%2C-apple-system%2C%22Segoe%20UI%22%2Csans-serif%3Bfont-size%3A12px%3Bbackground%3A%2327303b%3Bborder%3A1px%20solid%20%2393c5fd%3Bborder-radius%3A2px%3Bpointer-events%3Anone%3Bz-index%3A100%3B%7D%23coddy-mermaid-3%20.flowchartTitleText%7Btext-anchor%3Amiddle%3Bfont-size%3A18px%3Bfill%3A%23ffffff%3B%7D%23coddy-mermaid-3%20rect.text%7Bfill%3Anone%3Bstroke-width%3A0%3B%7D%23coddy-mermaid-3%20.icon-shape%2C%23coddy-mermaid-3%20.image-shape%7Bbackground-color%3A%230f0f10%3Btext-align%3Acenter%3B%7D%23coddy-mermaid-3%20.icon-shape%20p%2C%23coddy-mermaid-3%20.image-shape%20p%7Bbackground-color%3A%230f0f10%3Bpadding%3A2px%3B%7D%23coddy-mermaid-3%20.icon-shape%20.label%20rect%2C%23coddy-mermaid-3%20.image-shape%20.label%20rect%7Bopacity%3A0.5%3Bbackground-color%3A%230f0f10%3Bfill%3A%230f0f10%3B%7D%23coddy-mermaid-3%20.label-icon%7Bdisplay%3Ainline-block%3Bheight%3A1em%3Boverflow%3Avisible%3Bvertical-align%3A-0.125em%3B%7D%23coddy-mermaid-3%20.node%20.label-icon%20path%7Bfill%3AcurrentColor%3Bstroke%3Arevert%3Bstroke-width%3Arevert%3B%7D%23coddy-mermaid-3%20.node%20.neo-node%7Bstroke%3A%239333ea%3B%7D%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.node%20rect%2C%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.cluster%20rect%2C%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.node%20polygon%7Bstroke%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.swimlane.cluster%20rect%7Bfilter%3Anone%3B%7D%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.node%20path%7Bstroke%3A%239333ea%3Bstroke-width%3A1px%3B%7D%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.node%20.outer-path%7Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.node%20.neo-line%20path%7Bstroke%3A%239333ea%3Bfilter%3Anone%3B%7D%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.node%20circle%7Bstroke%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.node%20circle%20.state-start%7Bfill%3A%23000000%3B%7D%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.icon-shape%20.icon%7Bfill%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-3%20%5Bdata-look%3D%22neo%22%5D.icon-shape%20.icon-neo%20path%7Bstroke%3A%239333ea%3Bfilter%3Adrop-shadow(%201px%202px%202px%20rgba(185%2C185%2C185%2C1))%3B%7D%23coddy-mermaid-3%20.mindmap-node.section-root%20text%7Btext-anchor%3Amiddle%3B%7D%23coddy-mermaid-3%20%3Aroot%7B--mermaid-font-family%3A%22trebuchet%20ms%22%2Cverdana%2Carial%2Csans-serif%3B%7D%3C%2Fstyle%3E%3Cg%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-pointEnd%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%225%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%228%22%20markerHeight%3D%228%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%200%200%20L%2010%205%20L%200%2010%20z%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-pointStart%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%224.5%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%228%22%20markerHeight%3D%228%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%200%205%20L%2010%2010%20L%2010%200%20z%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-pointEnd-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2011.5%2014%22%20refX%3D%2211.5%22%20refY%3D%227%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2210.5%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%200%200%20L%2011.5%207%20L%200%2014%20z%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-pointStart-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2011.5%2014%22%20refX%3D%221%22%20refY%3D%227%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211.5%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Cpolygon%20points%3D%220%2C7%2011.5%2C14%2011.5%2C0%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-circleEnd%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%2211%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-circleStart%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%22-1%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%201%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-circleEnd-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refY%3D%225%22%20refX%3D%2212.25%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2214%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-circleStart-margin%22%20class%3D%22marker%20flowchart-v2%22%20viewBox%3D%220%200%2010%2010%22%20refX%3D%22-2%22%20refY%3D%225%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2214%22%20markerHeight%3D%2214%22%20orient%3D%22auto%22%3E%3Ccircle%20cx%3D%225%22%20cy%3D%225%22%20r%3D%225%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%200%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-crossEnd%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2011%2011%22%20refX%3D%2212%22%20refY%3D%225.2%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20l%209%2C9%20M%2010%2C1%20l%20-9%2C9%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-crossStart%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2011%2011%22%20refX%3D%22-1%22%20refY%3D%225.2%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2211%22%20markerHeight%3D%2211%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20l%209%2C9%20M%2010%2C1%20l%20-9%2C9%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-crossEnd-margin%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2015%2015%22%20refX%3D%2217.7%22%20refY%3D%227.5%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2212%22%20markerHeight%3D%2212%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20L%2014%2C14%20M%201%2C14%20L%2014%2C1%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202.5%3B%22%2F%3E%3C%2Fmarker%3E%3Cmarker%20id%3D%22coddy-mermaid-3_flowchart-v2-crossStart-margin%22%20class%3D%22marker%20cross%20flowchart-v2%22%20viewBox%3D%220%200%2015%2015%22%20refX%3D%22-3.5%22%20refY%3D%227.5%22%20markerUnits%3D%22userSpaceOnUse%22%20markerWidth%3D%2212%22%20markerHeight%3D%2212%22%20orient%3D%22auto%22%3E%3Cpath%20d%3D%22M%201%2C1%20L%2014%2C14%20M%201%2C14%20L%2014%2C1%22%20class%3D%22arrowMarkerPath%22%20style%3D%22stroke-width%3A%202.5%3B%20stroke-dasharray%3A%201%2C%200%3B%22%2F%3E%3C%2Fmarker%3E%3Cg%20class%3D%22root%22%3E%3Cg%20class%3D%22clusters%22%2F%3E%3Cg%20class%3D%22edges%20edgePaths%22%3E%3Cpath%20d%3D%22M280%2C52L280%2C88%22%20id%3D%22coddy-mermaid-3-L_O_P_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%2032%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_O_P_0%22%20data-points%3D%22W3sieCI6MjgwLCJ5Ijo1Mn0seyJ4IjoyODAsInkiOjkyfV0%3D%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-3_flowchart-v2-pointEnd-margin)%22%2F%3E%3Cpath%20d%3D%22M243.5%2C221.499981880188L243.5%2C258L243.5%2C270.9289321881345Q243.5%2C278%20236.42893218813452%2C278L95.07106781186548%2C278Q88%2C278%2088%2C285.0710678118655L88%2C353.99999809265137%22%20id%3D%22coddy-mermaid-3-L_P_S_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%20278.67169189453125%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_P_S_0%22%20data-points%3D%22W3sieCI6MjQzLjUsInkiOjIyMS40OTk5ODE4ODAxODh9LHsieCI6MjQzLjUsInkiOjI1OH0seyJ4IjoyNDMuNSwieSI6Mjc4fSx7IngiOjg4LCJ5IjoyNzh9LHsieCI6ODgsInkiOjM1Ny45OTk5OTgwOTI2NTEzN31d%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-3_flowchart-v2-pointEnd-margin)%22%2F%3E%3Cpath%20d%3D%22M280%2C258L280%2C353.99999809265137%22%20id%3D%22coddy-mermaid-3-L_P_R_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%2092%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_P_R_0%22%20data-points%3D%22W3sieCI6MjgwLCJ5IjoyNTh9LHsieCI6MjgwLCJ5IjozNTcuOTk5OTk4MDkyNjUxMzd9XQ%3D%3D%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-3_flowchart-v2-pointEnd-margin)%22%2F%3E%3Cpath%20d%3D%22M316.5%2C221.499981880188L316.5%2C258L316.5%2C270.9289321881345Q316.5%2C278%20323.5710678118655%2C278L464.9289321881345%2C278Q472%2C278%20472%2C285.0710678118655L472%2C353.99999809265137%22%20id%3D%22coddy-mermaid-3-L_P_F_0%22%20class%3D%22edge-thickness-normal%20edge-pattern-solid%20edge-thickness-normal%20edge-pattern-solid%20flowchart-link%22%20style%3D%22stroke-dasharray%3A%200%200%20278.6717224121094%204%3B%20stroke-dashoffset%3A%200%3B%3B%22%20data-edge%3D%22true%22%20data-et%3D%22edge%22%20data-id%3D%22L_P_F_0%22%20data-points%3D%22W3sieCI6MzE2LjUsInkiOjIyMS40OTk5ODE4ODAxODh9LHsieCI6MzE2LjUsInkiOjI1OH0seyJ4IjozMTYuNSwieSI6Mjc4fSx7IngiOjQ3MiwieSI6Mjc4fSx7IngiOjQ3MiwieSI6MzU3Ljk5OTk5ODA5MjY1MTM3fV0%3D%22%20data-look%3D%22neo%22%20marker-end%3D%22url(%23coddy-mermaid-3_flowchart-v2-pointEnd-margin)%22%2F%3E%3C%2Fg%3E%3Cg%20class%3D%22edgeLabels%22%3E%3Cg%20class%3D%22edgeLabel%22%20transform%3D%22translate(87.6015625%2C%20307.9999990463257)%22%3E%3Cg%20class%3D%22label%22%20data-id%3D%22L_P_S_0%22%20transform%3D%22translate(0%2C%20-9.000000476837158)%22%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22%22%20x%3D%22-14.1015625%22%20y%3D%22-0.9999990463256836%22%20width%3D%2228.203125%22%20height%3D%2219.999999046325684%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20text-anchor%3D%22middle%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%20text-anchor%3D%22middle%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3Eyes%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22edgeLabel%22%20transform%3D%22translate(279.7265625%2C%20307.9999990463257)%22%3E%3Cg%20class%3D%22label%22%20data-id%3D%22L_P_R_0%22%20transform%3D%22translate(0%2C%20-9.000000476837158)%22%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22%22%20x%3D%22-10.7265625%22%20y%3D%22-0.9999990463256836%22%20width%3D%2221.453125%22%20height%3D%2219.999999046325684%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20text-anchor%3D%22middle%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%20text-anchor%3D%22middle%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3Eno%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22edgeLabel%22%20transform%3D%22translate(471.7265625%2C%20307.9999990463257)%22%3E%3Cg%20class%3D%22label%22%20data-id%3D%22L_P_F_0%22%20transform%3D%22translate(0%2C%20-9.000000476837158)%22%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22%22%20x%3D%22-10.7265625%22%20y%3D%22-0.9999990463256836%22%20width%3D%2221.453125%22%20height%3D%2219.999999046325684%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20text-anchor%3D%22middle%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%20text-anchor%3D%22middle%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3Eno%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22nodes%22%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-3-flowchart-O-0%22%20data-look%3D%22neo%22%20transform%3D%22translate(280%2C%2032)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3EOrder%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-3-flowchart-P-1%22%20data-look%3D%22neo%22%20transform%3D%22translate(280%2C%20175)%22%3E%3Cpolygon%20points%3D%2282.99999952316284%2C0%20165.99999904632568%2C-82.99999952316284%2082.99999952316284%2C-165.99999904632568%200%2C-82.99999952316284%22%20class%3D%22label-container%22%20transform%3D%22translate(-82.49999952316284%2C%2082.99999952316284)%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3EPaid%3F%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-3-flowchart-S-3%22%20data-look%3D%22neo%22%20transform%3D%22translate(88%2C%20377.99999809265137)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3EShip%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-3-flowchart-R-5%22%20data-look%3D%22neo%22%20transform%3D%22translate(280%2C%20377.99999809265137)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3ERemind%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cg%20class%3D%22node%20default%22%20id%3D%22coddy-mermaid-3-flowchart-F-7%22%20data-look%3D%22neo%22%20transform%3D%22translate(472%2C%20377.99999809265137)%22%3E%3Crect%20class%3D%22basic%20label-container%22%20style%3D%22%22%20x%3D%22-76%22%20y%3D%22-19.999999523162842%22%20width%3D%22152%22%20height%3D%2239.999999046325684%22%2F%3E%3Cg%20class%3D%22label%22%20style%3D%22%22%20transform%3D%22translate(0%2C%20-7.999999523162842)%22%3E%3Crect%2F%3E%3Cg%3E%3Crect%20class%3D%22background%22%20style%3D%22stroke%3A%20none%22%2F%3E%3Ctext%20y%3D%22-10.1%22%20style%3D%22%22%3E%3Ctspan%20class%3D%22text-outer-tspan%20row%22%20x%3D%220%22%20y%3D%22-0.1em%22%20dy%3D%221.1em%22%3E%3Ctspan%20font-style%3D%22normal%22%20class%3D%22text-inner-tspan%22%20font-weight%3D%22normal%22%3ERefund%3C%2Ftspan%3E%3C%2Ftspan%3E%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3Cdefs%3E%3Cfilter%20id%3D%22coddy-mermaid-3-drop-shadow%22%20height%3D%22130%25%22%20width%3D%22130%25%22%3E%3CfeDropShadow%20dx%3D%224%22%20dy%3D%224%22%20stdDeviation%3D%220%22%20flood-opacity%3D%220.06%22%20flood-color%3D%22%23000000%22%2F%3E%3C%2Ffilter%3E%3C%2Fdefs%3E%3Cdefs%3E%3Cfilter%20id%3D%22coddy-mermaid-3-drop-shadow-small%22%20height%3D%22150%25%22%20width%3D%22150%25%22%3E%3CfeDropShadow%20dx%3D%222%22%20dy%3D%222%22%20stdDeviation%3D%220%22%20flood-opacity%3D%220.06%22%20flood-color%3D%22%23000000%22%2F%3E%3C%2Ffilter%3E%3C%2Fdefs%3E%3C%2Fsvg%3E\"></button></figure></div>"}};
  const DATA = {"notes":{"notes/brief.md":"# Brief\nA shop for the workshop. See [[catalog]], [[checkout]], [pricing](pricing.md), [[roadmap]], [[plan]] and [the site](../site/index.html).\n","notes/catalog.md":"# Catalog\nThree products, prices in euro.\n","notes/checkout.md":"# Checkout\nCart, then pay.\n","notes/faq.md":"# FAQ\nReturns within 30 days. Shipping is in [[pricing]].\n","notes/pricing.md":"# Pricing\nFree shipping over 50.\n","notes/roadmap.md":"# Roadmap\nAlready on the board.\n"},"logo":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAZAAAAEECAIAAACJKvXOAAAF2UlEQVR4nO3aPW6USxCG0eHKGyBlQ6RE5KyMnIiUDREaR45vMGhkPD/+hsHueqvOiQF3t1SP6rN4d//wuANI8N/qAwBsJVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCDG3eoDvOzL51+rjwBTfP32fvURLnl3//C4+gyn6RQsVLNcFYMlVVBEtWyV+x2WWkEd1eaxVrCqvQ5QaioLBavUuwAHdWazSrDqvAhwrMiElghWkbcALqgwp+uDVeEVgC2WT+viYC2/P3CVtTO7fsMC2GhlsKxXkGjh5NqwgBiCBcRYFizfg5Br1fzasIAYggXEECwghmABMQQLiCFYQAzBAmIIFhBDsIAYggXEECwghmABMQQLiCFYQAzBAmIIFhBDsIAYggXEECwghmABMQQLiCFYQAzBAmIIFhBDsIAYd6sPQLzvPz5s/8OfPv58vZPQnmBxtasKdfnv6hdXESy2uqVTL/6bysUWgsULXqNTF36KcnGBYHHW26Tq5A+VLU4SLE5YkqrjA8gWzwgWf1ieqqdki2cEi99Kpeop2eLAfxxltytcq4P6J+QN2LCmCwqBVQsb1mhBtTpIPDP/imDNlTv5uSfnRj4JJ2ow8D4PZ7JhjdOgVged7sIWgjVLvwnvdyMuEKxBus5213txTLCm6D3VvW/HgWCNMGGeJ9wRwQJiCFZ/c1aPOTcdS7CamzbD0+47jWB1NnN6Z956CMECYghWW5MXjcl3702wejKxXqAlwQJiCFZDlos979CPYAExBKsba8VTXqMZwQJiCFYrFopj3qQTwQJiCFYfVolzvEwbggXEECwghmA14avnMu/Tg2ABMQQLiCFYHfje2cIrNSBYQAzBAmIIFhBDsIAYghXP75K381bpBAuIIVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQrHifPv5cfYQY3iqdYAExBAuIIVhADMECYghWB36XvIVXakCwgBiCBcQQrCZ871zmfXoQLCCGYAExBKsPXz3neJk2BAuIIVitWCWOeZNOBAuIIVjdWCie8hrNCBYQQ7AaslbseYd+BAuIIVg9WS68QEuC1dbkiZ18994EC4ghWJ3NXDRm3noIwWpu2vROu+80gtXfnBmec9OxBAuIIVgjTFg9JtwRwZqi9zz3vh0HgjVI16nuei+OCdYs/Wa73424QLDG6TThne7CFnerD8AC+zn//uPD6oP8PamayYY1V+7M556cGwnWaImTn3hm/hWfhNMFfR5KFTYsdruEFtQ/IW/AhsVvZVctqeJAsPhDqWxJFc8IFicsz5ZUcZJgcdaSbEkVFwgWLzgU5FXLpVNsIVhs9Rrl0imuIlhc7VllruqXQnELweJWGsSb8R9HgRiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBjLgvX12/tVPxq40ar5tWEBMQQLiLEyWL4KIdHCybVhATEWB8uSBVnWzuz6DUuzIMXyaV0frF2BVwBeVGFOSwRrV+MtgHOKTGiVYO3KvAjwTJ3ZLBSsXaV3AfZKTWWtYO2KvQ4MV20e390/PK4+w2lfPv9afQSYq1qq9uoG60C54M3U7NRBQLAA9sr9DgvgHMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCCGYAExBAuIIVhADMECYggWEEOwgBiCBcQQLCDG/w29JbGxO0s1AAAAAElFTkSuQmCC"};

  // ---------- small helpers ----------

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const esc = (s) =>
    String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  const el = (markup) => {
    const t = document.createElement("template");
    t.innerHTML = markup.trim();
    return t.content.firstElementChild;
  };
  const clone = (v) => JSON.parse(JSON.stringify(v));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const svgIcon = (inner, size = 20) =>
    `<svg viewBox="0 0 24 24" width="${size}" height="${size}" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;

  const body = document.body;
  const PAGE = body.dataset.page;
  const SLIDE = body.dataset.slide || "";
  const PHONE = body.dataset.width === "390";
  const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform);
  // Obsidian's keys: the clone key and the no-snap key swap on macOS.
  const CLONE = IS_MAC ? "altKey" : "ctrlKey";
  const NOSNAP = IS_MAC ? "ctrlKey" : "altKey";
  const CLONE_KEY = IS_MAC ? "Alt" : "Ctrl";
  const NOSNAP_KEY = IS_MAC ? "Ctrl" : "Alt";
  const MOD = IS_MAC ? "Cmd" : "Ctrl";
  // Decision 5: a 20 px grid; a card 260 x 140, a file or link node 400 x 300; a minimum of 60 x 40.
  const GRID = 20;
  const CARD = { w: 260, h: 140 };
  const FILE = { w: 400, h: 300 };
  const MIN = { w: 60, h: 40 };
  // Coddy's camera (external/ui/src/ui/canvas/camera.ts, components/zoom.ts).
  const FIT_PADDING = 32;
  const TITLE_ROOM = 34;
  const ZOOM_STEP = 1.25;
  const clampScale = (k) => Math.min(2, Math.max(0.05, k));
  // JSON Canvas presets as Obsidian paints them (canvas/jsonCanvas.ts).
  const PRESET = { 1: "#fb464c", 2: "#e9973f", 3: "#e0de71", 4: "#44cf6e", 5: "#53dfdd", 6: "#a882ff" };
  const canvasColor = (c) => (c ? PRESET[c] || (/^#[0-9a-f]{6}$/i.test(c) ? c : undefined) : undefined);
  // The markup window's palette (markup/markupModel.ts, MARKUP_PALETTE).
  const MARKUP_PALETTE = [
    ["red", "#ff3b30"],
    ["orange", "#ff9500"],
    ["yellow", "#ffcc00"],
    ["green", "#34c759"],
    ["blue", "#0a84ff"],
    ["white", "#ffffff"],
    ["black", "#000000"],
  ];
  const STROKE = 4; // a stroke's width, in board units at any zoom
  const TEXT_SIZE = 22;

  // ---------- #570: the menus' icons ----------

  const svg16 = (inner, size = 16) =>
    `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${inner}</svg>`;
  const ICONS = {
    pointer: svg16('<path d="M4 3l7 17 2.5-7.5L21 10z"/>'),
    plus: svg16('<path d="M12 5v14M5 12h14"/>'),
    link: svg16('<path d="M10 13a5 5 0 0 0 7.07 0l2.83-2.83a5 5 0 0 0-7.07-7.07L11.5 4.5"/><path d="M14 11a5 5 0 0 0-7.07 0L4.1 13.83a5 5 0 0 0 7.07 7.07L12.5 19.5"/>'),
    zoom: svg16('<path d="M4 9V5a1 1 0 0 1 1-1h4M15 4h4a1 1 0 0 1 1 1v4M20 15v4a1 1 0 0 1-1 1h-4M9 20H5a1 1 0 0 1-1-1v-4"/>'),
    focus: svg16('<circle cx="12" cy="12" r="3"/><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/>'),
    edges: svg16('<circle cx="5" cy="12" r="2"/><circle cx="19" cy="6" r="2"/><circle cx="19" cy="18" r="2"/><path d="M7 11l10-4M7 13l10 4"/>'),
    group: svg16('<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 9h18"/>'),
    swap: svg16('<path d="M7 7h12l-3-3M17 17H5l3 3"/>'),
    flip: svg16('<path d="M12 3v18M8 7l-4 5 4 5M16 7l4 5-4 5"/>'),
    box: svg16('<path d="M21 8l-9-5-9 5 9 5z"/><path d="M3 8v8l9 5 9-5V8"/>'),
    open: svg16('<path d="M14 3h7v7M10 14L21 3M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/>'),
    shape: svg16('<path d="M12 3l9 9-9 9-9-9z"/>'),
    border: svg16('<rect x="4" y="4" width="16" height="16" rx="2" stroke-dasharray="3 3"/>'),
    align: svg16('<path d="M4 6h16M7 12h10M4 18h16"/>'),
    colour: svg16('<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 0 0 18"/>'),
    play: svg16('<path d="M7 4l12 8-12 8z"/>'),
    trash: svg16('<path d="M3 6h18"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>'),
    collapse: svg16('<path d="M6 9l6 6 6-6"/>'),
    expand: svg16('<path d="M9 6l6 6-6 6"/>'),
    lock: svg16('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'),
    search: svg16('<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>'),
    path: svg16('<path d="M3 17c5 0 5-10 10-10s5 10 8 10" stroke-dasharray="4 3"/>'),
    arrow: svg16('<path d="M5 12h14M13 6l6 6-6 6"/>'),
    turn: svg16('<path d="M4 7h13l-3-3M20 17H7l3 3"/>'),
    download: svg16('<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>'),
    image: svg16('<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>'),
    screen: svg16('<path d="M4 9V5a1 1 0 0 1 1-1h4M15 4h4a1 1 0 0 1 1 1v4M20 15v4a1 1 0 0 1-1 1h-4M9 20H5a1 1 0 0 1-1-1v-4"/>', 14),
    unscreen: svg16('<path d="M9 4v4a1 1 0 0 1-1 1H4M20 9h-4a1 1 0 0 1-1-1V4M15 20v-4a1 1 0 0 1 1-1h4M4 15h4a1 1 0 0 1 1 1v4"/>', 14),
    chevron: svg16('<path d="M9 6l6 6-6 6"/>', 14),
    info: svg16('<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>', 22),
  };
  ICONS.pen = svg16('<path d="M16.5 3.5l4 4L8 20H4v-4L16.5 3.5z"/>');
  ICONS.copy = svg16('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>');
  ICONS.chat = svg16('<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>');

  // ---------- theme, notes, toasts and the mockup bar ----------

  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme === "light" ? "light" : "dark";
    const b = $(".mk-theme");
    if (b) b.textContent = theme === "light" ? "Dark theme" : "Light theme";
    placeNotes();
  }

  let notes = [];
  // Notes that live as long as what they point at: an open menu's.
  let transient = [];
  function setNotes(list) {
    notes = list || [];
    placeNotes();
  }
  function setTransient(list) {
    transient = list || [];
    placeNotes();
  }
  function placeNotes() {
    let layer = $(".mk-notes");
    if (!layer) {
      layer = el('<div class="mk-notes" aria-hidden="true"></div>');
      body.append(layer);
    }
    layer.textContent = "";
    const placed = [];
    for (const n of transient.concat(notes)) {
      const target = typeof n.at === "string" ? $(n.at) : n.at;
      if (!target || !target.isConnected) continue;
      const r = target.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) continue;
      if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) continue;
      if (!n.free) {
        const cx = Math.min(Math.max(r.left + Math.min(r.width / 2, 24), 0), innerWidth - 1);
        const cy = Math.min(Math.max(r.top + Math.min(r.height / 2, 12), 0), innerHeight - 1);
        const hit = document.elementFromPoint(cx, cy);
        if (!hit || !(target.contains(hit) || hit.contains(target) || hit.closest?.(".mk-notes"))) continue;
      }
      const note = el(`<div class="mk-note">${esc(n.text)}</div>`);
      layer.append(note);
      const w = note.offsetWidth;
      const h = note.offsetHeight;
      let x = r.left;
      let y = r.bottom + 6;
      let side = n.side;
      if (side === "left" && r.left - w - 8 < 6) side = "below";
      if (side === "right" && r.right + 8 + w > innerWidth - 6) side = "below";
      if (side === "above") y = r.top - h - 6;
      if (side === "right") {
        x = r.right + 8;
        y = r.top + (r.height - h) / 2;
      }
      if (side === "left") {
        x = r.left - w - 8;
        y = r.top + (r.height - h) / 2;
      }
      x = Math.max(6, Math.min(x + (n.dx || 0), innerWidth - w - 6));
      y = Math.max(6, Math.min(y + (n.dy || 0), innerHeight - h - 6));
      // Never over another note: step away from the ones placed already, in
      // the note's own direction first, then the other way.
      const hits = (yy) => placed.some((q) => x < q.x + q.w + 4 && q.x < x + w + 4 && yy < q.y + q.h + 4 && q.y < yy + h + 4);
      if (hits(y)) {
        const dir = side === "above" ? -1 : 1;
        let best = y;
        for (let k = 1; k <= 12; k++) {
          const a = y + dir * k * 12, b = y - dir * k * 12;
          if (a >= 6 && a <= innerHeight - h - 6 && !hits(a)) {
            best = a;
            break;
          }
          if (b >= 6 && b <= innerHeight - h - 6 && !hits(b)) {
            best = b;
            break;
          }
        }
        y = best;
      }
      placed.push({ x, y, w, h });
      note.style.left = `${x}px`;
      note.style.top = `${y}px`;
    }
  }
  addEventListener("resize", placeNotes);
  setInterval(placeNotes, 700);

  let toastTimer = 0;
  // A toast of plain text (#606) or of markup (#570 shows the request a write
  // sends); in full screen it shows inside the pane.
  function toastHtml(html, ms = 3600) {
    $(".kp-toast")?.remove();
    const t = el(`<div class="kp-toast" role="status">${html}</div>`);
    ($(".kp-fullscreen") || body).append(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.remove(), ms);
  }
  const toast = (text, ms) => toastHtml(esc(text), ms);
  // A frame never takes the focus by itself: Chrome would scroll the focused
  // element into view through the canvas board around the frame (#679).
  const focusSoft = (node) => node && document.hasFocus() && node.focus({ preventScroll: true });

  // The web UI's confirmation dialog (components/ConfirmDialog.tsx).
  function confirmDialog({ title, message, confirm, variant = "primary" }) {
    return new Promise((resolve) => {
      const icon = variant === "danger" ? ICONS.trash.replace('width="16" height="16"', 'width="22" height="22"') : ICONS.info;
      const d = el(`<div class="confirm-dialog-backdrop"><div class="confirm-dialog" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <div class="confirm-dialog-body"><span class="confirm-dialog-icon confirm-dialog-icon--${variant}" aria-hidden="true">${icon}</span>
        <div class="confirm-dialog-text"><h2 class="confirm-dialog-title">${esc(title)}</h2><p class="confirm-dialog-message">${esc(message)}</p></div></div>
        <div class="confirm-dialog-actions"><button type="button" class="confirm-dialog-btn confirm-dialog-btn--cancel">Cancel</button>
        <button type="button" class="confirm-dialog-btn confirm-dialog-btn--${variant}">${esc(confirm)}</button></div></div></div>`);
      const done = (v) => {
        d.remove();
        removeEventListener("keydown", onKey, true);
        resolve(v);
      };
      const onKey = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          e.stopPropagation();
          done(false);
        }
      };
      addEventListener("keydown", onKey, true);
      d.addEventListener("mousedown", (e) => e.target === d && done(false));
      $(".confirm-dialog-btn--cancel", d).onclick = () => done(false);
      $(`.confirm-dialog-btn--${variant}`, d).onclick = () => done(true);
      ($(".kp-fullscreen") || body).append(d);
      focusSoft($(`.confirm-dialog-btn--${variant}`, d));
    });
  }

  function mockBar(actions, restart) {
    const bar = el(`<div class="mk-bar" role="region" aria-label="Mockup controls" data-collapsed="true">
      <div class="mk-bar-head"><span class="mk-bar-tag">Mockup</span>
        <button type="button" class="mk-bar-fold" aria-label="Show or hide the mockup controls">▴</button></div>
      <div class="mk-bar-body">
        <span class="mk-bar-title">${esc(SLIDE)}</span>
        <div class="mk-bar-row">
          <button type="button" class="mk-btn mk-theme">Light theme</button>
          <button type="button" class="mk-btn mk-notes-btn" aria-pressed="true">Notes</button>
          <button type="button" class="mk-btn mk-restart">Restart</button>
        </div>
        <div class="mk-bar-row mk-actions"></div>
        <span class="mk-bar-hint">Everything is clickable. Writes, files and the agent's answers are scripted; data is made up.</span>
      </div></div>`);
    body.append(bar);
    $(".mk-bar-fold", bar).onclick = () => {
      const c = bar.dataset.collapsed !== "true";
      bar.dataset.collapsed = String(c);
      $(".mk-bar-fold", bar).textContent = c ? "▴" : "▾";
    };
    $(".mk-theme", bar).onclick = () => setTheme(document.documentElement.dataset.theme === "light" ? "dark" : "light");
    $(".mk-notes-btn", bar).onclick = (e) => {
      const on = body.dataset.notes === "off";
      body.dataset.notes = on ? "on" : "off";
      e.currentTarget.setAttribute("aria-pressed", String(on));
    };
    const row = $(".mk-actions", bar);
    const fill = (list) => {
      row.textContent = "";
      for (const a of list) {
        const b = el(`<button type="button" class="mk-btn">${esc(a.label)}</button>`);
        b.onclick = a.run;
        row.append(b);
      }
    };
    $(".mk-restart", bar).onclick = () => fill(restart());
    fill(actions);
  }

  // The shared confirmation dialog (components/ConfirmDialog.tsx) as Draw asks
  // it: the dismissal (Keep) has the focus, so Enter, Escape and a click
  // outside keep drawing. It mounts in `host`, the pane while in full screen.
  function keepOrDiscard(count, host = body) {
    return new Promise((resolve) => {
      const icon = svgIcon('<path d="M3 6h18"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/><path d="M14 11v6"/>', 22);
      const title = `Discard ${count} change${count === 1 ? "" : "s"}?`;
      const d = el(`<div class="confirm-dialog-backdrop"><div class="confirm-dialog" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <div class="confirm-dialog-body"><span class="confirm-dialog-icon confirm-dialog-icon--danger" aria-hidden="true">${icon}</span>
        <div class="confirm-dialog-text"><h2 class="confirm-dialog-title">${esc(title)}</h2><p class="confirm-dialog-message">Done saves them as a sketch on the board. Discarded changes cannot be brought back.</p></div></div>
        <div class="confirm-dialog-actions"><button type="button" class="confirm-dialog-btn confirm-dialog-btn--cancel">Keep</button>
        <button type="button" class="confirm-dialog-btn confirm-dialog-btn--danger">Discard</button></div></div></div>`);
      const done = (v) => {
        d.remove();
        removeEventListener("keydown", onKey, true);
        resolve(v);
      };
      const onKey = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          e.stopPropagation();
          done(false);
        }
      };
      addEventListener("keydown", onKey, true);
      d.addEventListener("mousedown", (e) => e.target === d && done(false));
      $(".confirm-dialog-btn--cancel", d).onclick = () => done(false);
      $(".confirm-dialog-btn--danger", d).onclick = () => done(true);
      host.append(d);
      $(".confirm-dialog-btn--cancel", d).focus({ preventScroll: true });
    });
  }

  // ---------- Markdown, as the cards draw it (a small subset) ----------

  // #570, Stage 5: a board in the workspace resolves node links and embeds;
  // the board on screen sets it (createBoard).
  let LINKS = null;
  function inline(s, depth = 0) {
    let out = esc(s);
    if (LINKS) {
      out = out.replace(/!\[\[([^\]#]+\.canvas)#([^\]]+)\]\]/g, (_, f, id) => (depth > 0 ? LINKS.linkTo(f, id) : `\u0000${f}#${id}\u0000`));
      out = out.replace(/\[\[([^\]#]+\.canvas)#([^\]]+)\]\]/g, (_, f, id) => LINKS.linkTo(f, id));
    }
    out = out.replace(/`([^`]+)`/g, '<code class="md-inline-code" role="button" tabindex="0" title="Copy" aria-label="Copy code" data-testid="md-inline-code">$1</code>');
    out = out.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    out = out.replace(/(^|[^*])\*([^*]+)\*/g, "$1<em>$2</em>");
    out = out.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, '<a href="$2">$1</a>');
    return out;
  }
  function md(text, depth = 0) {
    const il = (l) => inline(l, depth);
    const blocks = String(text || "").split(/\n\s*\n/);
    const html = blocks
      .map((b) => {
        const lines = b.split("\n");
        const h = /^(#{1,6})\s+(.*)$/.exec(lines[0]);
        if (h && lines.length === 1) return `<h${h[1].length}>${il(h[2])}</h${h[1].length}>`;
        if (h) return `<h${h[1].length}>${il(h[2])}</h${h[1].length}>\n<p>${lines.slice(1).map(il).join("<br>\n")}</p>`;
        if (lines.every((l) => /^- /.test(l))) return `<ul>${lines.map((l) => `<li>${il(l.slice(2))}</li>`).join("")}</ul>`;
        return `<p>${lines.map(il).join("<br>\n")}</p>`;
      })
      .join("\n");
    // An embed is a block of its own: pull it out of its paragraph.
    return html.replace(/\u0000([^#\u0000]+)#([^\u0000]+)\u0000/g, (_, f, id) => `</p>${LINKS.embed(f, id)}<p>`).replace(/<p>(<br>\n)*<\/p>/g, "");
  }

  // ---------- geometry: the canvas's own (canvas/jsonCanvas.ts) ----------

  const NORMALS = { top: [0, -1], right: [1, 0], bottom: [0, 1], left: [-1, 0] };
  const rectOf = (n) => ({ x: n.x, y: n.y, width: n.w, height: n.h });
  function sideAnchor(r, side) {
    if (side === "top") return { x: r.x + r.width / 2, y: r.y };
    if (side === "right") return { x: r.x + r.width, y: r.y + r.height / 2 };
    if (side === "bottom") return { x: r.x + r.width / 2, y: r.y + r.height };
    return { x: r.x, y: r.y + r.height / 2 };
  }
  function facingSide(from, to) {
    const dx = to.x + to.width / 2 - (from.x + from.width / 2);
    const dy = to.y + to.height / 2 - (from.y + from.height / 2);
    if (Math.abs(dx) >= Math.abs(dy)) return dx >= 0 ? "right" : "left";
    return dy >= 0 ? "bottom" : "top";
  }
  const round1 = (n) => Math.round(n * 10) / 10;
  function bezierAt(p, t) {
    const u = 1 - t;
    const a = u * u * u, b = 3 * u * u * t, c = 3 * u * t * t, d = t * t * t;
    return { x: a * p[0].x + b * p[1].x + c * p[2].x + d * p[3].x, y: a * p[0].y + b * p[1].y + c * p[2].y + d * p[3].y };
  }
  function arrowAt(tip, from, size) {
    let ux = tip.x - from.x, uy = tip.y - from.y;
    const len = Math.hypot(ux, uy) || 1;
    ux /= len;
    uy /= len;
    const bx = tip.x - ux * size, by = tip.y - uy * size, half = size * 0.55;
    return [[tip.x, tip.y], [bx - uy * half, by + ux * half], [bx + uy * half, by - ux * half]].map(([x, y]) => `${round1(x)},${round1(y)}`).join(" ");
  }
  function curve(p0, fromSide, p3, toSide) {
    const dist = Math.hypot(p3.x - p0.x, p3.y - p0.y);
    const bend = Math.min(Math.max(dist * 0.4, 24), 240);
    const n0 = NORMALS[fromSide], n3 = NORMALS[toSide];
    const p1 = { x: p0.x + n0[0] * bend, y: p0.y + n0[1] * bend };
    const p2 = { x: p3.x + n3[0] * bend, y: p3.y + n3[1] * bend };
    const r = (p) => `${round1(p.x)} ${round1(p.y)}`;
    return { d: `M ${r(p0)} C ${r(p1)}, ${r(p2)}, ${r(p3)}`, pts: [p0, p1, p2, p3] };
  }
  function edgeShape(e, rects) {
    const a = rects.get(e.from), b = rects.get(e.to);
    if (!a || !b) return null;
    const fs = e.fromSide || facingSide(a, b), ts = e.toSide || facingSide(b, a);
    const c = curve(sideAnchor(a, fs), fs, sideAnchor(b, ts), ts);
    const st = e.styleAttributes || {};
    // #570, Stage 1: an arrow at the end the file names (toEnd defaults to
    // "arrow", fromEnd to "none"), in the plugin's arrow style; each arrow is
    // SVG markup.
    const arrows = [];
    if ((e.toEnd ?? "arrow") === "arrow") arrows.push(arrowStyled(c.pts[3], c.pts[2], st.arrow));
    if (e.fromEnd === "arrow") arrows.push(arrowStyled(c.pts[0], c.pts[1], st.arrow));
    return { d: c.d, arrows, mid: bezierAt(c.pts, 0.5), pts: c.pts };
  }
  const meets = (a, b) => a.x < b.x + b.width && b.x < a.x + a.width && a.y < b.y + b.height && b.y < a.y + a.height;
  const inside = (g, n) => n.x >= g.x && n.y >= g.y && n.x + n.w <= g.x + g.w && n.y + n.h <= g.y + g.h;
  // #570, Stage 1: a collapsed group's members are the nodes strictly inside
  // its rectangle, as the plugin's collapse takes them (a node touching the
  // edge stays out).
  const strictlyInside = (n, g) => n.x > g.x && n.y > g.y && n.x + n.w < g.x + g.w && n.y + n.h < g.y + g.h;

  // ---------- #570, Stage 1: what the plugin draws that Coddy does not today ----------

  const SHAPES = ["rectangle", "pill", "diamond", "parallelogram", "circle", "predefined-process", "document", "database"];
  const BORDERS = ["solid", "dashed", "dotted", "invisible"];
  const PATHS = ["solid", "long-dashed", "short-dashed", "dotted"];
  const ARROWS = ["triangle", "triangle-outline", "thin-triangle", "halved-triangle", "diamond", "diamond-outline", "circle", "circle-outline", "blunt"];
  const cap = (s) => s[0].toUpperCase() + s.slice(1).replace(/-/g, " ");

  // The outline of a shape, drawn under the card's text.
  function shapeSvg(shape, w, h) {
    const p = {
      pill: `<rect x="1" y="1" width="${w - 2}" height="${h - 2}" rx="${(h - 2) / 2}"/>`,
      diamond: `<path d="M${w / 2} 1 L${w - 1} ${h / 2} L${w / 2} ${h - 1} L1 ${h / 2} Z"/>`,
      parallelogram: `<path d="M${w * 0.18} 1 L${w - 1} 1 L${w * 0.82} ${h - 1} L1 ${h - 1} Z"/>`,
      circle: `<ellipse cx="${w / 2}" cy="${h / 2}" rx="${w / 2 - 1}" ry="${h / 2 - 1}"/>`,
      "predefined-process": `<rect x="1" y="1" width="${w - 2}" height="${h - 2}" rx="4"/><path d="M${w * 0.1} 1V${h - 1}M${w * 0.9} 1V${h - 1}"/>`,
      document: `<path d="M1 1H${w - 1}V${h * 0.82} C${w * 0.75} ${h * 0.68}, ${w * 0.25} ${h * 1.02}, 1 ${h * 0.86} Z"/>`,
      // The cap stays inside the box: the plugin draws it above.
      database: `<path d="M1 ${h * 0.14} V${h * 0.86} A${w / 2 - 1} ${h * 0.13} 0 0 0 ${w - 1} ${h * 0.86} V${h * 0.14}"/><ellipse cx="${w / 2}" cy="${h * 0.14}" rx="${w / 2 - 1}" ry="${h * 0.13}"/>`,
    }[shape];
    return p ? `<svg class="cv-shape" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">${p}</svg>` : "";
  }

  // An arrowhead in one of the plugin's styles, its tip at `tip`, pointing
  // away from `from`.
  function arrowStyled(tip, from, style) {
    let ux = tip.x - from.x, uy = tip.y - from.y;
    const len = Math.hypot(ux, uy) || 1;
    ux /= len;
    uy /= len;
    const s = 14, half = s * 0.55;
    const P = (along, across) => [tip.x - ux * along - uy * across, tip.y - uy * along + ux * across];
    const pts = (l) => l.map((p) => `${round1(p[0])},${round1(p[1])}`).join(" ");
    switch (style) {
      case "triangle-outline":
        return `<polygon class="cv-arrow-outline" points="${pts([P(0, 0), P(s, half), P(s, -half)])}"></polygon>`;
      case "thin-triangle":
        return `<polyline class="cv-arrow-line" points="${pts([P(s, half), P(0, 0), P(s, -half)])}"></polyline>`;
      case "halved-triangle":
        return `<polygon class="canvas-edge-arrow" points="${pts([P(0, 0), P(s, half), P(s, 0)])}"></polygon>`;
      case "diamond":
        return `<polygon class="canvas-edge-arrow" points="${pts([P(0, 0), P(s * 0.8, half), P(s * 1.6, 0), P(s * 0.8, -half)])}"></polygon>`;
      case "diamond-outline":
        return `<polygon class="cv-arrow-outline" points="${pts([P(0, 0), P(s * 0.8, half), P(s * 1.6, 0), P(s * 0.8, -half)])}"></polygon>`;
      case "circle": {
        const c = P(s / 2, 0);
        return `<circle class="canvas-edge-arrow" cx="${round1(c[0])}" cy="${round1(c[1])}" r="${s / 2}"></circle>`;
      }
      case "circle-outline": {
        const c = P(s / 2, 0);
        return `<circle class="cv-arrow-outline" cx="${round1(c[0])}" cy="${round1(c[1])}" r="${s / 2}"></circle>`;
      }
      case "blunt":
        return `<polyline class="cv-arrow-line" points="${pts([P(0, half), P(0, -half)])}"></polyline>`;
      default:
        return `<polygon class="canvas-edge-arrow" points="${pts([P(0, 0), P(s, half), P(s, -half)])}"></polygon>`;
    }
  }

  // A picture node's star and a group's background (media/paper.png with
  // backgroundStyle "repeat"), read as bounded bytes and shown from data:.
  const PICTURE =
    "data:image/svg+xml;utf8," +
    encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120"><circle cx="60" cy="60" r="54" fill="#a882ff"/><path d="M60 22l11 23 25 4-18 18 4 25-22-12-22 12 4-25-18-18 25-4z" fill="#fff"/></svg>');
  const PAPER =
    "data:image/svg+xml;utf8," +
    encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path d="M0 28L28 0" stroke="#8a8a9a" stroke-opacity=".28" stroke-width="1.2"/><circle cx="7" cy="7" r="1.4" fill="#8a8a9a" fill-opacity=".35"/></svg>');

  // #570's boards (JSON Canvas files as Obsidian with the plugin writes them)
  // and the notes they show.
  /* The boards, notes and pages the #570 prototypes open: JSON Canvas files
 * with the keys of Advanced JSON Canvas 1.0-1.0, as Obsidian with the
 * plugin 7.1.0 writes them. Neutral example data. */
const BOARDS = {
  // Stage 1: everything the plugin draws that Coddy does not today.
  "canvas/flow.canvas": {
    nodes: [
      { id: "z2", type: "text", text: "**zIndex 3**\nFirst in the file, on top.", x: 700, y: 50, width: 240, height: 100, color: "6", zIndex: 3 },
      { id: "z1", type: "text", text: "**zIndex 1**\nLater in the file, under it.", x: 640, y: 0, width: 240, height: 100, zIndex: 1 },
      { id: "start", type: "text", text: "Start", x: 0, y: 0, width: 200, height: 64, color: "4", styleAttributes: { shape: "pill", textAlign: "center" } },
      { id: "brief", type: "text", text: "**Brief**", x: 0, y: 140, width: 200, height: 110, styleAttributes: { shape: "document", textAlign: "center" } },
      { id: "stock", type: "text", text: "Check stock", x: 320, y: 155, width: 220, height: 80, styleAttributes: { shape: "predefined-process", textAlign: "center" } },
      { id: "paid", type: "text", text: "Paid?", x: -10, y: 320, width: 220, height: 140, color: "2", styleAttributes: { shape: "diamond", textAlign: "center" } },
      { id: "again", type: "text", text: "Ask again", x: 320, y: 350, width: 220, height: 80, color: "3", styleAttributes: { shape: "parallelogram", border: "dashed", textAlign: "center" } },
      { id: "orders", type: "text", text: "Orders", x: 0, y: 560, width: 200, height: 150, color: "5", styleAttributes: { shape: "database", textAlign: "center" } },
      { id: "done", type: "text", text: "Done", x: 340, y: 570, width: 130, height: 130, color: "4", styleAttributes: { shape: "circle", textAlign: "center" } },
      { id: "research", type: "group", collapsed: true, x: 640, y: 210, width: 480, height: 290, label: "Research" },
      { id: "r1", type: "text", text: "Interviews", x: 660, y: 250, width: 200, height: 80 },
      { id: "r2", type: "text", text: "Survey", x: 900, y: 250, width: 200, height: 80 },
      { id: "r3", type: "text", text: "Competitors", x: 660, y: 390, width: 200, height: 80, styleAttributes: { border: "dotted" } },
      { id: "r4", type: "text", text: "Open questions", x: 900, y: 390, width: 200, height: 80 },
      { id: "release", type: "group", x: 640, y: 560, width: 480, height: 230, label: "Release", color: "6", background: "media/paper.png", backgroundStyle: "repeat" },
      { id: "check", type: "text", text: "**Checklist**\nDocs, screenshots, changelog", x: 660, y: 600, width: 230, height: 110, styleAttributes: { textAlign: "center" } },
      { id: "badge", type: "file", file: "media/badge.svg", x: 920, y: 590, width: 170, height: 170, styleAttributes: { border: "invisible" } },
    ],
    edges: [
      { id: "f1", fromNode: "start", fromSide: "bottom", toNode: "brief", toSide: "top" },
      { id: "f2", fromNode: "brief", fromSide: "right", toNode: "stock", toSide: "left", styleAttributes: { path: "short-dashed", arrow: "circle-outline" } },
      { id: "f3", fromNode: "brief", fromSide: "bottom", toNode: "paid", toSide: "top", styleAttributes: { arrow: "thin-triangle" } },
      { id: "f4", fromNode: "paid", fromSide: "right", toNode: "again", toSide: "left", label: "no", styleAttributes: { path: "dotted", arrow: "blunt" } },
      { id: "f5", fromNode: "again", fromSide: "top", toNode: "stock", toSide: "bottom", label: "retry", styleAttributes: { path: "long-dashed", arrow: "diamond" } },
      { id: "f6", fromNode: "paid", fromSide: "bottom", toNode: "orders", toSide: "top", label: "yes", styleAttributes: { arrow: "triangle-outline" } },
      { id: "f7", fromNode: "orders", fromSide: "right", toNode: "done", toSide: "left", color: "4", styleAttributes: { arrow: "halved-triangle" } },
      { id: "f8", fromNode: "stock", fromSide: "right", toNode: "r1", toSide: "left", styleAttributes: { arrow: "diamond-outline" } },
      { id: "f9", fromNode: "done", fromSide: "right", toNode: "check", toSide: "left", styleAttributes: { arrow: "circle" } },
    ],
    metadata: { version: "1.0-1.0", frontmatter: {} },
  },

  // Stages 2 to 4: a working board with a live page, a note, a link and a
  // folded group.
  "canvas/shop.canvas": {
    nodes: [
      { id: "flow", type: "group", x: -80, y: -110, width: 860, height: 410, label: "Checkout", color: "5" },
      { id: "cart", type: "text", text: "**Cart**\nTotals and shipping.", x: 0, y: 0, width: 220, height: 100, color: "4" },
      { id: "checkout", type: "text", text: "### Checkout\nTwo steps: **cart**, then *pay*.", x: 300, y: 0, width: 240, height: 100 },
      { id: "pay", type: "text", text: "### Payment\nCard or invoice.", x: 300, y: 170, width: 240, height: 90 },
      { id: "receipt", type: "text", text: "**Receipt**\nMailed after payment.", x: 0, y: 170, width: 220, height: 90 },
      { id: "page", type: "file", file: "site/index.html", x: 820, y: 0, width: 600, height: 380, coddy: { title: "Checkout page" } },
      { id: "brief", type: "file", file: "notes/brief.md", x: 0, y: 340, width: 330, height: 200 },
      { id: "docs", type: "link", url: "https://example.com/docs/checkout", x: 380, y: 350, width: 300, height: 120 },
      // GET cut this card's text at 20000 bytes and says so (truncated).
      { id: "log", type: "text", text: "**Changelog**\nEvery checkout change since March, newest first: card payments, invoices, receipts by mail, the second step of checkout, refunds, …", truncated: true, x: 380, y: 510, width: 300, height: 110 },
      { id: "research", type: "group", collapsed: true, x: 820, y: 450, width: 460, height: 230, label: "Research" },
      { id: "fraud", type: "text", text: "**Fraud checks**\nRun after payment.", x: 840, y: 490, width: 200, height: 80 },
      { id: "chargebacks", type: "text", text: "Chargebacks", x: 1060, y: 490, width: 200, height: 80 },
      { id: "bench", type: "text", text: "Benchmarks", x: 840, y: 580, width: 200, height: 80 },
      { id: "interviews", type: "text", text: "Interviews", x: 1060, y: 580, width: 200, height: 80 },
    ],
    edges: [
      { id: "e1", fromNode: "cart", fromSide: "right", toNode: "checkout", toSide: "left", label: "then" },
      { id: "e2", fromNode: "checkout", fromSide: "bottom", toNode: "pay", toSide: "top" },
      { id: "e3", fromNode: "pay", fromSide: "right", toNode: "page", toSide: "left", label: "pay", color: "6" },
      { id: "e4", fromNode: "pay", fromSide: "left", toNode: "receipt", toSide: "right", label: "checked" },
      { id: "e5", fromNode: "cart", fromSide: "bottom", toNode: "receipt", toSide: "top" },
      { id: "e6", fromNode: "fraud", fromSide: "top", toNode: "page", toSide: "bottom" },
    ],
    metadata: { version: "1.0-1.0", frontmatter: {} },
  },

  // Stage 4: a talk, walked from metadata.startNode as the plugin walks it.
  "canvas/talk.canvas": {
    nodes: [
      { id: "s1", type: "group", x: 0, y: 0, width: 620, height: 380, label: "1 - Why two steps", color: "5" },
      { id: "s1t", type: "text", text: "## Checkout talk\nWhy payment is a step of its own.", x: 30, y: 40, width: 560, height: 150 },
      { id: "s1n", type: "text", text: "**Speaker note**\nTwo minutes; questions at the end.", x: 30, y: 220, width: 560, height: 120 },
      { id: "s2", type: "group", x: 760, y: 0, width: 700, height: 420, label: "2 - Checkout flow", color: "5" },
      { id: "s2a", type: "text", text: "Cart", x: 800, y: 50, width: 180, height: 60, color: "4", styleAttributes: { shape: "pill", textAlign: "center" } },
      { id: "s2b", type: "text", text: "Paid?", x: 790, y: 170, width: 200, height: 120, color: "2", styleAttributes: { shape: "diamond", textAlign: "center" } },
      { id: "s2c", type: "text", text: "Orders", x: 1080, y: 170, width: 200, height: 120, color: "5", styleAttributes: { shape: "database", textAlign: "center" } },
      { id: "s2n", type: "text", text: "**Speaker note**\nInvoices go through finance.", x: 1080, y: 40, width: 340, height: 100 },
      { id: "s3", type: "group", x: 0, y: 520, width: 760, height: 470, label: "3 - The checkout page", color: "5" },
      { id: "s3p", type: "file", file: "site/index.html", x: 30, y: 600, width: 460, height: 340, coddy: { title: "index.html" } },
      { id: "s3n", type: "text", text: "**Speaker note**\nThe page runs live: click Add to cart to show the counter.", x: 520, y: 600, width: 210, height: 200 },
      { id: "s4", type: "group", x: 900, y: 520, width: 460, height: 210, label: "4a - Paying by card", color: "4" },
      { id: "s4t", type: "text", text: "**Card**\nCharged at once; the receipt is mailed.", x: 930, y: 570, width: 400, height: 120 },
      { id: "s5", type: "group", x: 900, y: 790, width: 460, height: 210, label: "4b - Paying by invoice", color: "3" },
      { id: "s5t", type: "text", text: "**Invoice**\nFinance sends it within a day.", x: 930, y: 840, width: 400, height: 120 },
    ],
    edges: [
      { id: "t1", fromNode: "s1", fromSide: "right", toNode: "s2", toSide: "left" },
      { id: "t2", fromNode: "s2", fromSide: "bottom", toNode: "s3", toSide: "top" },
      { id: "t3", fromNode: "s3", fromSide: "right", toNode: "s4", toSide: "left", label: "a: card" },
      { id: "t4", fromNode: "s3", fromSide: "bottom", toNode: "s5", toSide: "left", label: "b: invoice" },
      { id: "t5", fromNode: "s4", fromSide: "top", toNode: "s3", toSide: "top", label: "back" },
      { id: "t6", fromNode: "s2a", fromSide: "bottom", toNode: "s2b", toSide: "top" },
      { id: "t7", fromNode: "s2b", fromSide: "right", toNode: "s2c", toSide: "left", label: "yes" },
    ],
    metadata: { version: "1.0-1.0", frontmatter: {}, startNode: "s1" },
  },

  // Stage 5: nodes of other boards embedded and linked in cards and a note.
  "canvas/plan.canvas": {
    nodes: [
      { id: "flowcard", type: "text", text: "**The flow we agreed**\n![[talk.canvas#s2]]", x: 0, y: 0, width: 420, height: 330 },
      { id: "linkcard", type: "text", text: "**Next**\nOpen the payment step: [[shop.canvas#pay]]\nThe old step was removed: [[shop.canvas#gone]]", x: 480, y: 0, width: 380, height: 150 },
      { id: "cardembed", type: "text", text: "**From the shop board**\n![[shop.canvas#cart]]", x: 480, y: 190, width: 380, height: 140 },
      { id: "note", type: "file", file: "notes/plan.md", x: 0, y: 380, width: 420, height: 260 },
    ],
    edges: [{ id: "p1", fromNode: "flowcard", fromSide: "right", toNode: "linkcard", toSide: "left" }],
    metadata: { version: "1.0-1.0", frontmatter: {} },
  },
};

// The .md notes file nodes name.
const NOTES = {
  "notes/brief.md": "# Brief\n\nThe checkout has two steps: **cart**, then **pay**. Every order goes through one checkout.\n\nFraud checks run after payment.",
  "notes/plan.md": "# Plan\n\nThe page we test: ![[shop.canvas#page]]\n\nSee [[talk.canvas#s3]] for the talk.",
};


  const SESSION = "sess_3f9c2a7d";
  const baseOf = (p) => p.split("/").pop();
  const kindOf = (n) => (n.type === "frame" ? "frame" : n.type === "file" ? (n.picture ? "picture" : n.board ? "board" : /\.md$/i.test(n.file) ? "note" : "file") : n.type);
  const plain = (t) => String(t || "").replace(/!?\[\[([^\]]+)\]\]/g, "$1").replace(/[#*_`>]/g, "").replace(/\n+/g, "\n").trim();
  const titleOf = (n) => {
    if (!n) return "?";
    if (n.type === "group") return n.label || "Group";
    if (n.type === "frame") return n.title || baseOf(n.file);
    if (n.type === "sketch" || n.type === "file") return baseOf(n.file);
    if (n.type === "link") {
      try {
        return new URL(n.url).host;
      } catch {
        return n.url;
      }
    }
    return plain(n.text).split("\n")[0].slice(0, 40) || "Card";
  };
  const kindName = (n) => ({ group: "group", text: "card", frame: "frame", note: "note", picture: "picture", board: "board", file: "file", link: "link", sketch: "sketch" })[kindOf(n)] || n.type;

  // A JSON Canvas file into the board's model: w/h, from/to, a page as a
  // frame of the inline shop page, a note with its text.
  function fromFile(doc) {
    const nodes = doc.nodes.map((n) => {
      const o = { ...clone(n), w: n.width, h: n.height };
      delete o.width;
      delete o.height;
      if (n.type === "file") {
        if (/\.html?$/i.test(n.file)) Object.assign(o, { type: "frame", page: "shop", title: n.coddy?.title || baseOf(n.file) });
        else if (/\.md$/i.test(n.file)) o.note = NOTES[n.file] ?? "";
        else if (/\.(svg|png|jpe?g|gif|webp)$/i.test(n.file)) o.picture = PICTURE;
        else if (/\.canvas$/i.test(n.file)) o.board = true;
      }
      return o;
    });
    const edges = doc.edges.map((e) => {
      const o = { ...clone(e), from: e.fromNode, to: e.toNode };
      delete o.fromNode;
      delete o.toNode;
      return o;
    });
    return { nodes, edges, metadata: clone(doc.metadata || null) };
  }
  const BOARD_FILES = () => Object.fromEntries(Object.entries(BOARDS).map(([p, d]) => [p, fromFile(d)]));

  // ---------- drawn shapes: the markup window's model, in board units ----------

  // markup/markupModel.ts, arrowGeometry.
  function arrowGeometry(a, b, width) {
    const dx = b.x - a.x, dy = b.y - a.y;
    const len = Math.hypot(dx, dy) || 1;
    const ux = dx / len, uy = dy / len;
    const head = Math.min(width * 4 + 6, len * 0.6), half = head * 0.55;
    const bx = b.x - ux * head, by = b.y - uy * head;
    return {
      shaftEnd: { x: b.x - ux * head * 0.5, y: b.y - uy * head * 0.5 },
      head: [{ x: b.x, y: b.y }, { x: bx - uy * half, y: by + ux * half }, { x: bx + uy * half, y: by - ux * half }],
    };
  }
  const labelFont = (size) => `bold ${size}px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`;
  function shapeSVG(s) {
    const st = `stroke="${s.color}" stroke-width="${s.width}" fill="none" stroke-linecap="round" stroke-linejoin="round"`;
    switch (s.kind) {
      case "pen": {
        if (s.points.length === 1) return `<circle cx="${s.points[0].x}" cy="${s.points[0].y}" r="${s.width / 2}" fill="${s.color}"/>`;
        return `<path d="M ${s.points.map((p) => `${round1(p.x)} ${round1(p.y)}`).join(" L ")}" ${st}/>`;
      }
      case "ellipse":
        return `<ellipse cx="${(s.a.x + s.b.x) / 2}" cy="${(s.a.y + s.b.y) / 2}" rx="${Math.abs(s.b.x - s.a.x) / 2}" ry="${Math.abs(s.b.y - s.a.y) / 2}" ${st}/>`;
      case "rect":
        return `<rect x="${Math.min(s.a.x, s.b.x)}" y="${Math.min(s.a.y, s.b.y)}" width="${Math.abs(s.b.x - s.a.x)}" height="${Math.abs(s.b.y - s.a.y)}" ${st} stroke-linejoin="miter"/>`;
      case "arrow": {
        const g = arrowGeometry(s.a, s.b, s.width);
        return `<path d="M ${s.a.x} ${s.a.y} L ${round1(g.shaftEnd.x)} ${round1(g.shaftEnd.y)}" ${st}/><path d="M ${g.head.map((p) => `${round1(p.x)} ${round1(p.y)}`).join(" L ")} Z" fill="${s.color}"/>`;
      }
      case "text":
        return `<text x="${s.at.x}" y="${s.at.y}" fill="${s.color}" font-family="system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif" font-weight="bold" font-size="${s.size}" dominant-baseline="hanging">${esc(s.text)}</text>`;
    }
    return "";
  }
  // Decision 8: under a shape whose colour has a relative luminance above 0.9
  // or below 0.1, the writer puts the same path in the opposite colour, one
  // and a half times as wide at 30% opacity, marked so the reader skips it.
  function luminance(hex) {
    const v = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
    return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
  }
  function outlineSVG(s) {
    if (!/^#[0-9a-f]{6}$/i.test(s.color || "")) return "";
    const l = luminance(s.color);
    if (l <= 0.9 && l >= 0.1) return "";
    const other = l > 0.9 ? "#000000" : "#ffffff";
    const o = { ...s, color: other, width: (s.width || 0) * 1.5 };
    if (s.kind === "text") {
      return `<text x="${s.at.x}" y="${s.at.y}" fill="none" stroke="${other}" stroke-width="${Math.max(2, s.size / 8)}" stroke-linejoin="round" opacity="0.3" data-coddy-outline="" font-family="system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif" font-weight="bold" font-size="${s.size}" dominant-baseline="hanging">${esc(s.text)}</text>`;
    }
    return `<g opacity="0.3" data-coddy-outline="">${shapeSVG(o).replace(/fill="(#[0-9a-f]{6})"/gi, `fill="${other}" stroke="${other}" stroke-width="${(s.width || 0) / 2}"`)}</g>`;
  }
  const drawn = (s) => outlineSVG(s) + shapeSVG(s);
  // What a person draws with in either theme: white on the dark board, black
  // on the light one (the sketches the pages start with).
  const INK = () => (new URLSearchParams(location.search).get("theme") === "light" ? "#000000" : "#ffffff");

  function shapeBox(s) {
    if (s.kind === "pen") {
      const xs = s.points.map((p) => p.x), ys = s.points.map((p) => p.y);
      return { x: Math.min(...xs), y: Math.min(...ys), width: Math.max(...xs) - Math.min(...xs), height: Math.max(...ys) - Math.min(...ys) };
    }
    if (s.kind === "text") return { x: s.at.x, y: s.at.y, width: Math.max(8, s.text.length * s.size * 0.6), height: s.size * 1.1 };
    return { x: Math.min(s.a.x, s.b.x), y: Math.min(s.a.y, s.b.y), width: Math.abs(s.b.x - s.a.x), height: Math.abs(s.b.y - s.a.y) };
  }
  function segDist(p, a, b) {
    const dx = b.x - a.x, dy = b.y - a.y;
    const l2 = dx * dx + dy * dy || 1;
    const t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2));
    return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy));
  }
  // The hit test Move and the eraser share: whole shapes, by their strokes.
  function hitShape(s, p, tol) {
    const t = tol + (s.width || 0) / 2;
    if (s.kind === "pen") {
      if (s.points.length === 1) return Math.hypot(p.x - s.points[0].x, p.y - s.points[0].y) <= t;
      for (let i = 1; i < s.points.length; i++) if (segDist(p, s.points[i - 1], s.points[i]) <= t) return true;
      return false;
    }
    if (s.kind === "arrow") return segDist(p, s.a, s.b) <= t;
    if (s.kind === "text") {
      const b = shapeBox(s);
      return p.x >= b.x - tol && p.x <= b.x + b.width + tol && p.y >= b.y - tol && p.y <= b.y + b.height + tol;
    }
    const b = shapeBox(s);
    if (s.kind === "rect") {
      const c = [{ x: b.x, y: b.y }, { x: b.x + b.width, y: b.y }, { x: b.x + b.width, y: b.y + b.height }, { x: b.x, y: b.y + b.height }];
      return c.some((q, i) => segDist(p, q, c[(i + 1) % 4]) <= t);
    }
    const cx = b.x + b.width / 2, cy = b.y + b.height / 2, rx = b.width / 2, ry = b.height / 2;
    let prev = null;
    for (let i = 0; i <= 48; i++) {
      const a = (i / 48) * Math.PI * 2;
      const q = { x: cx + rx * Math.cos(a), y: cy + ry * Math.sin(a) };
      if (prev && segDist(p, prev, q) <= t) return true;
      prev = q;
    }
    return false;
  }
  function moveShape(s, dx, dy) {
    if (s.kind === "pen") s.points = s.points.map((q) => ({ x: q.x + dx, y: q.y + dy }));
    else if (s.kind === "text") s.at = { x: s.at.x + dx, y: s.at.y + dy };
    else {
      s.a = { x: s.a.x + dx, y: s.a.y + dy };
      s.b = { x: s.b.x + dx, y: s.b.y + dy };
    }
  }
  // A hand's wobble, the same every time: a rectangle drawn with a pen.
  function rng(seed) {
    let x = seed >>> 0 || 1;
    return () => {
      x ^= x << 13;
      x ^= x >>> 17;
      x ^= x << 5;
      return ((x >>> 0) % 1000) / 1000;
    };
  }
  function handRect(x, y, w, h, color, seed, width = STROKE) {
    const r = rng(seed);
    const pts = [];
    const corners = [[x, y], [x + w, y], [x + w, y + h], [x, y + h], [x, y]];
    for (let i = 1; i < corners.length; i++) {
      const [ax, ay] = corners[i - 1], [bx, by] = corners[i];
      const steps = Math.max(3, Math.round(Math.hypot(bx - ax, by - ay) / 18));
      for (let k = 0; k < steps; k++) {
        const t = k / steps;
        pts.push({ x: ax + (bx - ax) * t + (r() - 0.5) * 3, y: ay + (by - ay) * t + (r() - 0.5) * 3 });
      }
    }
    pts.push({ x: x + (r() - 0.5) * 3, y: y + 2 });
    return { kind: "pen", color, width, points: pts };
  }
  function handLine(ax, ay, bx, by, color, seed, width = STROKE) {
    const r = rng(seed);
    const steps = Math.max(3, Math.round(Math.hypot(bx - ax, by - ay) / 16));
    const pts = [];
    for (let k = 0; k <= steps; k++) {
      const t = k / steps;
      pts.push({ x: ax + (bx - ax) * t + (r() - 0.5) * 2.5, y: ay + (by - ay) * t + (r() - 0.5) * 2.5 });
    }
    return { kind: "pen", color, width, points: pts };
  }
  function handDiamond(cx, cy, w, h, color, seed) {
    const r = rng(seed);
    const c = [[cx, cy - h / 2], [cx + w / 2, cy], [cx, cy + h / 2], [cx - w / 2, cy], [cx, cy - h / 2]];
    const pts = [];
    for (let i = 1; i < c.length; i++) {
      for (let k = 0; k < 6; k++) {
        const t = k / 6;
        pts.push({ x: c[i - 1][0] + (c[i][0] - c[i - 1][0]) * t + (r() - 0.5) * 3, y: c[i - 1][1] + (c[i][1] - c[i - 1][1]) * t + (r() - 0.5) * 3 });
      }
    }
    pts.push({ x: c[0][0], y: c[0][1] + 2 });
    return { kind: "pen", color, width: STROKE, points: pts };
  }
  const label = (x, y, text, color, size = TEXT_SIZE) => ({ kind: "text", color, size, at: { x, y }, text });
  const arrow = (ax, ay, bx, by, color) => ({ kind: "arrow", color, width: STROKE, a: { x: ax, y: ay }, b: { x: bx, y: by } });
  const ring = (ax, ay, bx, by, color) => ({ kind: "ellipse", color, width: STROKE, a: { x: ax, y: ay }, b: { x: bx, y: by } });

  // The sketches the pages start with.
  function signInSketch(ox, oy, color = INK()) {
    return [
      handRect(ox, oy, 300, 300, color, 11),
      handLine(ox + 26, oy + 36, ox + 150, oy + 34, color, 12),
      handRect(ox + 24, oy + 76, 252, 40, color, 13),
      label(ox + 34, oy + 86, "email", color, 18),
      handRect(ox + 24, oy + 140, 252, 40, color, 14),
      label(ox + 34, oy + 150, "password", color, 18),
      handRect(ox + 24, oy + 212, 130, 44, color, 15),
      label(ox + 40, oy + 224, "sign in", color, 18),
    ];
  }
  function flowSketch(ox, oy, color = "#ffcc00") {
    return [
      handRect(ox, oy, 130, 56, color, 21),
      label(ox + 22, oy + 16, "order", color, 18),
      arrow(ox + 65, oy + 60, ox + 65, oy + 120, color),
      handDiamond(ox + 65, oy + 170, 150, 90, color, 22),
      label(ox + 38, oy + 160, "paid?", color, 18),
      arrow(ox + 142, oy + 170, ox + 250, oy + 170, color),
      label(ox + 180, oy + 138, "yes", color, 16),
      handRect(ox + 256, oy + 144, 120, 54, color, 23),
      label(ox + 282, oy + 160, "ship", color, 18),
    ];
  }
  // A clean picture the agent writes for "A tidy picture": an SVG file.
  function tidyPicture(kind, dark) {
    const fg = dark ? "#e6e7ea" : "#1d1f24";
    const ac = "#a882ff";
    const t = (x, y, s, size = 16, w = 600) => `<text x="${x}" y="${y}" font-family="system-ui,sans-serif" font-size="${size}" font-weight="${w}" fill="${fg}">${esc(s)}</text>`;
    let inner = "";
    if (kind === "signin") {
      inner = `<rect x="20" y="20" width="320" height="300" rx="12" fill="none" stroke="${fg}" stroke-width="2"/>${t(44, 62, "Sign in to Acme", 20, 700)}
        <rect x="44" y="92" width="272" height="40" rx="6" fill="none" stroke="${fg}" stroke-width="1.5"/>${t(56, 117, "Email", 14, 400)}
        <rect x="44" y="152" width="272" height="40" rx="6" fill="none" stroke="${fg}" stroke-width="1.5"/>${t(56, 177, "Password", 14, 400)}
        <rect x="44" y="222" width="272" height="44" rx="8" fill="${ac}"/>${t(150, 249, "Sign in", 15, 700).replace(`fill="${fg}"`, 'fill="#ffffff"')}`;
      return { w: 360, h: 340, svg: inner };
    }
    const box = (x, y, w, h, s) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" fill="none" stroke="${fg}" stroke-width="2"/>${t(x + 14, y + h / 2 + 6, s)}`;
    const ar = (x1, y1, x2, y2) => `<path d="M${x1} ${y1} L${x2} ${y2}" stroke="${fg}" stroke-width="2"/><path d="M${x2} ${y2} l-6 -10 l12 0 z" fill="${fg}" transform="rotate(${(Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI - 90} ${x2} ${y2})"/>`;
    inner = box(30, 20, 130, 50, "Order") + ar(95, 70, 95, 120) + `<path d="M95 120 L170 170 L95 220 L20 170 Z" fill="none" stroke="${fg}" stroke-width="2"/>${t(70, 176, "Paid?")}` + ar(170, 170, 250, 170) + t(195, 160, "yes", 13, 400) + box(250, 145, 120, 50, "Ship");
    if (kind === "refund") inner += ar(95, 220, 95, 270) + t(104, 252, "no", 13, 400) + box(30, 270, 130, 50, "Refund");
    return { w: 400, h: kind === "refund" ? 340 : 240, svg: inner };
  }
  const svgDataUrl = (w, h, inner) =>
    "data:image/svg+xml," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${inner}</svg>`);

  // ---------- pages inside frames, inline ----------

  const INLINE = {
    shop: (n) => `<header>Acme<nav><a href="#">Catalog</a><a href="#">About</a></nav></header>
      <main><h1>Welcome to the shop</h1><p>Everything for the workshop, delivered tomorrow.</p>
      <button type="button" data-kp-action="cart">Add to cart</button><span class="kp-count">in the cart: <b data-kp-count>${n.count || 0}</b></span>
      <p class="kp-live" style="margin-top:14px;font-size:12px">Visitors now: <b data-kp-live>${n.live || 12}</b></p></main>`,
    login: () => `<div class="kp-login"><h1>Sign in to Acme</h1><label>Email</label><input type="text" value="" placeholder="you@example.com">
      <label>Password</label><input type="password" value="" placeholder="········"><button type="button" data-kp-action="signin">Sign in</button>
      <a class="kp-forgot" href="#">Forgot password?</a><p class="kp-said" data-kp-said hidden>Signed in: the page runs live on the board.</p></div>`,
    status: () => `<header>Acme<nav><a href="#">Orders</a></nav></header><main><h1>Order 1042</h1><p>Paid: yes</p><p>Status: shipped today</p><button type="button" data-kp-action="cart">Track</button></main>`,
  };

  // What the link scan finds in the workspace (#606, Stage 4: the resolver's rules).
  const NOTE_LINKS = {
    "notes/brief.md": { out: ["notes/catalog.md", "notes/checkout.md", "notes/pricing.md", "notes/roadmap.md"], skipped: ["<code>[[plan]]</code>: 2 files match, none in <code>notes/</code> (<code>notes/archive/plan.md</code>, <code>archive/plan.md</code>)", "<code>site/index.html</code>: a page, <code>canvas_show</code> puts it on"] },
    "notes/pricing.md": { in: ["notes/brief.md", "notes/faq.md"] },
    "notes/faq.md": { out: ["notes/pricing.md"] },
  };

  // ---------- the board ----------

  let nextId = 1;
  const newId = (p = "n") => `${p}${(Date.now() % 100000).toString(16)}${(nextId++).toString(16).padStart(4, "0")}`;

  let ACTIVE = null;
  function createBoard(pane, cfg) {
    // Both issues have landed: every slide edits, draws and goes full screen.
    cfg = { edit: true, draw: true, fullscreen: true, ...cfg };
    const path0 = cfg.path || `canvas/${cfg.board || "shop"}.canvas`;
    // The workspace's boards, for the links and embeds of #570, Stage 5; the
    // board on screen is the slide's own when it brings its nodes.
    const docs = cfg.docs || BOARD_FILES();
    if (cfg.nodes) docs[path0] = { nodes: clone(cfg.nodes), edges: clone(cfg.edges || []), metadata: clone(cfg.metadata || null) };
    const S = {
      path: path0,
      open: [path0],
      meta: docs[path0].metadata,
      shown: new Set(), // collapsed groups this viewer looks into (#570, Stage 3)
      focus: false, // #570, Stage 2
      readOnly: false,
      today: false, // drawn as Coddy draws the file today, for comparison
      pres: null, // #570, Stage 4
      conflictArmed: false,
      unloaded: new Set(), // frames unloaded at this zoom (#570, Decision 8)
      lastFrame: "",
      nodes: docs[path0].nodes,
      edges: docs[path0].edges,
      mode: "interact",
      sel: new Set(),
      selEdge: null,
      editing: null, // {id, draft, before, conflict}
      cam: { x: 0, y: 0, scale: 1 },
      fitted: true,
      undo: [],
      redo: [],
      hover: null,
      picks: [],
      busy: false,
      draw: null, // {tool, color, shapes, sel:Set, stack, editing, done}
      fullscreen: false,
      sketchNo: cfg.sketchNo || 1,
    };
    const B = cfg.board || "shop";
    const modeBtn = (key, labelText, title) =>
      `<button type="button" class="canvas-mode-btn" aria-pressed="false" data-testid="canvas-mode-${key}" data-kp-mode="${key}" title="${esc(title)}">${labelText}</button>`;
    pane.innerHTML = `<div class="canvas-board" data-testid="canvas-board" tabindex="0">
        <div class="canvas-world" data-testid="canvas-world"></div>
        <div class="canvas-mode" role="group" aria-label="What a click does">${modeBtn("interact", "Interact", "Clicks go to the pages")}${modeBtn("comment", "Comment", "A click picks an element to tell the agent about")}${
          cfg.draw ? modeBtn("draw", "Draw", "Draw on the board: the markup window's tools") : ""
        }</div>
        ${cfg.fullscreen ? '<div class="zoom-controls kp-fs-controls" role="group" aria-label="Full screen"><button type="button" class="zoom-control kp-fs-btn" title="Full screen (F)">' + svgIcon('<path d="M4 9V4h5"/><path d="M20 9V4h-5"/><path d="M4 15v5h5"/><path d="M20 15v5h-5"/>', 16) + '<span class="kp-fs-text">Full screen</span><span class="kp-kbd">F</span></button></div>' : ""}
        ${PHONE ? `<button type="button" class="zoom-controls cv-search-btn" aria-label="Search the board" title="Search the board">${ICONS.search}</button>` : ""}
        ${FRAGS.zoom}
        <div class="kp-draw-capture" hidden></div>
      </div>
      <section class="canvas-prompts" data-testid="canvas-prompts" aria-label="The agent is waiting for your answer" hidden></section>
      <div class="kp-notice" role="status" hidden></div>
      <div class="kp-bar-host"></div>`;
    const board = $(".canvas-board", pane);
    const world = $(".canvas-world", pane);
    const capture = $(".kp-draw-capture", pane);
    const prompts = $(".canvas-prompts", pane);
    const notice = $(".kp-notice", pane);
    const barHost = $(".kp-bar-host", pane);
    const FIT_GLYPH = $('[data-testid="canvas-fit"]', board).innerHTML;
    const api = { S, board, world, pane, render, fit, write, toast, setMode, renderBar, startDraw, select, nodeById: (id) => S.nodes.find((n) => n.id === id) };

    // ----- camera -----
    function applyCam() {
      world.style.transform = `translate(${S.cam.x}px, ${S.cam.y}px) scale(${S.cam.scale})`;
      board.style.setProperty("--canvas-scale", String(S.cam.scale));
      board.style.setProperty("--canvas-inv", String(1 / S.cam.scale));
      $('[data-testid="canvas-fit"]', board).innerHTML = S.fitted ? FIT_GLYPH : `${Math.round(S.cam.scale * 100)}%`;
      placeLabelInput();
      settleSoon();
      placeNotes();
    }
    const boundsOf = (rs) => {
      const x = Math.min(...rs.map((r) => r.x)), y = Math.min(...rs.map((r) => r.y));
      return { x, y, width: Math.max(...rs.map((r) => r.x + r.width)) - x, height: Math.max(...rs.map((r) => r.y + r.height)) - y };
    };
    // What lies under the board's bottom edge: Draw's toolbar, or the
    // presentation's controls.
    const roomBottom = () => (S.draw ? $(".kp-draw-bar", board)?.offsetHeight || 70 : S.pres ? 64 : 0);
    function fitTo(b, opts = {}) {
      const vw = board.clientWidth, vh = board.clientHeight - roomBottom() - (opts.roomTop || 0);
      const k = clampScale(Math.min(opts.max ?? 1, (vw - FIT_PADDING * 2) / b.width, (vh - FIT_PADDING * 2 - TITLE_ROOM) / b.height));
      S.cam = { scale: k, x: (vw - b.width * k) / 2 - b.x * k, y: (opts.roomTop || 0) + TITLE_ROOM + (vh - TITLE_ROOM - b.height * k) / 2 - b.y * k };
      S.fitted = !!opts.all;
      S.camSet = true;
      applyCam();
    }
    function fit(ids) {
      const hidden = hiddenSet();
      const ns = S.nodes.filter((n) => (!ids || ids.includes(n.id)) && !hidden.has(n.id));
      const shapes = S.draw ? S.draw.shapes.map(shapeBox) : [];
      const rs = ns.map(rectFor).concat(shapes);
      if (!rs.length) return;
      fitTo(boundsOf(rs), { all: !ids });
    }
    function selectionRects() {
      const out = [];
      for (const id of S.sel) {
        if (id.startsWith("e:")) {
          const e = S.edges.find((x) => x.id === id.slice(2));
          if (e) [e.from, e.to].forEach((nid) => nodeById(nid) && out.push(rectFor(nodeById(nid))));
        } else if (nodeById(id)) out.push(rectFor(nodeById(id)));
      }
      if (S.selEdge) {
        const e = S.edges.find((x) => x.id === S.selEdge);
        if (e) [e.from, e.to].forEach((nid) => nodeById(nid) && out.push(rectFor(nodeById(nid))));
      }
      return out;
    }
    function zoomToSelection() {
      const rs = selectionRects();
      if (!rs.length) return toast("Nothing is selected: Zoom to selection fits the selected nodes.");
      fitTo(boundsOf(rs));
    }
    // Bring a node into view without changing the zoom unless it does not fit.
    function reveal(n) {
      const r = rectFor(n);
      const sx = S.cam.x + r.x * S.cam.scale, sy = S.cam.y + r.y * S.cam.scale;
      const inView = sx >= 0 && sy >= 30 && sx + r.width * S.cam.scale <= board.clientWidth && sy + r.height * S.cam.scale <= board.clientHeight - roomBottom();
      if (!inView) fitTo(boundsOf([r]), { max: Math.max(S.cam.scale, 0.6) });
    }
    // Detail by zoom (#570, Decision 8): a frame drawn narrower than 320 px is
    // unloaded once a zoom settles, and loads again above 384. Nothing waits
    // for a timer until the page has opened on its step.
    let settleTimer = 0;
    let booted = false;
    function settleSoon() {
      clearTimeout(settleTimer);
      if (booted) settleTimer = setTimeout(settle, 250);
    }
    function settle() {
      if (S.today) return;
      let changed = false;
      for (const f of S.nodes.filter((n) => n.type === "frame")) {
        const w = f.w * S.cam.scale;
        const slide = S.pres && S.pres.visited.at(-1);
        const keep = f.id === S.lastFrame || (slide && membersOrSelf(slide).includes(f.id));
        if (!keep && w < 320 && !S.unloaded.has(f.id)) {
          S.unloaded.add(f.id);
          changed = true;
        } else if ((w > 384 || keep) && S.unloaded.has(f.id)) {
          S.unloaded.delete(f.id);
          changed = true;
        }
      }
      if (changed) render();
    }
    api.boot = () => {
      settle();
      booted = true;
    };
    api.zoomBy = (f) => zoomAt(f, ...center());
    api.fitNode = (id, max = 1) => fitTo(boundsOf([rectFor(nodeById(id))]), { max });
    api.zoomToSelection = () => zoomToSelection();
    api.copyLink = (id) => copyLink(id);
    function zoomAt(factor, fx, fy) {
      const k = clampScale(S.cam.scale * factor);
      S.cam = { scale: k, x: fx - ((fx - S.cam.x) * k) / S.cam.scale, y: fy - ((fy - S.cam.y) * k) / S.cam.scale };
      S.fitted = false;
      S.camSet = true;
      applyCam();
    }
    const center = () => [board.clientWidth / 2, board.clientHeight / 2];
    $('[data-testid="canvas-zoom-in"]', board).onclick = () => zoomAt(ZOOM_STEP, ...center());
    $('[data-testid="canvas-zoom-out"]', board).onclick = () => zoomAt(1 / ZOOM_STEP, ...center());
    $('[data-testid="canvas-fit"]', board).onclick = () => fit();
    board.addEventListener(
      "wheel",
      (e) => {
        if (S.pres) return e.preventDefault(); // #570, Stage 4: no pan or zoom while presenting
        if (e.target.closest(".cv-search-results, .cv-menu")) return;
        if (e.target.closest(".kp-inline-page") && S.mode === "interact") return;
        e.preventDefault();
        const r = board.getBoundingClientRect();
        zoomAt(2 ** (-e.deltaY / 500), e.clientX - r.left, e.clientY - r.top);
      },
      { passive: false },
    );
    const toBoard = (cx, cy) => {
      const r = board.getBoundingClientRect();
      return { x: (cx - r.left - S.cam.x) / S.cam.scale, y: (cy - r.top - S.cam.y) / S.cam.scale };
    };
    const toScreen = (p) => ({ x: p.x * S.cam.scale + S.cam.x, y: p.y * S.cam.scale + S.cam.y });

    // ----- writes and undo: one contract for both issues (#570, Stage 3) -----
    // A write enters the one undo history; the read-only view writes nothing;
    // a conflict armed by the mockup answers 409 and writes nothing.
    function guard(what) {
      if (S.readOnly) {
        toastHtml(`<strong>Read-only view:</strong> nothing is written. ${esc(what)} needs the board to be editable.`);
        return false;
      }
      if (S.conflictArmed) {
        S.conflictArmed = false;
        remoteEdit();
        toastHtml("<strong>409:</strong> the file moved since the board read it. The board took the current values and wrote nothing; this step is not in the undo history.", 6000);
        return false;
      }
      return true;
    }
    api.guard = guard;
    // Another window changes the file under the board.
    function remoteEdit() {
      const n = S.nodes.find((x) => x.type === "text");
      if (n) n.color = n.color === "3" ? "6" : "3";
      render();
    }
    const snapshot = () => ({ path: S.path, nodes: clone(S.nodes), edges: clone(S.edges), meta: clone(S.meta ?? null) });
    api.snapshot = snapshot;
    function write(text, fn, opts = {}) {
      if (!guard(text.split(":")[0])) return false;
      S.undo.push({ ...snapshot(), text });
      S.redo = [];
      fn();
      render();
      if (!opts.quiet) toast(text);
      cfg.onWrite?.(text, api);
      return true;
    }
    // #570's writes show the request they send.
    function writeReq({ what, route, body: payload, apply, undoable = true }) {
      if (!guard(what)) return false;
      if (undoable) {
        S.undo.push({ ...snapshot(), text: what });
        S.redo = [];
      }
      apply();
      render();
      toastHtml(`<strong>${esc(what)}</strong><code class="cv-req">${esc(route)} ${esc(JSON.stringify(payload))}</code><span class="cv-undo-hint">${undoable ? `${MOD}+Z undoes it` : "outside undo: it asked first"}</span>`, 4200);
      cfg.onWrite?.(what, api);
      return true;
    }
    api.writeReq = writeReq;
    function put(u) {
      S.nodes = u.nodes;
      S.edges = u.edges;
      S.meta = u.meta;
      S.sel.clear();
      S.selEdge = null;
      render();
    }
    function undo() {
      if (S.readOnly) return toastHtml("<strong>Read-only view:</strong> nothing to undo here.");
      const u = S.undo.pop();
      if (!u) return toast("Nothing to undo: the history keeps this page's own writes.");
      if (u.path !== S.path) switchBoard(u.path, () => {});
      S.redo.push({ ...snapshot(), text: u.text });
      put(u);
      toast(`Undone: ${u.text.split(":")[0]}.`);
      cfg.onUndo?.(api);
    }
    function redo() {
      const r = S.redo.pop();
      if (!r) return;
      if (r.path !== S.path) switchBoard(r.path, () => {});
      S.undo.push({ ...snapshot(), text: r.text });
      put(r);
      toast(`Redone: ${r.text.split(":")[0]}.`);
    }
    api.undo = undo;

    // ----- rendering, in Coddy's markup -----
    const nodeById = (id) => S.nodes.find((n) => n.id === id);
    // #570, Stage 1: a collapsed group is drawn as its bar at its stored
    // place, its members hidden, unless this viewer looks inside.
    function membersOf(g) {
      return S.nodes.filter((n) => n !== g && strictlyInside(n, g));
    }
    function isFolded(g) {
      return !S.today && g.type === "group" && g.collapsed && !S.shown.has(g.id);
    }
    function barRect(g) {
      return { x: g.x, y: g.y, width: Math.min(g.w, 320), height: 48 };
    }
    function rectFor(n) {
      return isFolded(n) ? barRect(n) : rectOf(n);
    }
    function hiddenSet() {
      const h = new Set();
      if (S.today) return h;
      for (const g of S.nodes) if (isFolded(g)) for (const m of membersOf(g)) h.add(m.id);
      return h;
    }
    function membersOrSelf(id) {
      const n = nodeById(id);
      return n?.type === "group" ? [id, ...membersOf(n).map((m) => m.id)] : [id];
    }
    // Ranks inside a layer, as the plugin 7.1.0 ranks nodes on open: walking
    // nodes in file order with a counter from 1, a node without zIndex takes
    // the counter plus one, a node with one takes it and raises the counter.
    function ranked(list) {
      if (S.today) return list;
      let counter = 1;
      const rank = new Map();
      for (const n of S.nodes) {
        if (typeof n.zIndex === "number") {
          rank.set(n.id, n.zIndex);
          counter = Math.max(counter, n.zIndex);
        } else rank.set(n.id, ++counter);
      }
      return list.map((n, i) => [n, i]).sort((x, y) => rank.get(x[0].id) - rank.get(y[0].id) || x[1] - y[1]).map(([n]) => n);
    }
    const isSel = (id) => S.sel.has(id);
    function nodeStyle(n) {
      const c = canvasColor(n.color);
      return `left: ${n.x}px; top: ${n.y}px; width: ${n.w}px; height: ${n.h}px;${c ? ` --canvas-node-color: ${c};` : ""}`;
    }
    const baseName = (p) => p.split("/").pop();
    function bodyHTML(n) {
      if (S.editing && S.editing.id === n.id)
        return `<textarea class="kp-card-editor" spellcheck="false" aria-label="Card text, Markdown">${esc(S.editing.draft)}</textarea><span class="kp-card-hint">Esc cancels · saved on blur</span>`;
      const st = S.today ? {} : n.styleAttributes || {};
      if (n.type === "text") {
        if (n.mermaid) return `<div class="canvas-node-text">${FRAGS.mermaid[n.mermaid]}</div>`;
        return `<div class="canvas-node-text"${st.textAlign ? ` style="text-align: ${st.textAlign}"` : ""}><div class="md">${md(n.text)}</div></div>`;
      }
      if (n.type === "link") {
        let host = n.url;
        try {
          host = new URL(n.url).host;
        } catch {
          /* as written */
        }
        return `<div class="canvas-node-card"><span class="canvas-node-kind">Link</span><span class="canvas-node-name">${esc(host)}</span><a class="canvas-node-url" href="${esc(n.url)}" target="_blank" rel="noopener noreferrer">${esc(n.url)}</a></div>`;
      }
      if (n.picture) return `<img class="canvas-node-image" alt="${esc(baseName(n.file))}" draggable="false" data-image-name="${esc(baseName(n.file))}" src="${n.picture}">`;
      if (/\.md$/.test(n.file)) return `<div class="canvas-node-text canvas-node-note"><p class="canvas-node-note-name">${esc(baseName(n.file))}</p><div class="md">${md(n.note || "")}</div></div>`;
      const folder = n.file.includes("/") ? n.file.slice(0, n.file.lastIndexOf("/")) : "";
      const open = n.board ? `<button type="button" class="canvas-node-open cv-open-board" data-file="${esc(n.file)}">Open board</button>` : "";
      return `<div class="canvas-node-card"><span class="canvas-node-kind">File</span><span class="canvas-node-name" title="${esc(n.file)}">${esc(baseName(n.file))}</span>${folder ? `<span class="canvas-node-folder">${esc(folder)}</span>` : ""}${open}</div>`;
    }
    function groupHTML(g) {
      const c = canvasColor(g.color);
      const sel = isSel(g.id) ? " is-selected" : "";
      const colour = c ? ` --canvas-node-color: ${c};` : "";
      if (isFolded(g)) {
        const r = barRect(g);
        return `<div class="canvas-group cv-folded${c ? " is-colored" : ""}${sel}" data-testid="canvas-group" data-node-id="${g.id}" style="left: ${r.x}px; top: ${r.y}px; width: ${r.width}px; height: ${r.height}px;${colour}" title="Show the members to you; writes nothing">
          <span class="cv-folded-icon">${ICONS.expand}</span><span class="cv-folded-label">${esc(g.label || "Group")}</span><span class="cv-folded-count">${membersOf(g).length} hidden</span></div>`;
      }
      const peek = !S.today && g.collapsed && S.shown.has(g.id);
      const bg = !S.today && g.background ? ` background-image: url('${PAPER}'); background-repeat: ${g.backgroundStyle === "repeat" ? "repeat" : "no-repeat"}; background-size: ${g.backgroundStyle === "repeat" ? "28px 28px" : "cover"};` : "";
      return `<div class="canvas-group${c ? " is-colored" : ""}${sel}${peek ? " cv-peek" : ""}" data-testid="canvas-group" data-node-id="${g.id}" style="${nodeStyle(g)}${bg}">${
        g.label || peek ? `<span class="canvas-group-label">${peek ? `${ICONS.collapse} ` : ""}${esc(g.label || "")}${peek ? " · shown to you" : ""}</span>` : ""
      }</div>`;
    }
    function nodeHTML(n) {
      if (n.type === "group") return groupHTML(n);
      const c = canvasColor(n.color);
      const sel = isSel(n.id) ? " is-selected" : "";
      const st = S.today ? {} : n.styleAttributes || {};
      const shape = st.shape && st.shape !== "rectangle" ? st.shape : "";
      const border = st.border && st.border !== "solid" ? ` cv-border-${st.border}` : "";
      const kind = n.type === "link" ? "link" : n.type === "file" ? "file" : "text";
      const editing = S.editing && S.editing.id === n.id ? " is-editing" : "";
      return `<div class="canvas-node canvas-node--${kind}${c ? " is-colored" : ""}${shape ? ` cv-has-shape cv-shape-${shape}` : ""}${border}${sel}${editing}" data-testid="canvas-node" data-node-id="${n.id}" data-node-type="${kind}" style="${nodeStyle(n)}">${shape ? shapeSvg(shape, n.w, n.h) : ""}<div class="canvas-node-body">${bodyHTML(n)}</div></div>`;
    }
    const FRAME_BTNS = FRAGS.frameActions;
    function frameHTML(n) {
      const sel = isSel(n.id) ? " is-selected" : "";
      const page = S.unloaded.has(n.id)
        ? `<div class="canvas-frame-page cv-frame-placeholder"><strong>${esc(n.title)}</strong><span>${esc(n.file)}</span><span>Unloaded at this zoom: it loads again when you zoom in</span></div>`
        : `<div class="canvas-frame-page kp-inline-page" role="document" aria-label="${esc(n.title)}">${INLINE[n.page](n)}</div>`;
      return `<div class="canvas-frame-bar${sel}" data-testid="canvas-frame-bar" data-frame-id="${n.id}" style="left: ${n.x}px; top: ${n.y}px; --canvas-frame-width: ${n.w};"><span class="canvas-frame-title" title="${esc(n.file)}">${esc(n.title)}</span><span class="canvas-frame-size">${n.w}x${n.h}</span><span class="canvas-frame-actions">${FRAME_BTNS}</span></div>
        <div class="canvas-frame${sel}" data-testid="canvas-frame" data-frame-id="${n.id}" data-node-id="${n.id}" style="left: ${n.x}px; top: ${n.y}px; width: ${n.w}px; height: ${n.h}px;">${page}</div>`;
    }
    function sketchHTML(n) {
      const sel = isSel(n.id) ? " is-selected" : "";
      const hidden = S.draw && S.draw.editing === n.id ? ' style="display:none"' : "";
      return `<div class="kp-sketch${sel}" data-node-id="${n.id}" data-node-type="sketch" data-file="${esc(n.file)}" style="left: ${n.x}px; top: ${n.y}px; width: ${n.w}px; height: ${n.h}px;${hidden ? " display:none;" : ""}">${
        sel ? `<span class="kp-sketch-name">${esc(n.file)}${n.over?.length ? ` · over ${n.over.length} node${n.over.length === 1 ? "" : "s"}` : ""}</span>` : ""
      }<svg class="kp-sketch-svg" width="${n.w}" height="${n.h}" viewBox="${n.x} ${n.y} ${n.w} ${n.h}">${n.shapes.map(drawn).join("")}</svg></div>`;
    }
    function rectsMap() {
      const hidden = hiddenSet();
      return new Map(S.nodes.filter((n) => !hidden.has(n.id)).map((n) => [n.id, rectFor(n)]));
    }
    const edgeSelected = (e) => S.selEdge === e.id || S.sel.has(`e:${e.id}`);
    function render() {
      LINKS = linksOfBoard;
      const hidden = hiddenSet();
      const visible = S.nodes.filter((n) => !hidden.has(n.id));
      const rects = rectsMap();
      const groups = ranked(visible.filter((n) => n.type === "group"));
      const cards = ranked(visible.filter((n) => n.type !== "group" && n.type !== "frame" && n.type !== "sketch"));
      const frames = ranked(visible.filter((n) => n.type === "frame"));
      const sketches = visible.filter((n) => n.type === "sketch");
      const shapes = S.edges.map((e) => ({ e, s: edgeShape(e, rects) })).filter((x) => x.s);
      // #570, Stage 2: the edges of the selection are highlighted, the ones
      // between two selected nodes more.
      const hl = new Set(S.edges.filter((e) => S.sel.has(e.from) || S.sel.has(e.to)).map((e) => e.id));
      const between = new Set(S.edges.filter((e) => S.sel.has(e.from) && S.sel.has(e.to)).map((e) => e.id));
      let html = groups.map(nodeHTML).join("");
      if (shapes.length) {
        html += `<svg class="canvas-edges" aria-hidden="true" data-testid="canvas-edges">${shapes
          .map(({ e, s }) => {
            const c = canvasColor(e.color);
            const st = S.today ? {} : e.styleAttributes || {};
            const cls = [c ? "is-colored" : "", st.path && st.path !== "solid" ? `cv-path-${st.path}` : "", edgeSelected(e) ? "kp-edge-selected" : "", hl.has(e.id) ? "cv-hl" : "", between.has(e.id) ? "cv-between" : ""].filter(Boolean).join(" ");
            const arrows = S.today ? s.arrows.slice(0, 1).map(() => `<polygon class="canvas-edge-arrow" points="${arrowAt(s.pts[3], s.pts[2], 14)}"></polygon>`) : s.arrows;
            return `<g data-edge-id="${e.id}"${c ? ` style="color: ${c};"` : ""}${cls ? ` class="${cls}"` : ""}><path class="canvas-edge" d="${s.d}"></path>${arrows.join("")}</g>`;
          })
          .join("")}</svg>`;
        html += `<svg class="kp-edge-hits" aria-hidden="true">${shapes.map(({ e, s }) => `<path data-edge-id="${e.id}" d="${s.d}"></path>`).join("")}</svg>`;
        html += shapes
          .map(({ e, s }) =>
            S.editEdge === e.id
              ? `<input class="kp-edge-editor" data-edge-id="${e.id}" aria-label="Edge label" value="${esc(e.label || "")}" style="left: ${s.mid.x}px; top: ${s.mid.y}px;">`
              : e.label
                ? `<span class="canvas-edge-label${edgeSelected(e) ? " is-selected" : ""}" data-edge-id="${e.id}" style="left: ${s.mid.x}px; top: ${s.mid.y}px;">${esc(e.label)}</span>`
                : "",
          )
          .join("");
      }
      html += cards.map(nodeHTML).join("");
      html += frames.map(frameHTML).join("");
      html += sketches.map(sketchHTML).join("");
      if (S.hover && cfg.edit && S.mode === "interact" && !S.drag && !S.pres && !S.readOnly) {
        const n = S.nodes.find((x) => x.id === S.hover);
        if (n && n.type !== "sketch" && !hidden.has(n.id))
          for (const side of ["top", "right", "bottom", "left"]) {
            const p = sideAnchor(rectFor(n), side);
            html += `<span class="kp-handle" data-node-id="${n.id}" data-side="${side}" title="Drag to another node for an edge" style="left: ${p.x}px; top: ${p.y}px;"></span>`;
          }
      }
      if (S.tempEdge) html += `<svg class="kp-edge-temp" aria-hidden="true"><path d="${S.tempEdge}"></path></svg>`;
      if (S.conflict) html += conflictHTML();
      html += `<svg class="kp-draw-layer" aria-hidden="true">${drawLayer()}</svg>`;
      world.innerHTML = html;
      // #570, Stage 2: Focus dims what is not selected.
      const dim = S.focus && (S.sel.size > 0 || S.selEdge);
      board.classList.toggle("cv-focus", !!dim);
      board.classList.toggle("cv-today", S.today);
      if (dim) {
        $$(".canvas-node, .canvas-group, .canvas-frame, .canvas-frame-bar, .kp-sketch", world).forEach((x) => x.classList.toggle("cv-dim", !S.sel.has(x.dataset.nodeId || x.dataset.frameId)));
        $$(".canvas-edges g", world).forEach((g) => g.classList.toggle("cv-dim", !between.has(g.dataset.edgeId) && !S.sel.has(`e:${g.dataset.edgeId}`) && S.selEdge !== g.dataset.edgeId));
      }
      renderTabs();
      afterRender();
    }
    api.renderNow = render;

    // ----- #570, Stage 5: the workspace's boards, the tabs, node links and embeds -----
    function renderTabs() {
      const tabs = $(".files-tabs");
      if (!tabs) return;
      tabs.innerHTML = S.open
        .map((p) => `<div class="files-tab${p === S.path ? " is-active" : ""}" title="${esc(p)}"><button type="button" role="tab" aria-selected="${p === S.path}" class="files-tab-name" data-path="${esc(p)}">${esc(baseOf(p))}</button><button type="button" class="files-tab-close" aria-label="Close ${esc(baseOf(p))}" data-path="${esc(p)}">×</button></div>`)
        .join("");
    }
    $(".files-tabs")?.addEventListener("click", (e) => {
      const b = e.target.closest(".files-tab-name[data-path]");
      if (b) switchBoard(b.dataset.path);
    });
    function switchBoard(p, then) {
      if (!docs[p]) return toast(`No board ${p} in the workspace.`);
      if (S.draw) return toast("Leave Draw first: Done keeps the strokes, Cancel asks before it drops them.");
      if (S.pres) endPresentation();
      closeSearch();
      closeMenus();
      docs[S.path] = { nodes: S.nodes, edges: S.edges, metadata: S.meta };
      if (!S.open.includes(p)) S.open.push(p);
      S.path = p;
      S.nodes = docs[p].nodes;
      S.edges = docs[p].edges;
      S.meta = docs[p].metadata;
      S.sel.clear();
      S.selEdge = null;
      S.focus = false;
      S.shown.clear();
      S.unloaded.clear();
      render();
      if (then) then();
      else fit();
    }
    api.switchBoard = switchBoard;
    const resolveBoard = (name) => Object.keys(docs).find((p) => p === name || baseOf(p) === name);
    const boardNodes = (p) => (p === S.path ? S.nodes : docs[p]?.nodes || []);
    function linkTo(f, id) {
      const p = resolveBoard(f);
      const n = p && boardNodes(p).find((x) => x.id === id);
      return `<a href="#" class="cv-node-link${n ? "" : " is-missing"}" data-board="${esc(p || f)}" data-node="${esc(id)}" title="${esc(`${f}#${id}`)}">${esc(f.replace(/\.canvas$/, ""))} › ${esc(n ? titleOf(n) : id)}</a>`;
    }
    // A node of a board shown in place: a card as its text, a group drawn
    // small, a frame as a placeholder, a picture as the picture.
    function embed(f, id) {
      const p = resolveBoard(f);
      const n = p && boardNodes(p).find((x) => x.id === id);
      if (!n) return `<div class="cv-embed is-missing">${linkTo(f, id)}<span class="cv-embed-note">no such node on the board</span></div>`;
      const k = kindOf(n);
      const head = `<div class="cv-embed-head">${esc(baseOf(p))} · ${esc(kindName(n))}${linkTo(f, id).replace("cv-node-link", "cv-node-link cv-embed-open").replace(/>[^<]*<\/a>$/, ">open</a>")}</div>`;
      if (k === "text") return `<div class="cv-embed">${head}<div class="md">${md(n.text, 1)}</div></div>`;
      if (k === "frame") return `<div class="cv-embed">${head}<div class="cv-frame-placeholder"><strong>${esc(titleOf(n))}</strong><span>${esc(n.file)}</span><span>Not running here: opens on its board</span></div></div>`;
      if (k === "picture") return `<div class="cv-embed">${head}<img class="cv-embed-picture" src="${n.picture}" alt=""></div>`;
      if (n.type === "group") {
        const s = 260 / n.w;
        const boxes = boardNodes(p)
          .filter((m) => m !== n && strictlyInside(m, n))
          .map((m) => {
            const c = canvasColor(m.color);
            const label = kindOf(m) === "frame" ? titleOf(m) : plain(m.text || titleOf(m)).split("\n")[0];
            return `<span class="cv-mini-node${m.styleAttributes?.shape ? ` cv-mini-${m.styleAttributes.shape}` : ""}" style="left:${(m.x - n.x) * s}px;top:${(m.y - n.y) * s}px;width:${m.w * s}px;height:${m.h * s}px;${c ? `--canvas-node-color:${c};` : ""}">${esc(label)}</span>`;
          })
          .join("");
        return `<div class="cv-embed">${head}<div class="cv-mini" style="height:${n.h * s}px"><span class="cv-mini-label">${esc(n.label)}</span>${boxes}</div></div>`;
      }
      return `<div class="cv-embed">${head}<p>${esc(titleOf(n))}</p></div>`;
    }
    const linksOfBoard = { linkTo, embed };
    // #570, Stage 2: a node in the address, and a link to a node.
    function openNodeLink(f, id) {
      const target = resolveBoard(f) || f;
      if (!docs[target]) return toast(`No board ${f} in the workspace: the link stays text.`);
      const go = () => {
        const n = nodeById(id);
        if (!n) {
          fit();
          return toastHtml(`The board no longer holds <code class="cv-req">${esc(id)}</code>: it opens fitted.`);
        }
        for (const g of S.nodes) if (g.type === "group" && g.collapsed && strictlyInside(n, g)) S.shown.add(g.id);
        S.sel = new Set([id]);
        S.selEdge = null;
        if (n.type === "frame") S.lastFrame = id;
        render();
        fitTo(boundsOf([rectFor(n)]), { max: 1 });
        toastHtml(`Opened <code class="cv-req">#/s/${SESSION}/files?path=${esc(target)}&amp;node=${esc(id)}</code>, fitted on the node.`);
      };
      if (target === S.path) go();
      else switchBoard(target, go);
    }
    api.openNodeLink = openNodeLink;
    world.addEventListener("click", (e) => {
      const link = e.target.closest(".cv-node-link");
      if (link) {
        e.preventDefault();
        e.stopPropagation();
        return openNodeLink(link.dataset.board, link.dataset.node);
      }
      const ob = e.target.closest(".cv-open-board");
      if (ob) switchBoard(ob.dataset.file);
    });
    function afterRender() {
      if (S.editing) {
        const ta = $(".kp-card-editor", world);
        if (ta && document.activeElement !== ta) {
          ta.focus({ preventScroll: true });
          const pos = S.editing.caret ?? ta.value.length;
          ta.setSelectionRange(pos, pos);
        }
        if (ta) {
          ta.oninput = () => {
            S.editing.draft = ta.value;
            S.editing.caret = ta.selectionStart;
          };
          ta.onblur = () => setTimeout(() => S.editing && document.activeElement !== ta && !S.conflict && commitEdit(), 0);
          ta.onkeydown = (e) => {
            if (e.key === "Escape") {
              e.preventDefault();
              e.stopPropagation();
              cancelEdit();
            }
          };
        }
      }
      const ed = $(".kp-edge-editor", world);
      if (ed) {
        ed.focus({ preventScroll: true });
        ed.setSelectionRange(0, ed.value.length);
        ed.onkeydown = (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            ed.blur();
          } else if (e.key === "Escape") {
            e.preventDefault();
            e.stopPropagation();
            S.editEdge = null;
            render();
          }
        };
        ed.onblur = () => {
          const id = S.editEdge;
          if (!id) return;
          S.editEdge = null;
          const e = S.edges.find((x) => x.id === id);
          const v = ed.value.trim();
          if (e && v !== (e.label || "")) write("Edge label saved: one PATCH …/canvas/edges, one undo step", () => (e.label = v || undefined));
          else render();
        };
      }
      cfg.afterRender?.(api);
      placeNotes();
    }

    // ----- Stage 1: editing a card's Markdown source in place -----
    function startEdit(id, opts = {}) {
      const n = S.nodes.find((x) => x.id === id);
      if (!n || n.type !== "text" || n.mermaid) return;
      if (n.truncated) return toast("This card's text was cut at 20000 bytes in what the board read, so it is not edited in place: its menu offers Open in Files.");
      S.editing = { id, draft: n.text, before: n.text, isNew: !!opts.isNew };
      S.sel = new Set([id]);
      render();
    }
    function commitEdit() {
      const ed = S.editing;
      if (!ed) return;
      const n = S.nodes.find((x) => x.id === ed.id);
      S.editing = null;
      S.conflict = null;
      if (!n) return render();
      if (ed.draft === ed.before) return render();
      write("Card saved on blur: one PATCH …/canvas/nodes with expect, one undo step", () => (n.text = ed.draft));
    }
    function cancelEdit() {
      const ed = S.editing;
      S.editing = null;
      S.conflict = null;
      render();
      if (ed && !ed.isNew) toast("Escape: the edit is cancelled, nothing written.");
    }
    api.startEdit = startEdit;
    api.commitEdit = commitEdit;
    // The file changed under a card being edited: a note keeps the person's text.
    function conflictHTML() {
      const n = S.nodes.find((x) => x.id === S.conflict.id);
      if (!n) return "";
      return `<div class="canvas-popover kp-pop kp-conflict" role="dialog" aria-label="The card changed in the file" style="left: ${n.x}px; top: ${n.y + n.h + 8}px; transform-origin: 0 0; transform: scale(var(--canvas-inv, 1));">
        <p class="canvas-popover-target"><code>${esc(n.id)}</code> changed in the file while you typed</p>
        <p class="kp-pop-text">The file now says: “${esc(S.conflict.file.replace(/\n/g, " "))}”. Your text stays in the card.</p>
        <div class="canvas-popover-actions"><button type="button" class="canvas-popover-cancel" data-kp-conflict="copy">Copy</button><button type="button" class="canvas-popover-add" data-kp-conflict="keep">Keep mine</button></div></div>`;
    }
    api.conflict = (fileText) => {
      if (!S.editing) startEdit(cfg.conflictCard);
      if (!S.editing) return;
      S.editing.draft = $(".kp-card-editor", world)?.value ?? S.editing.draft;
      if (S.editing.draft === S.editing.before) S.editing.draft = S.editing.before.replace("next day in town", "next day in town, and on Saturdays");
      const n = S.nodes.find((x) => x.id === S.editing.id);
      n.text = fileText;
      S.editing.before = fileText;
      S.conflict = { id: n.id, file: fileText };
      render();
    };
    world.addEventListener("click", (e) => {
      const b = e.target.closest("[data-kp-conflict]");
      if (!b) return;
      if (b.dataset.kpConflict === "copy") {
        navigator.clipboard?.writeText(S.editing?.draft || "").catch(() => {});
        toast("Your text is copied; the card stays in editing.");
        return;
      }
      const ed = S.editing;
      const n = S.nodes.find((x) => x.id === ed.id);
      S.editing = null;
      S.conflict = null;
      write("Keep mine: saved against the file's current value, one undo step", () => (n.text = ed.draft));
    });

    // ----- selection, menus, deleting, duplicating -----
    // The selection holds node ids and "e:<edge id>" (#570, Stage 2).
    function select(ids, add = false) {
      if (!add) S.sel = new Set();
      for (const id of ids) S.sel.add(id);
      S.selEdge = null;
      render();
    }
    const selectedNodes = () => [...S.sel].filter((id) => !id.startsWith("e:")).map(nodeById).filter(Boolean);
    api.selectedNodes = selectedNodes;

    // One menu for both issues: Coddy's own (mode-menu, as the picture menu),
    // with a header, an icon and a key hint per row, submenus and the colour
    // swatches; on a phone it is a sheet with a Back row for a submenu.
    function closeMenus() {
      const open = $$(".cv-menu, .cv-menu-backdrop").concat($$(".kp-pop:not(.kp-conflict), .kp-palette", pane));
      open.forEach((m) => m.remove());
      if (open.length && transient.length) setTransient([]);
    }
    api.closeMenus = closeMenus;
    const norm = (it) => (it === "-" ? { sep: true } : it.key && !it.hint ? { ...it, hint: it.key } : it);
    const DIRS = [
      ["left", "←", "Left"],
      ["top", "↑", "Above"],
      ["bottom", "↓", "Below"],
      ["right", "→", "Right"],
    ];
    function menuRow(it) {
      if (it.sep) return '<div class="cv-menu-sep" role="separator"></div>';
      if (it.header) return `<div class="mode-menu-group-label cv-menu-head">${esc(it.header)}</div>`;
      if (it.swatches)
        return `<div class="cv-menu-swatches" role="group" aria-label="Colour">${ICONS.colour}<span>Colour</span>${["", "1", "2", "3", "4", "5", "6"]
          .map((c) => `<button type="button" class="cv-swatch${(it.current || "") === c ? " is-on" : ""}" data-colour="${c}" title="${c ? `Preset ${c}` : "No colour"}" style="${c ? `--sw:${PRESET[c]}` : ""}"></button>`)
          .join("")}<button type="button" class="cv-swatch cv-swatch-hex" data-colour="#ffb86c" title="#rrggbb">#</button></div>`;
      if (it.dirs)
        return `<div class="mode-item image-menu-item cv-menu-item kp-menu-dirs" role="group" aria-label="${esc(it.label)}">${it.icon || ""}<span class="cv-menu-label">${esc(it.label)}</span><span class="kp-dirs">${DIRS.map(
          ([d, g, t]) => `<button type="button" role="menuitem" data-dir="${d}" title="${t}">${g}</button>`,
        ).join("")}</span></div>`;
      return `<button type="button" role="menuitem" class="mode-item image-menu-item cv-menu-item${it.on ? " is-on" : ""}${it.disabled ? " is-disabled" : ""}"${it.title ? ` title="${esc(it.title)}"` : ""}${it.sub ? ' aria-haspopup="menu"' : ""}>${it.icon || ""}<span class="cv-menu-label">${esc(it.label)}</span>${it.hint ? `<span class="cv-menu-hint">${esc(it.hint)}</span>` : ""}${it.sub ? `<span class="cv-menu-sub">${ICONS.chevron}</span>` : ""}</button>`;
    }
    // `x`, `y` in the viewport; opts.note says which rows are whose.
    function openMenu(list, x, y, opts = {}) {
      closeMenus();
      const items = list.map(norm);
      const host = $(".kp-fullscreen") || body;
      const sheet = PHONE;
      if (sheet) host.append(el('<div class="mode-menu-backdrop mode-menu-backdrop--scrim cv-menu-backdrop"></div>'));
      const m = el(`<div class="mode-menu ${sheet ? "mode-menu--sheet" : "mode-menu--portal"} image-menu cv-menu" role="menu">${items.map(menuRow).join("")}</div>`);
      host.append(m);
      if (!sheet) {
        m.style.left = `${Math.max(6, Math.min(x, innerWidth - m.offsetWidth - 6))}px`;
        m.style.top = `${Math.max(6, Math.min(y, innerHeight - m.offsetHeight - 6))}px`;
      }
      const live = items.filter((it) => !it.sep && !it.header && !it.swatches);
      $$(".cv-menu-item", m).forEach((r, i) => {
        const it = live[i];
        if (it.disabled) {
          if (it.title) r.onclick = () => toast(it.title);
          return;
        }
        if (it.dirs) {
          $$("button[data-dir]", r).forEach((b) => (b.onclick = () => (closeMenus(), it.dirs(b.dataset.dir))));
          if (!sheet) r.onmouseenter = () => $$(".cv-submenu").forEach((x2) => x2.remove());
          return;
        }
        if (it.sub) {
          const openSub = () => {
            $$(".cv-submenu").forEach((x2) => x2.remove());
            setTransient([]); // the menu's note would cover the submenu
            if (sheet) return openMenu([{ header: it.label }, ...it.sub, { sep: true }, { label: "Back", icon: ICONS.chevron, run: () => openMenu(list, x, y, opts) }], x, y);
            const sm = el(`<div class="mode-menu mode-menu--portal image-menu cv-menu cv-submenu" role="menu">${it.sub.map(menuRow).join("")}</div>`);
            host.append(sm);
            const rr = r.getBoundingClientRect();
            const left = rr.right + 4 + sm.offsetWidth > innerWidth ? rr.left - sm.offsetWidth - 4 : rr.right + 4;
            sm.style.left = `${Math.max(6, left)}px`;
            sm.style.top = `${Math.max(6, Math.min(rr.top - 6, innerHeight - sm.offsetHeight - 6))}px`;
            const subs = it.sub.filter((q) => !q.sep && !q.header);
            $$(".cv-menu-item", sm).forEach((sr, j) => (sr.onclick = () => (closeMenus(), subs[j].run())));
            opts.onSub?.(sm, it);
          };
          r.onclick = openSub;
          if (!sheet) r.onmouseenter = openSub;
          return;
        }
        r.onclick = () => (closeMenus(), it.run());
        if (!sheet) r.onmouseenter = () => $$(".cv-submenu").forEach((x2) => x2.remove());
      });
      const sw = items.find((it) => it.swatches);
      if (sw) $$(".cv-swatch", m).forEach((b) => (b.onclick = () => (closeMenus(), sw.pick(b.dataset.colour || null))));
      $(".cv-menu-backdrop")?.addEventListener("click", closeMenus);
      if (opts.note) setTransient([{ at: m, text: opts.note, side: sheet ? "above" : m.getBoundingClientRect().right + 280 < innerWidth ? "right" : "left", free: true }]);
      opts.onOpen?.(m);
      return m;
    }
    api.openMenu = openMenu;
    // `at` in the board's own coordinates (from its top left corner).
    function menu(at, items, note) {
      const r = board.getBoundingClientRect();
      return openMenu(items, r.left + at.x, r.top + at.y, { note });
    }
    api.menu = menu;
    // #570, Stage 2: the first row of a node's menu selects; the rest of the
    // menu acts on the node, or on the selection when the node is in it.
    const selectRow = (n) =>
      S.sel.size && !S.sel.has(n.id) ? { label: "Add to selection", icon: ICONS.pointer, hint: "Shift-click", run: () => select([n.id], true) } : { label: "Select", icon: ICONS.pointer, run: () => select([n.id]) };
    const targetOf = (n) => (S.sel.has(n.id) ? selectedNodes().map((x) => x.id) : [n.id]);
    api.selectRow = selectRow;
    api.targetOf = targetOf;
    document.addEventListener("pointerdown", (e) => {
      if (!e.target.closest?.(".cv-menu, .cv-menu-backdrop, .kp-palette, .kp-pop, .markup-swatch")) closeMenus();
    });
    const snap = (v, e) => (e && e[NOSNAP] ? Math.round(v) : Math.round(v / GRID) * GRID);
    function addCard(at, text = "", extra = {}) {
      const n = { id: newId("c"), type: "text", text, x: snap(at.x - CARD.w / 2), y: snap(at.y - CARD.h / 2), w: CARD.w, h: CARD.h, ...extra };
      write("New card: one POST …/canvas/nodes, the server picks its id", () => S.nodes.push(n), { quiet: true });
      startEdit(n.id, { isNew: true });
      return n;
    }
    api.addCard = addCard;
    function connected(id, dir) {
      const src = S.nodes.find((x) => x.id === id);
      if (!src) return toast("The source node is gone: nothing is written.");
      const gap = 80;
      const p = {
        right: { x: src.x + src.w + gap, y: src.y },
        left: { x: src.x - gap - CARD.w, y: src.y },
        bottom: { x: src.x, y: src.y + src.h + gap },
        top: { x: src.x, y: src.y - gap - CARD.h },
      }[dir];
      const n = { id: newId("c"), type: "text", text: "", x: snap(p.x), y: snap(p.y), w: CARD.w, h: CARD.h };
      const opp = { right: "left", left: "right", top: "bottom", bottom: "top" }[dir];
      write(`Connected card ${dir === "top" ? "above" : dir === "bottom" ? "below" : "on the " + dir}: the node and its edge in one write, one undo step`, () => {
        S.nodes.push(n);
        S.edges.push({ id: newId("e"), from: src.id, fromSide: dir, to: n.id, toSide: opp });
      });
      startEdit(n.id, { isNew: true });
    }
    function cloneIds(ids, dx, dy, how) {
      const out = new Map();
      const want = new Set(ids);
      for (const id of ids) {
        const n = S.nodes.find((x) => x.id === id);
        if (n?.type === "group") S.nodes.filter((m) => m.id !== n.id && inside(n, m)).forEach((m) => want.add(m.id));
      }
      const skipped = [];
      for (const id of want) {
        const n = S.nodes.find((x) => x.id === id);
        if (!n) continue;
        if (n.type === "frame") {
          skipped.push(n.file);
          continue;
        }
        const c = { ...clone(n), id: newId(n.type === "group" ? "g" : "c"), x: n.x + dx, y: n.y + dy };
        if (c.shapes) c.shapes.forEach((s) => moveShape(s, dx, dy));
        out.set(id, c);
      }
      const edges = S.edges.filter((e) => out.has(e.from) && out.has(e.to)).map((e) => ({ ...clone(e), id: newId("e"), from: out.get(e.from).id, to: out.get(e.to).id }));
      if (!out.size) {
        toast(`${how}: nothing to clone. ${skipped.join(", ")} is a frame, left out and named: the same page at the same size is one frame.`);
        return [];
      }
      write(`${how}: cloned on the server, one POST …/canvas/nodes with clone${skipped.length ? `; ${skipped.join(", ")} left out, a frame is shown once` : ""}`, () => {
        S.nodes.push(...out.values());
        S.edges.push(...edges);
      });
      return [...out.values()].map((c) => c.id);
    }
    function deleteSel() {
      if (!S.sel.size && !S.selEdge) return;
      const ids = new Set(S.sel);
      const frames = S.nodes.filter((n) => ids.has(n.id) && n.type === "frame");
      const frameIds = new Set(frames.map((f) => f.id));
      write(
        `Deleted: one POST …/canvas/delete${frames.length ? `, then ${frames.length} frame${frames.length > 1 ? "s" : ""} through ${frames.length > 1 ? "their" : "its"} own route, outside undo` : ""}; Ctrl/Cmd+Z brings ${frames.length ? "the rest" : "them"} back`,
        () => {
          S.nodes = S.nodes.filter((n) => !ids.has(n.id));
          S.edges = S.edges.filter((e) => !ids.has(e.from) && !ids.has(e.to) && e.id !== S.selEdge);
          S.sel.clear();
          S.selEdge = null;
        },
      );
      // A frame stays outside undo, and so does an edge between it and a
      // removed node: the undo step restores the rest without them.
      if (frameIds.size) {
        const u = S.undo[S.undo.length - 1];
        u.nodes = u.nodes.filter((n) => !frameIds.has(n.id));
        u.edges = u.edges.filter((e) => !frameIds.has(e.from) && !frameIds.has(e.to));
      }
    }
    api.deleteSel = deleteSel;
    function addFile(at) {
      menu(at, [
        { file: true, label: "notes/brief.md", hint: "a note: shown as its text", run: () => placeFile(at, "notes/brief.md") },
        { file: true, label: "design/logo.png", hint: "a picture: shown as the picture", run: () => placeFile(at, "design/logo.png") },
        { file: true, label: "site/index.html", hint: "a page: canvas_show or the Files window puts it on", disabled: true, run: () => {} },
      ]);
    }
    function placeFile(at, file) {
      const p = toBoard(at.x + board.getBoundingClientRect().left, at.y + board.getBoundingClientRect().top);
      const pic = /\.png$/.test(file);
      const n = { id: newId("f"), type: "file", file, x: snap(p.x - 200), y: snap(p.y - 130), w: FILE.w, h: pic ? 260 : FILE.h };
      if (pic) n.picture = DATA.logo;
      else n.note = DATA.notes[file] || "";
      write(`Add file: ${file}, one POST …/canvas/nodes, one undo step`, () => S.nodes.push(n));
    }
    function addLink(at) {
      closeMenus();
      const pop = el(`<div class="canvas-popover kp-pop" role="dialog" aria-label="Add link" style="left: ${at.x}px; top: ${at.y}px;"><p class="canvas-popover-target">Add link</p>
        <input class="canvas-popover-note kp-pop-input" aria-label="Address" placeholder="https://" value="https://jsoncanvas.org"><p class="kp-pop-error" hidden></p>
        <div class="canvas-popover-actions"><button type="button" class="canvas-popover-cancel">Cancel</button><button type="button" class="canvas-popover-add">Add</button></div></div>`);
      board.append(pop);
      // Opened near the board's edge, it stays inside the board.
      pop.style.left = `${Math.max(8, Math.min(at.x, board.clientWidth - pop.offsetWidth - 8))}px`;
      pop.style.top = `${Math.max(8, Math.min(at.y, board.clientHeight - pop.offsetHeight - 8))}px`;
      const input = $("input", pop);
      focusSoft(input);
      const go = () => {
        const v = input.value.trim();
        if (!/^https?:\/\/[^\s/]+/i.test(v)) {
          const err = $(".kp-pop-error", pop);
          err.hidden = false;
          err.textContent = "Only an http or https address: anything else is 400 and writes nothing.";
          return;
        }
        pop.remove();
        const p = toBoard(at.x + board.getBoundingClientRect().left, at.y + board.getBoundingClientRect().top);
        write("Add link: one POST …/canvas/nodes, one undo step", () => S.nodes.push({ id: newId("l"), type: "link", url: v, x: snap(p.x), y: snap(p.y), w: FILE.w, h: 120 }));
      };
      $(".canvas-popover-add", pop).onclick = go;
      $(".canvas-popover-cancel", pop).onclick = () => pop.remove();
      input.onkeydown = (e) => {
        if (e.key === "Enter") go();
        if (e.key === "Escape") pop.remove();
      };
    }
    // ----- #570, Stages 2 to 4: the menus' actions -----
    function copyLink(id) {
      toastHtml(`Copied: <code class="cv-req">#/s/${SESSION}/files?path=${esc(S.path)}&amp;node=${esc(id)}</code> The address opens this board fitted on the node.`);
    }
    function selectEdges(id, which) {
      const list = S.edges.filter((e) => (which !== "in" && e.from === id) || (which !== "out" && e.to === id));
      S.sel = new Set(list.map((e) => `e:${e.id}`));
      S.selEdge = null;
      render();
      toast(`${list.length} ${which === "in" ? "incoming" : which === "out" ? "outgoing" : "connected"} edge${list.length === 1 ? "" : "s"} selected.`);
    }
    api.selectEdges = selectEdges;
    function setFocus(on) {
      S.focus = on;
      render();
    }
    api.setFocus = setFocus;
    const newGroupId = () => `g${Math.random().toString(16).slice(2, 10)}`;
    function groupSelection() {
      const ns = selectedNodes();
      if (!ns.length) return toast("Select the nodes to group first.");
      const r = boundsOf(ns.map(rectFor));
      const id = newGroupId();
      writeReq({
        what: "Group the selection",
        route: "POST …/canvas/nodes",
        body: { type: "group", around: ns.map((n) => n.id) },
        apply: () => {
          S.nodes.splice(Math.min(...ns.map((n) => S.nodes.indexOf(n))), 0, { id, type: "group", x: r.x - 40, y: r.y - 40, w: r.width + 80, h: r.height + 80, label: "Group" });
          S.sel = new Set([id]);
        },
      });
    }
    function newGroup(p) {
      const g = { id: newGroupId(), type: "group", x: snap(p.x), y: snap(p.y), w: 400, h: 300, label: "New group" };
      writeReq({ what: "New group", route: "POST …/canvas/nodes", body: { type: "group", x: g.x, y: g.y }, apply: () => S.nodes.unshift(g) });
    }
    function setCollapsed(g, v) {
      writeReq({
        what: v ? `Collapse "${g.label}"` : `Expand "${g.label}"`,
        route: "PATCH …/canvas/nodes",
        body: { nodes: [{ id: g.id, collapsed: v || null, expect: { collapsed: g.collapsed ? true : null } }] },
        apply: () => {
          const n = nodeById(g.id);
          if (v) n.collapsed = true;
          else delete n.collapsed;
          S.shown.delete(g.id);
        },
      });
    }
    api.setCollapsed = (id, v) => setCollapsed(nodeById(id), v);
    async function removeGroup(g) {
      if (!guard("Remove group")) return;
      const ok = await confirmDialog({ title: `Remove the group "${g.label}"?`, message: "The members and their edges stay; an edge that ends at the group itself goes with it. This is not undone with Ctrl+Z.", confirm: "Remove", variant: "danger" });
      if (!ok) return;
      writeReq({
        what: `Remove "${g.label}"`,
        route: `DELETE …/canvas/nodes/${g.id}`,
        body: { stamp: "c41f…" },
        undoable: false,
        apply: () => {
          S.nodes = S.nodes.filter((n) => n.id !== g.id);
          S.edges = S.edges.filter((e) => e.from !== g.id && e.to !== g.id);
          S.sel.delete(g.id);
        },
      });
    }
    function swap() {
      const ns = selectedNodes();
      if (ns.length !== 2) return toast("Swap takes two selected nodes.");
      const [a, b] = ns;
      writeReq({
        what: "Swap",
        route: "PATCH …/canvas/nodes",
        body: { nodes: [{ id: a.id, x: b.x, y: b.y, width: b.w, height: b.h, expect: { x: a.x, y: a.y, width: a.w, height: a.h } }, { id: b.id, x: a.x, y: a.y, width: a.w, height: a.h, expect: { x: b.x, y: b.y, width: b.w, height: b.h } }] },
        apply: () => {
          for (const k of ["x", "y", "w", "h"]) [a[k], b[k]] = [b[k], a[k]];
        },
      });
    }
    function flip(axis) {
      let ns = selectedNodes();
      for (const g of ns.filter((n) => n.type === "group")) ns = ns.concat(membersOf(g));
      ns = [...new Set(ns)];
      if (ns.length < 2) return toast("Flip mirrors two or more selected nodes.");
      const r = boundsOf(ns.map(rectOf));
      const ids = new Set(ns.map((n) => n.id));
      const turn = axis === "horizontal" ? { left: "right", right: "left" } : { top: "bottom", bottom: "top" };
      writeReq({
        what: `Flip ${axis}ly`,
        route: "POST …/canvas/flip",
        body: { ids: [...ids], axis, stamp: "c41f…" },
        apply: () => {
          for (const n of ns) {
            if (axis === "horizontal") n.x = r.x + r.width - (n.x - r.x) - n.w;
            else n.y = r.y + r.height - (n.y - r.y) - n.h;
          }
          for (const e of S.edges) {
            if (ids.has(e.from) && turn[e.fromSide]) e.fromSide = turn[e.fromSide];
            if (ids.has(e.to) && turn[e.toSide]) e.toSide = turn[e.toSide];
          }
        },
      });
    }
    async function encapsulate() {
      const ns = selectedNodes();
      if (!ns.length) return toast("Select what to move into a new board first.");
      if (!guard("Encapsulate")) return;
      const name = S.path.replace(/\.canvas$/, "-1.canvas");
      const ok = await confirmDialog({ title: `Move ${ns.length} node${ns.length === 1 ? "" : "s"} into ${baseOf(name)}?`, message: "They move into a new board next to this one, keeping their places; a file node takes their place and crossing edges end at it. This is not undone with Ctrl+Z.", confirm: "Encapsulate" });
      if (!ok) return;
      const ids = new Set(ns.map((n) => n.id));
      const r = boundsOf(ns.map(rectFor));
      writeReq({
        what: "Encapsulate",
        route: "POST …/canvas/encapsulate",
        body: { ids: [...ids], stamp: "c41f…" },
        undoable: false,
        apply: () => {
          docs[name] = { nodes: clone(ns), edges: clone(S.edges.filter((e) => ids.has(e.from) && ids.has(e.to))), metadata: { version: "1.0-1.0", frontmatter: {} } };
          const fid = `f${Math.random().toString(16).slice(2, 10)}`;
          S.nodes = S.nodes.filter((n) => !ids.has(n.id));
          S.nodes.push({ id: fid, type: "file", file: name, board: true, x: r.x, y: r.y, w: 300, h: 130 });
          S.edges = S.edges.filter((e) => !(ids.has(e.from) && ids.has(e.to))).map((e) => ({ ...e, from: ids.has(e.from) ? fid : e.from, to: ids.has(e.to) ? fid : e.to }));
          S.sel = new Set([fid]);
        },
      });
    }
    const isEdge = (x) => "from" in x && "to" in x && !("x" in x);
    function setStyle(x, key, value) {
      const before = x.styleAttributes?.[key] ?? null;
      writeReq({
        what: `${key === "textAlign" ? "Align text" : cap(key)}: ${value}`,
        route: isEdge(x) ? "PATCH …/canvas/edges" : "PATCH …/canvas/nodes",
        body: { [isEdge(x) ? "edges" : "nodes"]: [{ id: x.id, styleAttributes: { [key]: value }, expect: { [`styleAttributes.${key}`]: before } }] },
        apply: () => {
          const t = isEdge(x) ? S.edges.find((e) => e.id === x.id) : nodeById(x.id);
          t.styleAttributes = { ...(t.styleAttributes || {}), [key]: value };
        },
      });
    }
    api.setStyle = (id, key, value) => setStyle(nodeById(id) || S.edges.find((e) => e.id === id), key, value);
    function setColour(x, c) {
      const before = x.color ?? null;
      writeReq({
        what: `Colour: ${c ?? "none"}`,
        route: isEdge(x) ? "PATCH …/canvas/edges" : "PATCH …/canvas/nodes",
        body: { [isEdge(x) ? "edges" : "nodes"]: [{ id: x.id, color: c, expect: { color: before } }] },
        apply: () => {
          const t = isEdge(x) ? S.edges.find((e) => e.id === x.id) : nodeById(x.id);
          if (c) t.color = c;
          else delete t.color;
        },
      });
    }
    function setStart(n) {
      const before = S.meta?.startNode ?? null;
      writeReq({
        what: `Set as start slide: ${titleOf(n)}`,
        route: "PATCH …/canvas/metadata",
        body: { startNode: n.id, expect: { startNode: before } },
        apply: () => (S.meta = { ...(S.meta || { version: "1.0-1.0", frontmatter: {} }), startNode: n.id }),
      });
    }
    function flipEdge(e) {
      writeReq({
        what: "Flip edge",
        route: "PATCH …/canvas/edges",
        body: { ids: [e.id], flip: true, stamp: "c41f…" },
        apply: () => {
          const t = S.edges.find((x) => x.id === e.id);
          [t.from, t.to] = [t.to, t.from];
          [t.fromSide, t.toSide] = [t.toSide, t.fromSide];
        },
      });
    }
    function toggleReadOnly() {
      S.readOnly = !S.readOnly;
      $(".cv-readonly", board)?.remove();
      if (S.readOnly) $(".canvas-mode", board).after(el(`<span class="cv-readonly" role="status">${ICONS.lock}Read-only view</span>`));
      toastHtml(S.readOnly ? "<strong>Read-only view</strong> for you: the board writes nothing. Pan, zoom, search, focus, the presentation and links keep working." : "The board writes again.");
    }
    api.toggleReadOnly = toggleReadOnly;
    api.armConflict = () => {
      S.conflictArmed = true;
      toast("The file changed elsewhere: the next write gets 409 and takes the current values.");
    };
    api.setToday = (on) => {
      S.today = on;
      render();
      fit();
    };
    api.peek = (id) => {
      S.shown.has(id) ? S.shown.delete(id) : S.shown.add(id);
      render();
    };

    // ----- #606, Stage 4: links onto the board -----
    function pull(n, dir) {
      const found = (NOTE_LINKS[n.file] || {})[dir] || [];
      const skipped = dir === "out" ? (NOTE_LINKS[n.file] || {}).skipped || [] : [];
      const added = [];
      const newEdges = [];
      let row = 0;
      for (const f of found) {
        let target = S.nodes.find((m) => m.file === f);
        if (!target) {
          target = { id: newId("f"), type: "file", file: f, note: DATA.notes[f] || NOTES[f] || "", x: dir === "out" ? n.x + n.w + 240 : n.x - 640, y: n.y + row * 340, w: 400, h: 300 };
          row++;
          added.push(target);
        }
        const [from, to] = dir === "out" ? [n.id, target.id] : [target.id, n.id];
        if (!S.edges.some((e) => e.from === from && e.to === to) && !newEdges.some((e) => e.from === from && e.to === to)) newEdges.push({ id: newId("e"), from, fromSide: dir === "out" ? "right" : "left", to, toSide: dir === "out" ? "left" : "right" });
      }
      if (!added.length && !newEdges.length) return api.notice(`<b>Nothing new:</b> every ${dir === "out" ? "outgoing link" : "backlink"} of <code>${esc(n.file)}</code> is on the board with its edge.`);
      const onBoard = newEdges.length - added.length;
      const ok = write(`${dir === "out" ? "Pull outgoing links" : "Pull backlinks"}: one POST …/canvas/links, one write, one undo step`, () => {
        S.nodes.push(...added);
        S.edges.push(...newEdges);
      }, { quiet: true });
      if (!ok) return;
      fit();
      api.notice(
        `<b>Pulled the ${dir === "out" ? "outgoing links" : "backlinks"} of <code>${esc(n.file)}</code>:</b> ${added.length} note${added.length === 1 ? "" : "s"} added${onBoard > 0 ? `, ${onBoard} edge${onBoard === 1 ? "" : "s"} to a note already here` : ""}.${skipped.length ? ` Skipped: ${skipped.join("; ")}.` : ""}`,
        true,
      );
      cfg.onPull?.(n, dir, api);
    }
    api.pull = (id, dir) => pull(nodeById(id), dir);

    // ----- the three menus: one for each kind of thing, the same on every slide -----
    const MENU_NOTE = "One menu for both issues: Select, the links, Focus, the organising and the styles are #570's; Edit, Add connected card, Ask Coddy, the link pulls, Duplicate and Delete are #606's.";
    function boardMenu(at) {
      const p = toBoard(at.x + board.getBoundingClientRect().left, at.y + board.getBoundingClientRect().top);
      menu(
        at,
        [
          { header: baseOf(S.path) },
          { label: "New card", icon: ICONS.plus, key: "double click", run: () => addCard(p) },
          { label: "Add file…", icon: ICONS.open, run: () => addFile(at) },
          { label: "Add link…", icon: ICONS.link, run: () => addLink(at) },
          { label: "New group", icon: ICONS.group, run: () => newGroup(p) },
          "-",
          { label: "Search", icon: ICONS.search, key: `${MOD} F`, run: openSearch },
          { label: "Fit", icon: ICONS.zoom, key: "Shift 1", run: () => fit() },
          "-",
          { label: "Present", icon: ICONS.play, run: startPresentation },
          { label: "Read-only view", icon: ICONS.lock, on: S.readOnly, run: toggleReadOnly },
          { label: "Export…", icon: ICONS.download, run: exportDialog },
        ],
        "The board's menu: New card, Add file and Add link are #606's; New group, Search, Present, Read-only view and Export are #570's.",
      );
    }
    api.boardMenu = boardMenu;
    function duplicate(n) {
      const ids = targetOf(n);
      // A group's copy goes beside it, a node's a step down and right.
      const g = ids.length === 1 && n.type === "group";
      const made = cloneIds(ids, g ? n.w + 40 : 40, g ? 0 : 40, "Duplicate");
      if (made.length) select(made);
    }
    const ensureSel = (n) => S.sel.has(n.id) || select([n.id]);
    function nodeMenu(at, n) {
      const k = kindOf(n);
      const many = selectedNodes().length > 1 && S.sel.has(n.id);
      const items = [{ header: `${titleOf(n)} · ${kindName(n)}` }, selectRow(n)];
      // #606: making and changing the node.
      if (n.type === "sketch") items.push({ label: "Ask Coddy", icon: ICONS.chat, run: () => api.ask(n.id) }, { label: "Edit sketch", icon: ICONS.pen, key: "double click", run: () => startDraw({ editing: n.id }) });
      if (n.type === "text" && !n.mermaid)
        items.push(n.truncated ? { label: "Open in Files", icon: ICONS.open, run: () => toast("Open in Files: the board file opens in a tab of the Files window, since its text is longer than the board read.") } : { label: "Edit", icon: ICONS.pen, key: "double click", run: () => startEdit(n.id) });
      if (k === "note") items.push({ label: "Pull outgoing links", icon: ICONS.edges, run: () => pull(n, "out") }, { label: "Pull backlinks", icon: ICONS.edges, run: () => pull(n, "in") });
      if (!["frame", "group", "sketch"].includes(n.type)) items.push({ label: "Add connected card", icon: ICONS.plus, dirs: (d) => connected(n.id, d) });
      if (k === "picture") items.push({ label: "Copy image", icon: ICONS.image, run: () => toast("Copied the picture, as the picture menu copies it today.") }, { label: "Save image", icon: ICONS.download, run: () => toast(`Saved ${baseOf(n.file)}, as the picture menu saves it today.`) });
      if (k === "board") items.push({ label: "Open board", icon: ICONS.open, run: () => switchBoard(n.file) });
      // #570: the address, the view.
      items.push("-", { label: "Copy link", icon: ICONS.link, run: () => copyLink(n.id) });
      if (k !== "frame") {
        items.push(
          { label: "Zoom to selection", icon: ICONS.zoom, key: "Shift 2", run: () => (ensureSel(n), zoomToSelection()) },
          { label: "Focus", icon: ICONS.focus, on: S.focus, run: () => (ensureSel(n), setFocus(!S.focus)) },
          { label: "Select connected edges", icon: ICONS.edges, sub: [{ label: "All", run: () => selectEdges(n.id, "all") }, { label: "Incoming", run: () => selectEdges(n.id, "in") }, { label: "Outgoing", run: () => selectEdges(n.id, "out") }] },
        );
        // #570, Stage 3: organising.
        items.push("-", { label: "Group the selection", icon: ICONS.group, run: () => (ensureSel(n), groupSelection()) });
        if (many) items.push({ label: "Swap", icon: ICONS.swap, disabled: selectedNodes().length !== 2, title: "Swap takes two selected nodes", run: swap }, { label: "Flip", icon: ICONS.flip, sub: [{ label: "Horizontally", run: () => flip("horizontal") }, { label: "Vertically", run: () => flip("vertical") }] });
        items.push({ label: "Encapsulate…", icon: ICONS.box, run: () => (ensureSel(n), encapsulate()) });
      }
      if (n.type === "group") items.push("-", n.collapsed ? { label: "Expand", icon: ICONS.expand, run: () => setCollapsed(n, false) } : { label: "Collapse", icon: ICONS.collapse, run: () => setCollapsed(n, true) }, { label: "Remove group…", icon: ICONS.trash, run: () => removeGroup(n) });
      // #570, Stage 4: styles.
      items.push("-");
      if (!["frame", "group", "sketch"].includes(n.type)) {
        items.push(
          { label: "Shape", icon: ICONS.shape, sub: SHAPES.map((v) => ({ label: cap(v), on: (n.styleAttributes?.shape || "rectangle") === v, run: () => setStyle(n, "shape", v) })) },
          { label: "Border", icon: ICONS.border, sub: BORDERS.map((v) => ({ label: cap(v), on: (n.styleAttributes?.border || "solid") === v, run: () => setStyle(n, "border", v) })) },
        );
        if (n.type === "text") items.push({ label: "Align text", icon: ICONS.align, sub: ["left", "center", "right"].map((v) => ({ label: cap(v), on: (n.styleAttributes?.textAlign || "left") === v, run: () => setStyle(n, "textAlign", v) })) });
      }
      if (n.type !== "sketch") items.push({ swatches: true, current: n.color, pick: (c) => setColour(n, c) });
      items.push({ label: "Set as start slide", icon: ICONS.play, on: S.meta?.startNode === n.id, run: () => setStart(n) });
      // #606: copying and removing.
      items.push(
        "-",
        n.type === "frame" ? { label: "Duplicate", icon: ICONS.copy, disabled: true, title: "A frame is shown once: the same page at the same size is one frame, so Duplicate leaves it out." } : { label: "Duplicate", icon: ICONS.copy, key: `${CLONE_KEY}+drag`, run: () => duplicate(n) },
        { label: "Delete", icon: ICONS.trash, key: "Del", run: () => (select(targetOf(n)), deleteSel()) },
      );
      return menu(at, items, MENU_NOTE);
    }
    function edgeMenu(at, e) {
      menu(
        at,
        [
          { header: `Edge${e.label ? ` "${e.label}"` : ""} · ${titleOf(nodeById(e.from))} → ${titleOf(nodeById(e.to))}` },
          { label: "Select", icon: ICONS.pointer, run: () => select([`e:${e.id}`]) },
          { label: "Edit label", icon: ICONS.pen, key: "double click", run: () => ((S.editEdge = e.id), render()) },
          { label: "Zoom to selection", icon: ICONS.zoom, key: "Shift 2", run: () => (select([`e:${e.id}`]), zoomToSelection()) },
          "-",
          { label: "Path", icon: ICONS.path, sub: PATHS.map((v) => ({ label: cap(v), on: (e.styleAttributes?.path || "solid") === v, run: () => setStyle(e, "path", v) })) },
          { label: "Arrow", icon: ICONS.arrow, sub: ARROWS.map((v) => ({ label: cap(v), on: (e.styleAttributes?.arrow || "triangle") === v, run: () => setStyle(e, "arrow", v) })) },
          { swatches: true, current: e.color, pick: (c) => setColour(e, c) },
          { label: "Flip edge", icon: ICONS.turn, run: () => flipEdge(e) },
          "-",
          { label: "Delete", icon: ICONS.trash, key: "Del", run: () => ((S.selEdge = e.id), deleteSel()) },
        ],
        "An edge's menu: Edit label and Delete are #606's; Path, Arrow, Colour and Flip edge are #570's.",
      );
    }
    // Open a menu beside a node or an edge label, as a right click there does.
    const atOf = (elm) => {
      const r = elm.getBoundingClientRect(), b = board.getBoundingClientRect();
      return { x: r.left - b.left + Math.min(r.width * 0.6, r.width - 10), y: r.top - b.top + Math.min(r.height * 0.5, 30) };
    };
    api.nodeMenu = (id) => {
      const n = nodeById(id);
      const elm = $(`[data-node-id="${id}"]`, world) || $(`[data-frame-id="${id}"]`, world);
      return n && elm && nodeMenu(atOf(elm), n);
    };
    api.edgeMenu = (id) => {
      const e = S.edges.find((x) => x.id === id);
      const elm = $(`.canvas-edge-label[data-edge-id="${id}"]`, world);
      return e && elm && edgeMenu(atOf(elm), e);
    };
    // ----- pointer: Interact and Comment -----
    const boardAt = (e) => {
      const r = board.getBoundingClientRect();
      return { x: e.clientX - r.left, y: e.clientY - r.top };
    };
    // Controls over the board that take their own clicks.
    const CONTROLS = ".zoom-controls, .canvas-mode, .cv-menu, .kp-pop, .kp-card-editor, .kp-edge-editor, .kp-palette, .canvas-frame-actions, .cv-search, .cv-present, .cv-readonly, .cv-search-btn, .kp-fs-controls, .cv-node-link, .cv-open-board";
    // A menu for what lies under the pointer: an edge, a node or the board.
    function menuFor(e) {
      const at = boardAt(e);
      const edgeEl = e.target.closest("[data-edge-id]");
      if (edgeEl) {
        const ed = S.edges.find((x) => x.id === edgeEl.dataset.edgeId);
        if (ed) {
          S.selEdge = ed.id;
          S.sel.clear();
          render();
          return edgeMenu(at, ed);
        }
      }
      // A right click opens the menu and leaves the selection as it is: the
      // menu's first row selects (#570, Stage 2).
      const nodeEl = e.target.closest("[data-node-id], .canvas-frame-bar");
      if (nodeEl && !nodeEl.classList.contains("kp-handle") && !nodeEl.classList.contains("kp-resize")) {
        const n = nodeById(nodeEl.dataset.nodeId || nodeEl.dataset.frameId);
        if (n) return nodeMenu(at, n);
      }
      boardMenu(at);
    }
    board.addEventListener("contextmenu", (e) => {
      if (S.mode === "draw" || S.pres || e.target.closest(`.kp-inline-page, ${CONTROLS}`)) return;
      e.preventDefault();
      menuFor(e);
    });
    // On touch a long press opens the same menu, as a sheet (#570, Stage 2).
    let press = null;
    const endPress = () => {
      clearTimeout(press?.t);
      press = null;
    };
    board.addEventListener("pointerdown", (e) => {
      if (!PHONE || S.mode === "draw" || S.pres || e.target.closest(`.kp-inline-page, ${CONTROLS}`)) return;
      endPress();
      press = { x: e.clientX, y: e.clientY, t: setTimeout(() => (endPress(), menuFor(e)), 500) };
    });
    board.addEventListener("pointermove", (e) => press && Math.hypot(e.clientX - press.x, e.clientY - press.y) > 6 && endPress());
    board.addEventListener("pointerup", endPress);
    board.addEventListener("pointercancel", endPress);
    board.addEventListener("dblclick", (e) => {
      // The first press of a double click selects and redraws the board, so
      // the event's own target may be gone: take what is under the pointer.
      const t = document.elementFromPoint(e.clientX, e.clientY) || e.target;
      if (S.mode !== "interact" || S.pres || S.readOnly || t.closest(`.kp-inline-page, .cv-folded, ${CONTROLS}`)) return;
      const edgeEl = t.closest("[data-edge-id]");
      if (edgeEl && cfg.edit) {
        S.editEdge = edgeEl.dataset.edgeId;
        return render();
      }
      const nodeEl = t.closest("[data-node-id]");
      if (nodeEl) {
        const n = nodeById(nodeEl.dataset.nodeId);
        if (n?.type === "sketch" && cfg.draw) return startDraw({ editing: n.id });
        if (n && cfg.edit) startEdit(n.id);
        return;
      }
      if (cfg.edit) addCard(toBoard(e.clientX, e.clientY));
    });
    board.addEventListener("pointermove", (e) => {
      if (S.mode !== "interact" || S.drag || !cfg.edit || S.pres || S.readOnly) return;
      const nodeEl = e.target.closest("[data-node-id]");
      const id = nodeEl && !nodeEl.closest(".kp-sketch") && !nodeEl.classList.contains("cv-folded") ? nodeEl.dataset.nodeId : null;
      if (id !== S.hover && !e.target.classList.contains("kp-handle")) {
        S.hover = id;
        if (!S.editing) render();
      }
    });
    board.addEventListener("pointerdown", (e) => {
      if (e.button === 2 || S.mode === "draw" || S.pres) return;
      if (e.target.closest(CONTROLS)) return;
      const page = e.target.closest(".kp-inline-page");
      if (page && S.mode === "comment") return commentPick(e, page);
      if (page) return; // Interact: the page takes it
      if (S.editing) {
        $(".kp-card-editor", world)?.blur();
      }
      const handle = e.target.closest(".kp-handle");
      if (handle) return startEdgeDrag(e, handle);
      const edgeEl = e.target.closest("[data-edge-id]");
      if (edgeEl) {
        if (e.shiftKey) {
          const k = `e:${edgeEl.dataset.edgeId}`;
          S.sel.has(k) ? S.sel.delete(k) : S.sel.add(k);
          return render();
        }
        // A second press on the selected edge redraws nothing, so a double
        // click lands on the same label and edits it.
        if (S.selEdge === edgeEl.dataset.edgeId && !S.sel.size) return;
        S.selEdge = edgeEl.dataset.edgeId;
        S.sel.clear();
        render();
        return;
      }
      const nodeEl = e.target.closest("[data-node-id], .canvas-frame-bar");
      if (nodeEl && S.mode === "interact") {
        const id = nodeEl.dataset.nodeId || nodeEl.dataset.frameId;
        const n = nodeById(id);
        if (!n) return;
        // #570, Stage 3: a click on a collapsed group's bar shows its members
        // to this viewer, and on the label of a group looked into hides them;
        // nothing is written.
        const onClick = () => {
          if (isFolded(n)) {
            S.shown.add(n.id);
            render();
            toast(`Showing the members of "${n.label}" to you; nothing is written. A click on its label hides them.`);
          } else if (n.collapsed && S.shown.has(n.id) && e.target.closest(".canvas-group-label")) {
            S.shown.delete(n.id);
            render();
          }
        };
        if (e.shiftKey) {
          S.sel.has(id) ? S.sel.delete(id) : S.sel.add(id);
          return render();
        }
        if (!S.sel.has(id)) select([id]);
        if (S.readOnly) return startPan(e, onClick);
        startNodeDrag(e, n, onClick);
        return;
      }
      if (!e.shiftKey && (S.sel.size || S.selEdge)) {
        S.sel.clear();
        S.selEdge = null;
        S.focus = false;
        render();
      }
      startPan(e);
    });
    // #570, Stage 4: while presenting, a click goes forward (Coddy's addition),
    // but not on a link, a field or a frame's page.
    board.addEventListener("click", (e) => {
      if (!S.pres || e.target.closest(".cv-present, a, button, input, textarea, .kp-inline-page")) return;
      next();
    });
    function startPan(e, onClick) {
      const start = { x: e.clientX, y: e.clientY, cam: { ...S.cam } };
      let moved = false;
      board.setPointerCapture?.(e.pointerId);
      const move = (ev) => {
        if (!moved && Math.hypot(ev.clientX - start.x, ev.clientY - start.y) < 3) return;
        moved = true;
        S.cam = { ...start.cam, x: start.cam.x + ev.clientX - start.x, y: start.cam.y + ev.clientY - start.y };
        S.fitted = false;
        applyCam();
      };
      const up = () => {
        board.removeEventListener("pointermove", move);
        board.removeEventListener("pointerup", up);
        if (!moved) onClick?.();
      };
      board.addEventListener("pointermove", move);
      board.addEventListener("pointerup", up);
    }
    function startNodeDrag(e, n, onClick) {
      const start = toBoard(e.clientX, e.clientY);
      let ids = selectedNodes().map((x) => x.id);
      // A group carries what lies inside it.
      for (const id of [...ids]) {
        const g = S.nodes.find((x) => x.id === id);
        if (g?.type === "group") S.nodes.filter((m) => m.id !== g.id && inside(g, m)).forEach((m) => ids.push(m.id));
      }
      ids = [...new Set(ids)];
      let orig = null;
      let moved = false;
      let cloned = false;
      board.setPointerCapture?.(e.pointerId);
      const move = (ev) => {
        const p = toBoard(ev.clientX, ev.clientY);
        const dx = p.x - start.x, dy = p.y - start.y;
        if (!moved && Math.hypot(dx, dy) * S.cam.scale < 3) return;
        if (!moved) {
          moved = true;
          if (ev[CLONE] && cfg.edit) {
            ids = cloneIds(ids, 0, 0, `${CLONE_KEY}+drag`);
            cloned = true;
            S.sel = new Set(ids);
          } else S.undo.push({ ...snapshot(), text: "Move" });
          S.drag = true;
          orig = new Map(ids.map((id) => [id, { ...S.nodes.find((x) => x.id === id) }]));
        }
        for (const id of ids) {
          const nn = S.nodes.find((x) => x.id === id);
          const o = orig.get(id);
          const lead = orig.get(n.id) || o;
          // The lead node snaps by its corner; the others keep their offsets.
          const sx = snap(lead.x + dx, ev) - lead.x, sy = snap(lead.y + dy, ev) - lead.y;
          nn.x = o.x + sx;
          nn.y = o.y + sy;
          if (nn.shapes && o.shapes) {
            nn.shapes = clone(o.shapes);
            nn.shapes.forEach((s) => moveShape(s, sx, sy));
          }
        }
        render();
      };
      const up = () => {
        board.removeEventListener("pointermove", move);
        board.removeEventListener("pointerup", up);
        if (!moved) onClick?.();
        if (moved) {
          S.drag = false;
          render();
          toast(cloned ? `${CLONE_KEY}+drag: cloned on the server, one undo step` : `Moved, snapped to the ${GRID} px grid (${NOSNAP_KEY} held: no snap); one write`, 2400);
        }
      };
      board.addEventListener("pointermove", move);
      board.addEventListener("pointerup", up);
    }
    // A new edge: from a side handle to another node.
    function startEdgeDrag(e, handle) {
      e.stopPropagation();
      const from = S.nodes.find((x) => x.id === handle.dataset.nodeId);
      const side = handle.dataset.side;
      const p0 = sideAnchor(rectOf(from), side);
      board.setPointerCapture?.(e.pointerId);
      S.drag = true;
      const move = (ev) => {
        const p = toBoard(ev.clientX, ev.clientY);
        const opp = Math.abs(p.x - p0.x) > Math.abs(p.y - p0.y) ? (p.x > p0.x ? "left" : "right") : p.y > p0.y ? "top" : "bottom";
        S.tempEdge = curve(p0, side, p, opp).d;
        render();
      };
      const up = (ev) => {
        board.removeEventListener("pointermove", move);
        board.removeEventListener("pointerup", up);
        S.drag = false;
        S.tempEdge = null;
        const p = toBoard(ev.clientX, ev.clientY);
        const target = S.nodes.filter((n) => n.id !== from.id && n.type !== "group" && p.x >= n.x && p.x <= n.x + n.w && p.y >= n.y && p.y <= n.y + n.h).pop() ||
          S.nodes.filter((n) => n.id !== from.id && p.x >= n.x && p.x <= n.x + n.w && p.y >= n.y && p.y <= n.y + n.h).pop();
        if (!target) return render();
        const r = rectOf(target);
        const d = { left: Math.abs(p.x - r.x), right: Math.abs(r.x + r.width - p.x), top: Math.abs(p.y - r.y), bottom: Math.abs(r.y + r.height - p.y) };
        const toSide = Object.entries(d).sort((a, b) => a[1] - b[1])[0][0];
        write("Edge added between those sides: one POST …/canvas/edges, one undo step", () => S.edges.push({ id: newId("e"), from: from.id, fromSide: side, to: target.id, toSide }));
      };
      board.addEventListener("pointermove", move);
      board.addEventListener("pointerup", up);
    }

    // Comment, as the canvas has it today: a click on an element of a page.
    function commentPick(e, page) {
      e.preventDefault();
      const t = e.target;
      $$(".kp-picked", world).forEach((x) => x.classList.remove("kp-picked"));
      t.classList.add("kp-picked");
      closeMenus();
      const at = boardAt(e);
      const pop = el(`${FRAGS.popover}`);
      pop.classList.add("kp-pop");
      pop.style.left = `${Math.min(at.x + 12, board.clientWidth - 260)}px`;
      pop.style.top = `${Math.min(at.y + 12, board.clientHeight - 170)}px`;
      $("code", pop).textContent = t.tagName.toLowerCase();
      board.append(pop);
      const note = $(".canvas-popover-note", pop);
      note.focus({ preventScroll: true });
      $(".canvas-popover-cancel", pop).onclick = () => (pop.remove(), t.classList.remove("kp-picked"));
      $(".canvas-popover-add", pop).onclick = () => {
        S.picks.push({ kind: "element", name: t.tagName.toLowerCase(), note: note.value.trim() });
        pop.remove();
        t.classList.remove("kp-picked");
        renderBar();
      };
    }

    // ----- the page inside a frame keeps running -----
    world.addEventListener("click", (e) => {
      const a = e.target.closest("[data-kp-action]");
      if (!a || S.mode !== "interact") return;
      const frame = a.closest("[data-frame-id]");
      const n = frame && S.nodes.find((x) => x.id === frame.dataset.frameId);
      if (a.dataset.kpAction === "cart" && n) {
        n.count = (n.count || 0) + 1;
        const c = $("[data-kp-count]", frame);
        if (c) c.textContent = String(n.count);
      }
      if (a.dataset.kpAction === "signin") {
        const s = $("[data-kp-said]", frame);
        if (s) s.hidden = false;
      }
    });
    world.addEventListener("click", (e) => {
      const b = e.target.closest(".canvas-frame-btn");
      if (!b) return;
      toast(b.title === "Reload" ? "Reload: the page loads again, its frame alone." : `${b.title}: as the canvas has it today.`);
    });
    setInterval(() => {
      for (const n of S.nodes.filter((x) => x.page === "shop")) {
        n.live = 9 + Math.floor(Math.random() * 7);
        const v = $(`[data-frame-id="${n.id}"] [data-kp-live]`, world);
        if (v) v.textContent = String(n.live);
      }
    }, 1600);

    // ----- keys: one table for both issues (#570, Decision 3; #606, Keys) -----
    // Letters are matched on e.key for Latin layouts, on e.code otherwise.
    let space = false;
    document.addEventListener("keyup", (e) => {
      if (e.code === "Space") {
        space = false;
        capture.classList.remove("is-panning");
      }
    });
    document.addEventListener("keydown", (e) => {
      if ($(".confirm-dialog-backdrop")) return;
      const typing = e.target.closest?.("input, textarea, [contenteditable]");
      const mod = e.ctrlKey || e.metaKey;
      const latin = /^[a-z]$/i.test(e.key);
      const letter = (l) => (latin ? e.key.toLowerCase() === l : e.code === `Key${l.toUpperCase()}`);
      if (e.key === "Escape") {
        // Escape steps back: a menu, full screen, the presentation, a stroke
        // and Draw, the search field, Focus, the selection, Comment, the window.
        if ($(".cv-menu, .kp-palette") || $(".kp-pop:not(.kp-conflict)", pane)) return closeMenus();
        if (S.fullscreen) return setFullscreen(false);
        if (S.pres) return endPresentation();
        if (S.draw) return drawEscape();
        if ($(".cv-search", board)) return closeSearch();
        if (S.focus) return setFocus(false);
        if (S.sel.size || S.selEdge) {
          S.sel.clear();
          S.selEdge = null;
          return render();
        }
        if (S.mode === "comment") return setMode("interact");
        return toast("Escape now closes the Files window, as it does today.");
      }
      if (mod && letter("f")) {
        e.preventDefault();
        return openSearch();
      }
      if (typing) return;
      if (e.code === "Space" && S.draw) {
        space = true;
        capture.classList.add("is-panning");
        e.preventDefault();
        return;
      }
      if (mod && letter("z")) {
        e.preventDefault();
        if (S.draw) return drawUndo();
        return e.shiftKey ? redo() : undo();
      }
      if (letter("f") && !mod && cfg.fullscreen && !noFullscreen) return setFullscreen(!S.fullscreen);
      if (S.pres) {
        if (["ArrowRight", "ArrowUp", "ArrowDown", "PageDown"].includes(e.key)) return e.preventDefault(), next();
        if (["ArrowLeft", "PageUp"].includes(e.key)) return e.preventDefault(), back();
        return;
      }
      if (S.draw) {
        const t = { v: "move", p: "pen", o: "ellipse", r: "rect", a: "arrow", t: "text", e: "eraser" }[latin ? e.key.toLowerCase() : e.code.replace("Key", "").toLowerCase()];
        if (t && !mod) return setTool(t);
        return;
      }
      if ((e.key === "Delete" || e.key === "Backspace") && cfg.edit) return deleteSel();
      if (e.shiftKey && e.code === "Digit1") return e.preventDefault(), fit();
      if (e.shiftKey && e.code === "Digit2") return e.preventDefault(), zoomToSelection();
      const dirs = { ArrowRight: "right", ArrowLeft: "left", ArrowUp: "up", ArrowDown: "down" };
      if (dirs[e.key] && S.sel.size) return e.preventDefault(), navigate(dirs[e.key]);
      if (e.key === "+" || e.key === "=") return zoomAt(ZOOM_STEP, ...center());
      if (e.key === "-") return zoomAt(1 / ZOOM_STEP, ...center());
      if (e.key === "0") return fit();
    });
    // #570: move between nodes from the keyboard, as the plugin 7.1.0 navigates.
    function navigate(dir) {
      const cur = selectedNodes()[0];
      if (!cur) return;
      const a = rectFor(cur);
      const hidden = hiddenSet();
      let best = null;
      for (const n of S.nodes) {
        if (n === cur || hidden.has(n.id) || n.type === "group") continue;
        const r = rectFor(n);
        const horiz = dir === "left" || dir === "right";
        const overlap = horiz ? r.y < a.y + a.height && r.y + r.height > a.y : r.x < a.x + a.width && r.x + r.width > a.x;
        if (!overlap) continue;
        const gap = { right: r.x - (a.x + a.width), left: a.x - (r.x + r.width), down: r.y - (a.y + a.height), up: a.y - (r.y + r.height) }[dir];
        if (gap < -1) continue;
        const dc = Math.hypot(r.x + r.width / 2 - (a.x + a.width / 2), r.y + r.height / 2 - (a.y + a.height / 2));
        if (!best || gap < best.gap || (gap === best.gap && dc < best.dc)) best = { n, gap, dc };
      }
      if (!best) return toast("No node that way.");
      select([best.n.id]);
      reveal(best.n);
    }

    // ----- full screen: one for both issues (#570, Stage 4; #606, Stage 2) -----
    // The canvas pane in full screen in any mode: the board, its controls and
    // the prompt bar; nothing moves in the DOM, so pages keep running. Safari
    // on iPhone cannot put an element in full screen: no button there.
    let noFullscreen = false;
    function setFullscreen(on) {
      if (on && noFullscreen) return;
      closeMenus();
      S.fullscreen = on;
      pane.classList.toggle("kp-fullscreen", on);
      const b = $(".kp-fs-btn", board);
      if (b) {
        $(".kp-fs-text", b).textContent = on ? "Exit full screen" : "Full screen";
        b.title = on ? "Exit full screen (F, Escape)" : "Full screen (F)";
      }
      const pb = $(".cv-full", pane);
      if (pb) {
        pb.querySelector("svg").outerHTML = on ? ICONS.unscreen : ICONS.screen;
        pb.querySelector("span")?.replaceChildren(document.createTextNode(on ? "Exit full screen" : "Full screen"));
        pb.title = on ? "Exit full screen" : PHONE ? "Full screen" : "Full screen (F)";
      }
      requestAnimationFrame(() => (S.pres ? showSlide() : S.fitted ? fit() : applyCam()));
      cfg.onFullscreen?.(on, api);
    }
    api.setFullscreen = setFullscreen;
    $(".kp-fs-btn", board)?.addEventListener("click", () => setFullscreen(!S.fullscreen));
    api.setNoFullscreen = (v) => {
      noFullscreen = v;
      if (v && S.fullscreen) setFullscreen(false);
      $(".kp-fs-controls", board)?.toggleAttribute("hidden", v);
    };

    // ----- #570, Stage 2: search over what the board read, and Focus -----
    function searchIndex() {
      const out = [];
      for (const n of S.nodes) {
        const k = kindOf(n);
        const folded = S.nodes.find((g) => g.type === "group" && g.collapsed && strictlyInside(n, g));
        const where = folded ? `in ${folded.label}, collapsed` : "";
        if (n.type === "group") out.push({ id: n.id, text: n.label || "", kind: where || "group label" });
        else if (k === "text") out.push({ id: n.id, text: plain(n.text).replace(/\n/g, " "), kind: where || (n.truncated ? "card, text cut" : "card"), cut: !!n.truncated });
        else if (k === "frame") out.push({ id: n.id, text: titleOf(n), kind: where || "frame" });
        else if (k === "note") out.push({ id: n.id, text: `${baseOf(n.file)}: ${plain(n.note).replace(/\n/g, " ")}`, kind: where || "note" });
        else if (k === "link") out.push({ id: n.id, text: n.url, kind: where || "link" });
        else out.push({ id: n.id, text: baseOf(n.file), kind: where || kindName(n) });
      }
      for (const e of S.edges) if (e.label) out.push({ id: `e:${e.id}`, text: `edge "${e.label}"`, kind: "edge label" });
      return out;
    }
    let searchState = null;
    function openSearch() {
      if (S.pres || S.draw) return toast(S.pres ? "End the presentation to search." : "Search waits until Draw is done.");
      closeMenus();
      if ($(".cv-search", board)) return focusSoft($(".cv-search input", board));
      const sb = el(`<div class="cv-search" role="search"><div class="cv-search-row">${ICONS.search}<input type="text" aria-label="Search the board" placeholder="Search the board" autocomplete="off"><span class="cv-search-count"></span><button type="button" class="cv-search-close" aria-label="Close search">×</button></div><div class="cv-search-results" role="listbox"></div><div class="cv-search-foot"><kbd>↑</kbd><kbd>↓</kbd> move <kbd>Enter</kbd> fit <kbd>Esc</kbd> close<span>${MOD}+F</span></div></div>`);
      board.append(sb);
      searchState = { i: 0, hits: [] };
      const input = $("input", sb);
      input.oninput = () => runSearch(input.value);
      input.onkeydown = (e) => {
        if (e.key === "ArrowDown" || e.key === "ArrowUp") {
          e.preventDefault();
          e.stopPropagation();
          moveHit(e.key === "ArrowDown" ? 1 : -1);
        } else if (e.key === "Enter") {
          e.preventDefault();
          pickHit(searchState.i);
        }
      };
      $(".cv-search-close", sb).onclick = closeSearch;
      focusSoft(input);
      runSearch("");
    }
    function closeSearch() {
      $(".cv-search", board)?.remove();
      searchState = null;
    }
    function runSearch(q) {
      const sb = $(".cv-search", board);
      if (!sb) return;
      const ql = q.trim().toLowerCase();
      const hits = ql ? searchIndex().filter((h) => h.text.toLowerCase().includes(ql)) : [];
      searchState.hits = hits;
      searchState.i = 0;
      $(".cv-search-count", sb).textContent = ql ? (hits.length ? `1 of ${hits.length}` : "no match") : "";
      $(".cv-search-results", sb).innerHTML = hits
        .map((h, i) => {
          const at = h.text.toLowerCase().indexOf(ql);
          const from = Math.max(0, at - 18);
          const snip = (from ? "…" : "") + h.text.slice(from, at) + "\u0001" + h.text.slice(at, at + ql.length) + "\u0002" + h.text.slice(at + ql.length, at + ql.length + 28) + (at + ql.length + 28 < h.text.length ? "…" : "");
          return `<button type="button" role="option" class="mode-item cv-search-hit${i === 0 ? " is-active" : ""}" data-i="${i}"><span class="cv-search-text">${esc(snip).replace("\u0001", "<mark>").replace("\u0002", "</mark>")}</span><span class="cv-search-kind">${esc(h.kind)}</span></button>`;
        })
        .join("");
      $$(".cv-search-hit", sb).forEach((x) => (x.onclick = () => pickHit(Number(x.dataset.i))));
      if (hits.length) pickHit(0, true);
    }
    function moveHit(d) {
      if (!searchState?.hits.length) return;
      searchState.i = (searchState.i + d + searchState.hits.length) % searchState.hits.length;
      $$(".cv-search-hit", board).forEach((x, i) => x.classList.toggle("is-active", i === searchState.i));
      $(".cv-search-count", board).textContent = `${searchState.i + 1} of ${searchState.hits.length}`;
      pickHit(searchState.i, true);
    }
    // A result selects its node and fits it under the panel; an edge result
    // its two nodes; a hidden member's result shows its group to this viewer.
    function pickHit(i, quiet) {
      const h = searchState?.hits[i];
      if (!h) return;
      searchState.i = i;
      $$(".cv-search-hit", board).forEach((x, j) => x.classList.toggle("is-active", j === i));
      const n = h.id.startsWith("e:") ? null : nodeById(h.id);
      if (n) for (const g of S.nodes) if (g.type === "group" && g.collapsed && strictlyInside(n, g)) S.shown.add(g.id);
      S.sel = new Set([h.id]);
      S.selEdge = null;
      render();
      if (h.cut) toastHtml("This card's text was cut at 20000 bytes in what the board read (<code>truncated</code>): the search reads only that part.");
      const sb = $(".cv-search", board);
      const roomTop = PHONE ? 0 : Math.min(320, (sb?.offsetTop || 0) + (sb?.offsetHeight || 0) + 12);
      fitTo(boundsOf(selectionRects()), { roomTop, max: 1 });
      if (!quiet) $(".cv-search input", board)?.blur();
    }
    api.search = (q) => {
      if (!$(".cv-search", board)) openSearch();
      $(".cv-search input", board).value = q;
      runSearch(q);
    };
    api.moveHit = moveHit;
    $(".cv-search-btn", board)?.addEventListener("click", openSearch);

    // ----- #570, Stage 4: presenting in place, walking as the plugin walks -----
    function startPresentation() {
      if (S.draw) return toast("Leave Draw first: Done keeps the strokes.");
      closeMenus();
      closeSearch();
      let start = S.meta?.startNode && nodeById(S.meta.startNode) ? S.meta.startNode : null;
      if (!start) start = selectedNodes()[0]?.id || null;
      if (!start) return toastHtml("No start slide: set one with <strong>Set as start slide</strong> in a node's menu, or select the node to start at.");
      S.pres = { visited: [start], travelled: [] };
      pane.classList.add("cv-presenting");
      S.sel.clear();
      S.selEdge = null;
      S.focus = false;
      const full = noFullscreen ? "" : PHONE ? `<button type="button" class="cv-present-btn cv-full" aria-label="Full screen" title="Full screen">${ICONS.screen}</button>` : `<button type="button" class="cv-present-btn cv-full" title="Full screen (F)">${ICONS.screen}<span>Full screen</span><kbd>F</kbd></button>`;
      const c = el(`<div class="cv-present" role="toolbar" aria-label="Presentation">
        <button type="button" class="cv-present-btn cv-back">‹ Back</button><span class="cv-present-where"></span>
        <button type="button" class="cv-present-btn cv-next">Next ›</button><span class="cv-present-sep"></span>
        ${full}
        <button type="button" class="cv-present-btn cv-end"${PHONE ? ' aria-label="End the presentation" title="End"' : ""}>${PHONE ? "×" : "End <kbd>Esc</kbd>"}</button></div>`);
      board.append(c);
      $(".cv-back", c).onclick = back;
      $(".cv-next", c).onclick = next;
      $(".cv-full", c)?.addEventListener("click", () => setFullscreen(!S.fullscreen));
      $(".cv-end", c).onclick = endPresentation;
      if (S.fullscreen) setFullscreen(true);
      showSlide();
    }
    api.startPresentation = startPresentation;
    const outgoing = (id) => S.edges.filter((e) => e.from === id && nodeById(e.to));
    // Next, as the plugin walks: one outgoing edge, go and record nothing;
    // several, sorted by label (unlabelled last), the first not travelled,
    // else the last, and record it; none, stay.
    function nextEdge(id) {
      const out = outgoing(id);
      if (!out.length) return null;
      if (out.length === 1) return { e: out[0], record: false };
      const sorted = [...out].sort((x, y) => (x.label ? (y.label ? x.label.localeCompare(y.label) : -1) : y.label ? 1 : 0));
      const fresh = sorted.find((e) => !S.pres.travelled.includes(e.id));
      return { e: fresh || sorted[sorted.length - 1], record: true };
    }
    function next() {
      if (!S.pres) return;
      const step = nextEdge(S.pres.visited.at(-1));
      if (!step) return toast("The last slide: no edge leads on.");
      S.pres.visited.push(step.e.to);
      if (step.record) S.pres.travelled.push(step.e.id);
      showSlide();
    }
    function back() {
      if (!S.pres || S.pres.visited.length <= 1) return;
      S.pres.visited.pop();
      S.pres.travelled.pop();
      showSlide();
    }
    api.next = next;
    api.back = back;
    function showSlide() {
      const id = S.pres.visited.at(-1);
      const n = nodeById(id);
      for (const g of S.nodes) if (g.type === "group" && g.collapsed && strictlyInside(n, g)) S.shown.add(g.id);
      render();
      fitTo(boundsOf([rectFor(n)]), { max: 2 });
      const step = nextEdge(id);
      $(".cv-present-where", pane).innerHTML = PHONE ? `Slide ${S.pres.visited.length}` : `Slide ${S.pres.visited.length}${step ? ` · next along ${step.e.label ? `edge "${esc(step.e.label)}"` : "the edge"}` : " · the last"}`;
      $(".cv-back", pane).disabled = S.pres.visited.length <= 1;
      $(".cv-next", pane).disabled = !step;
      cfg.onSlide?.(id, api);
    }
    function endPresentation() {
      if (!S.pres) return;
      if (S.fullscreen) setFullscreen(false);
      S.pres = null;
      $(".cv-present", pane)?.remove();
      pane.classList.remove("cv-presenting");
      render();
      fit();
      toast("The presentation ended; walking wrote nothing.");
    }
    api.endPresentation = endPresentation;

    // ----- #570, Stage 4: export of the board or the selection -----
    function exportDialog() {
      closeMenus();
      const count = selectedNodes().length;
      const d = el(`<div class="confirm-dialog-backdrop"><div class="confirm-dialog cv-export" role="dialog" aria-modal="true" aria-label="Export">
        <div class="confirm-dialog-body"><span class="confirm-dialog-icon confirm-dialog-icon--primary" aria-hidden="true">${ICONS.download.replace('width="16" height="16"', 'width="22" height="22"')}</span>
        <div class="confirm-dialog-text"><h2 class="confirm-dialog-title">Export</h2>
          <fieldset class="cv-field"><legend>What</legend><label><input type="radio" name="what" value="board" checked> Board</label><label${count ? "" : ' class="is-disabled"'}><input type="radio" name="what" value="selection"${count ? "" : " disabled"}> Selection${count ? ` (${count} node${count === 1 ? "" : "s"})` : ""}</label></fieldset>
          <fieldset class="cv-field"><legend>Format</legend><span class="cv-seg"><button type="button" class="cv-seg-btn" data-f="svg">SVG</button><button type="button" class="cv-seg-btn is-on" data-f="png">PNG</button></span></fieldset>
          <label class="cv-check"><input type="checkbox" class="cv-transparent" checked> Transparent background</label>
          <p class="confirm-dialog-message cv-export-size"></p></div></div>
        <div class="confirm-dialog-actions"><button type="button" class="confirm-dialog-btn confirm-dialog-btn--cancel">Cancel</button><button type="button" class="confirm-dialog-btn confirm-dialog-btn--primary">Download</button></div></div></div>`);
      ($(".kp-fullscreen") || body).append(d);
      let fmt = "png";
      const size = () => {
        const what = $('input[name="what"]:checked', d).value;
        const hidden = hiddenSet();
        const rs = what === "selection" ? selectionRects() : S.nodes.filter((x) => !hidden.has(x.id)).map(rectFor);
        const r = boundsOf(rs);
        let w = Math.round(r.width * 2), h = Math.round(r.height * 2);
        const k = Math.min(1, 8192 / Math.max(w, h), Math.sqrt(16e6 / (w * h)));
        w = Math.round(w * k);
        h = Math.round(h * k);
        $(".cv-check", d).hidden = fmt !== "png";
        $(".cv-export-size", d).textContent =
          (fmt === "png" ? `PNG ${w} × ${h} px (at most 8192 a side and 16 million pixels). ` : "SVG, the pictures embedded as PNG. ") +
          "Frames become placeholders with their page's path; pictures, sketches and diagrams are embedded as images; the theme is the board's. Nothing is written to the workspace.";
        return [w, h];
      };
      $$(".cv-seg-btn", d).forEach((x) => (x.onclick = () => ((fmt = x.dataset.f), $$(".cv-seg-btn", d).forEach((y) => y.classList.toggle("is-on", y === x)), size())));
      $$('input[name="what"]', d).forEach((r) => (r.onchange = size));
      size();
      const close = () => d.remove();
      $(".confirm-dialog-btn--cancel", d).onclick = close;
      d.addEventListener("mousedown", (e) => e.target === d && close());
      $(".confirm-dialog-btn--primary", d).onclick = () => {
        const [w, h] = size();
        close();
        toastHtml(`Downloaded <strong>${esc(baseOf(S.path).replace(".canvas", `.${fmt}`))}</strong>${fmt === "png" ? `, ${w} × ${h}` : ""}: the browser saved it; nothing was written to the workspace and nothing entered undo.`);
      };
      focusSoft($(".confirm-dialog-btn--primary", d));
      cfg.onExport?.(api);
    }
    api.exportDialog = exportDialog;

    // ----- modes -----
    async function setMode(m) {
      if (m === S.mode) return;
      if (S.draw && m !== "draw") {
        if (!(await leaveDraw())) return;
      }
      if (m === "draw") return startDraw();
      S.mode = m;
      $$(".canvas-mode-btn", board).forEach((b) => {
        const on = b.dataset.kpMode === m;
        b.classList.toggle("is-active", on);
        b.setAttribute("aria-pressed", String(on));
      });
      board.classList.toggle("is-commenting", m === "comment");
      $$(".kp-inline-page", world).forEach((p) => p.classList.toggle("is-picking", m === "comment"));
      cfg.onMode?.(m, api);
    }
    $$(".canvas-mode-btn", board).forEach((b) => (b.onclick = () => setMode(b.dataset.kpMode)));
    function markMode(m) {
      S.mode = m;
      $$(".canvas-mode-btn", board).forEach((b) => {
        const on = b.dataset.kpMode === m;
        b.classList.toggle("is-active", on);
        b.setAttribute("aria-pressed", String(on));
      });
    }

    // ---------- Stage 2: Draw ----------
    const TOOLS = [
      ["move", "Move", "V", svgIcon('<path d="M12 3v18M3 12h18"/><path d="M9 6l3-3 3 3M9 18l3 3 3-3M6 9l-3 3 3 3M18 9l3 3-3 3"/>')],
      ["pen", "Pen", "P", svgIcon('<path d="M16.5 3.5l4 4L8 20H4v-4L16.5 3.5z"/><path d="M14 6l4 4"/>')],
      ["ellipse", "Ellipse", "O", svgIcon('<circle cx="12" cy="12" r="8"/>')],
      ["rect", "Rectangle", "R", svgIcon('<rect x="4" y="6" width="16" height="12"/>')],
      ["arrow", "Arrow", "A", svgIcon('<path d="M5 19L18 6"/><path d="M10 5h9v9"/>')],
      ["text", "Text", "T", svgIcon('<path d="M5 6V4.5h14V6"/><path d="M12 4.5V20"/><path d="M9 20h6"/>')],
      ["eraser", "Eraser", "E", svgIcon('<path d="M8 20h12"/><path d="M5.6 15.6l8.5-8.5a2 2 0 0 1 2.8 0l2 2a2 2 0 0 1 0 2.8L12 19H9z"/><path d="M10 11l4 4"/>')],
    ];
    const UNDO_ICON = svgIcon('<path d="M9 14L4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>');
    function drawBarHTML() {
      const d = S.draw;
      const tools = TOOLS.map(([t, name, key, icon]) => `<button type="button" class="markup-tool${d.tool === t ? " is-active" : ""}" aria-pressed="${d.tool === t}" aria-label="${name}" title="${name} (${key})" data-kp-tool="${t}">${icon}</button>`).join("");
      const swatches = PHONE
        ? `<button type="button" class="markup-swatch is-active kp-current-swatch" style="background: ${d.color};" aria-label="Colour: ${d.color}" title="Colour"></button>`
        : MARKUP_PALETTE.map(([id, c]) => `<button type="button" class="markup-swatch${d.color === c ? " is-active" : ""}" style="background: ${c};" aria-pressed="${d.color === c}" aria-label="${id}" title="${id[0].toUpperCase() + id.slice(1)}" data-kp-color="${c}"></button>`).join("") +
          `<button type="button" class="markup-swatch kp-palette-swatch${MARKUP_PALETTE.some(([, c]) => c === d.color) ? "" : " is-active"}" aria-label="More colours" title="More colours"></button>`;
      return `<button type="button" class="markup-action markup-action--cancel" data-kp-draw="cancel">Cancel</button>
        <div class="markup-tools" role="toolbar" aria-label="Draw tools">${tools}<span class="markup-sep" aria-hidden="true"></span>
        <button type="button" class="markup-tool" aria-label="Undo" title="Undo (Ctrl+Z)" data-kp-draw="undo"${d.stack.length ? "" : " disabled"}>${UNDO_ICON}</button><span class="markup-sep" aria-hidden="true"></span>
        <span class="markup-swatches" role="group" aria-label="Colours">${swatches}</span></div>
        <div class="kp-draw-actions"><button type="button" class="markup-action kp-send" data-kp-draw="send">Send</button><button type="button" class="markup-action markup-action--done" data-kp-draw="done">Done</button></div>`;
    }
    function renderDrawBar() {
      let barEl = $(".kp-draw-bar", board);
      if (!S.draw) return barEl?.remove();
      if (!barEl) {
        barEl = el('<div class="markup-bar kp-draw-bar" role="toolbar" aria-label="Draw"></div>');
        board.append(barEl);
        barEl.addEventListener("pointerdown", (e) => e.stopPropagation());
        barEl.addEventListener("click", (e) => {
          const t = e.target.closest("[data-kp-tool]");
          if (t) return setTool(t.dataset.kpTool);
          const c = e.target.closest("[data-kp-color]");
          if (c) return setColor(c.dataset.kpColor);
          if (e.target.closest(".kp-palette-swatch, .kp-current-swatch")) return openPalette();
          const a = e.target.closest("[data-kp-draw]");
          if (!a) return;
          if (a.dataset.kpDraw === "undo") drawUndo();
          if (a.dataset.kpDraw === "cancel") leaveDraw();
          if (a.dataset.kpDraw === "done") drawDone();
          if (a.dataset.kpDraw === "send") drawDone({ send: true });
        });
      }
      barEl.innerHTML = drawBarHTML();
    }
    function drawLayer() {
      const d = S.draw;
      if (!d) return "";
      let out = d.shapes.map(drawn).join("");
      if (d.live) out += drawn(d.live);
      for (const i of d.sel) {
        const s = d.shapes[i];
        if (!s) continue;
        const b = shapeBox(s);
        const pad = 6 / S.cam.scale + (s.width || 0) / 2;
        out += `<rect class="kp-draw-sel" x="${b.x - pad}" y="${b.y - pad}" width="${b.width + pad * 2}" height="${b.height + pad * 2}"/>`;
      }
      if (d.box) out += `<rect class="kp-draw-box" x="${Math.min(d.box.a.x, d.box.b.x)}" y="${Math.min(d.box.a.y, d.box.b.y)}" width="${Math.abs(d.box.b.x - d.box.a.x)}" height="${Math.abs(d.box.b.y - d.box.a.y)}"/>`;
      return out;
    }
    function startDraw(opts = {}) {
      if (S.pres) return toast("End the presentation to draw.");
      if (S.readOnly) return toastHtml("<strong>Read-only view:</strong> Draw writes a sketch, so it waits until the board is editable.");
      closeSearch();
      closeMenus();
      if (S.editing) commitEdit();
      const editing = opts.editing ? S.nodes.find((n) => n.id === opts.editing) : null;
      S.draw = {
        tool: opts.tool || "pen",
        color: opts.color || (editing ? editing.shapes[0]?.color : null) || (S.lastColor ?? "#ffcc00"),
        shapes: editing ? clone(editing.shapes) : clone(opts.shapes || []),
        sel: new Set(),
        stack: [],
        changes: opts.changes ?? 0,
        editing: editing ? editing.id : null,
      };
      S.sel.clear();
      markMode("draw");
      capture.hidden = false;
      capture.dataset.tool = S.draw.tool;
      renderDrawBar();
      render();
      cfg.onDraw?.(true, api);
      if (editing) toast(`Editing ${editing.file}: its shapes are read back from the subset the server writes.`);
    }
    function setTool(t) {
      if (!S.draw) return;
      commitLabel();
      S.draw.tool = t;
      if (t !== "move") S.draw.sel.clear();
      capture.dataset.tool = t;
      renderDrawBar();
      render();
    }
    function setColor(c) {
      if (!S.draw) return;
      S.draw.color = c;
      S.lastColor = c;
      renderDrawBar();
    }
    api.setTool = setTool;
    api.setColor = setColor;
    function pushDraw() {
      S.draw.stack.push(clone(S.draw.shapes));
      S.draw.changes++;
    }
    function drawUndo() {
      const d = S.draw;
      if (!d || !d.stack.length) return;
      d.shapes = d.stack.pop();
      d.changes = Math.max(0, d.changes - 1);
      d.sel.clear();
      renderDrawBar();
      render();
    }
    api.drawUndo = drawUndo;
    async function leaveDraw() {
      const d = S.draw;
      if (!d) return true;
      commitLabel();
      if (d.changes > 0 || d.stack.length > 0) {
        const n = Math.max(d.changes, d.stack.length);
        if (!(await keepOrDiscard(n, S.fullscreen ? pane : body))) return false;
      }
      exitDraw();
      return true;
    }
    api.leaveDraw = leaveDraw;
    function exitDraw() {
      S.draw = null;
      capture.hidden = true;
      renderDrawBar();
      markMode("interact");
      render();
      cfg.onDraw?.(false, api);
    }
    function drawEscape() {
      const d = S.draw;
      if (d.live || d.box || d.moving) {
        d.live = null;
        d.box = null;
        d.moving = null;
        render();
        return;
      }
      if ($(".kp-label-input", board)) return commitLabel(true);
      leaveDraw();
    }
    // Done: one POST …/canvas/sketches; the server writes the SVG.
    function drawDone(opts = {}) {
      const d = S.draw;
      if (!d) return;
      commitLabel();
      if (!d.shapes.length) {
        exitDraw();
        return toast("Nothing drawn: Draw closes and nothing is written.");
      }
      const boxes = d.shapes.map(shapeBox);
      const wide = Math.max(...d.shapes.map((s) => s.width || 0)) / 2;
      let x = Math.floor(Math.min(...boxes.map((b) => b.x)) - wide), y = Math.floor(Math.min(...boxes.map((b) => b.y)) - wide);
      let w = Math.ceil(Math.max(...boxes.map((b) => b.x + b.width)) + wide) - x, h = Math.ceil(Math.max(...boxes.map((b) => b.y + b.height)) + wide) - y;
      w = Math.max(w, MIN.w);
      h = Math.max(h, MIN.h);
      const bounds = { x, y, width: w, height: h };
      const cx = x + w / 2, cy = y + h / 2;
      const over = S.nodes
        .filter((n) => n.type !== "sketch" && n.id !== d.editing && meets(rectOf(n), bounds))
        .sort((a, b) => Math.hypot(a.x + a.w / 2 - cx, a.y + a.h / 2 - cy) - Math.hypot(b.x + b.w / 2 - cx, b.y + b.h / 2 - cy))
        .slice(0, 50)
        .map((n) => n.id);
      const file = `canvas/sketches/${B}-${S.sketchNo++}.svg`;
      const node = { id: newId("s"), type: "sketch", file, x, y, w, h, shapes: clone(d.shapes), over, border: over.length ? "invisible" : undefined };
      const editing = d.editing;
      S.draw = null;
      capture.hidden = true;
      renderDrawBar();
      markMode("interact");
      write(
        editing
          ? `Done: ${file} written; its node takes the old one's place in the same write, the old file stays; one undo step`
          : `Done: ${file} written and its node added in the same write${over.length ? `, over ${over.length} node${over.length === 1 ? "" : "s"} it is drawn over` : ""}; one undo step`,
        () => {
          if (editing) {
            const i = S.nodes.findIndex((n) => n.id === editing);
            if (i >= 0) S.nodes.splice(i, 1, { ...node, id: S.nodes[i].id });
          } else S.nodes.push(node);
        },
      );
      cfg.onDraw?.(false, api);
      const id = editing || node.id;
      if (opts.send) {
        S.picks = [{ kind: "sketch", id, name: file.split("/").pop() }];
        renderBar();
        $(".canvas-bar-field", pane)?.focus({ preventScroll: true });
        toast("Send ran Done first, then put the sketch into the prompt bar as a chip.");
      }
      cfg.onDone?.(id, api);
      return id;
    }
    api.drawDone = drawDone;

    // Pointer in Draw: board units at any zoom.
    let pointers = new Map();
    let pinch = null;
    capture.addEventListener("pointerdown", (e) => {
      const d = S.draw;
      if (!d) return;
      e.preventDefault();
      capture.setPointerCapture?.(e.pointerId);
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pointers.size === 2) {
        // Two fingers pan and zoom; the stroke they interrupted is dropped.
        d.live = null;
        const [a, b] = [...pointers.values()];
        pinch = { dist: Math.hypot(a.x - b.x, a.y - b.y), mid: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 } };
        render();
        return;
      }
      if (space || e.button === 1) {
        d.panning = { x: e.clientX, y: e.clientY, cam: { ...S.cam } };
        return;
      }
      commitLabel();
      const p = toBoard(e.clientX, e.clientY);
      const tol = 6 / S.cam.scale;
      if (d.tool === "pen") d.live = { kind: "pen", color: d.color, width: STROKE, points: [p] };
      else if (["ellipse", "rect", "arrow"].includes(d.tool)) d.live = { kind: d.tool, color: d.color, width: STROKE, a: p, b: p };
      else if (d.tool === "text") return openLabel(p);
      else if (d.tool === "eraser") {
        d.erasing = { before: clone(d.shapes), hit: false };
        erase(p, tol);
      } else if (d.tool === "move") {
        const i = d.shapes.map((s, k) => [s, k]).reverse().find(([s]) => hitShape(s, p, tol))?.[1];
        if (i !== undefined) {
          if (e.shiftKey) d.sel.has(i) ? d.sel.delete(i) : d.sel.add(i);
          else if (!d.sel.has(i)) d.sel = new Set([i]);
          d.moving = { start: p, before: clone(d.shapes), moved: false };
        } else {
          if (!e.shiftKey) d.sel.clear();
          d.box = { a: p, b: p };
        }
      }
      render();
    });
    capture.addEventListener("pointermove", (e) => {
      const d = S.draw;
      if (!d) return;
      if (pointers.has(e.pointerId)) pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pinch && pointers.size === 2) {
        const [a, b] = [...pointers.values()];
        const dist = Math.hypot(a.x - b.x, a.y - b.y);
        const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
        const r = board.getBoundingClientRect();
        S.cam.x += mid.x - pinch.mid.x;
        S.cam.y += mid.y - pinch.mid.y;
        zoomAt(dist / pinch.dist, mid.x - r.left, mid.y - r.top);
        pinch = { dist, mid };
        return;
      }
      if (d.panning) {
        S.cam = { ...d.panning.cam, x: d.panning.cam.x + e.clientX - d.panning.x, y: d.panning.cam.y + e.clientY - d.panning.y };
        S.fitted = false;
        return applyCam();
      }
      const p = toBoard(e.clientX, e.clientY);
      if (d.live?.kind === "pen") {
        const last = d.live.points[d.live.points.length - 1];
        if (Math.hypot(p.x - last.x, p.y - last.y) * S.cam.scale >= 1.5) d.live.points.push(p);
      } else if (d.live) d.live.b = p;
      else if (d.erasing) erase(p, 6 / S.cam.scale);
      else if (d.moving) {
        const dx = p.x - d.moving.start.x, dy = p.y - d.moving.start.y;
        d.shapes = clone(d.moving.before);
        for (const i of d.sel) moveShape(d.shapes[i], dx, dy);
        d.moving.moved = d.moving.moved || Math.hypot(dx, dy) * S.cam.scale > 2;
      } else if (d.box) {
        d.box.b = p;
        const bx = { x: Math.min(d.box.a.x, p.x), y: Math.min(d.box.a.y, p.y), width: Math.abs(p.x - d.box.a.x), height: Math.abs(p.y - d.box.a.y) };
        d.sel = new Set(d.shapes.map((s, i) => [s, i]).filter(([s]) => meets(shapeBox(s), bx)).map(([, i]) => i));
      } else return;
      render();
    });
    const endPointer = (e) => {
      const d = S.draw;
      pointers.delete(e.pointerId);
      if (pointers.size < 2) pinch = null;
      if (!d) return;
      if (d.panning) {
        d.panning = null;
        return;
      }
      if (d.live) {
        const s = d.live;
        d.live = null;
        const drew = s.kind === "pen" || Math.hypot(s.b.x - s.a.x, s.b.y - s.a.y) * S.cam.scale >= 3;
        if (drew) {
          pushDraw();
          d.shapes.push(s);
          S.lastColor = s.color;
        }
      } else if (d.erasing) {
        if (d.erasing.hit) {
          d.stack.push(d.erasing.before);
          d.changes++;
        }
        d.erasing = null;
      } else if (d.moving) {
        if (d.moving.moved) {
          d.stack.push(d.moving.before);
          d.changes++;
        }
        d.moving = null;
      } else if (d.box) d.box = null;
      renderDrawBar();
      render();
    };
    capture.addEventListener("pointerup", endPointer);
    capture.addEventListener("pointercancel", endPointer);
    function erase(p, tol) {
      const d = S.draw;
      const keep = d.shapes.filter((s) => !hitShape(s, p, tol));
      if (keep.length !== d.shapes.length) {
        d.shapes = keep;
        d.erasing.hit = true;
        render();
      }
    }
    // A text shape: typed in place, Enter or a click elsewhere commits it.
    function openLabel(p) {
      const input = el(`<input class="kp-label-input" aria-label="Text" value="">`);
      input.dataset.bx = String(p.x);
      input.dataset.by = String(p.y);
      input.style.color = S.draw.color;
      board.append(input);
      placeLabelInput();
      input.focus({ preventScroll: true });
      input.onkeydown = (e) => {
        e.stopPropagation();
        if (e.key === "Enter") commitLabel();
        if (e.key === "Escape") commitLabel(true);
      };
    }
    function placeLabelInput() {
      const input = $(".kp-label-input", board);
      if (!input) return;
      const s = toScreen({ x: +input.dataset.bx, y: +input.dataset.by });
      input.style.left = `${s.x}px`;
      input.style.top = `${s.y}px`;
      input.style.font = labelFont(TEXT_SIZE * S.cam.scale);
    }
    function commitLabel(drop = false) {
      const input = $(".kp-label-input", board);
      if (!input) return;
      input.remove();
      const t = input.value.trim();
      if (drop || !t || !S.draw) return;
      pushDraw();
      S.draw.shapes.push(label(+input.dataset.bx, +input.dataset.by, t, S.draw.color));
      renderDrawBar();
      render();
    }
    // The palette: the colours used last (kept per browser), a wider grid, a custom #rrggbb.
    const RECENT_KEY = "coddy-mockup-606-recent-colours";
    const recent = () => {
      try {
        return JSON.parse(localStorage.getItem(RECENT_KEY) || "null") || ["#2dd4bf", "#bf5af2"];
      } catch {
        return ["#2dd4bf", "#bf5af2"];
      }
    };
    const remember = (c) => {
      const list = [c, ...recent().filter((x) => x !== c)].slice(0, 9);
      try {
        localStorage.setItem(RECENT_KEY, JSON.stringify(list));
      } catch {
        /* storage off: the list lives for the page */
      }
    };
    const GRID_COLOURS = [
      ["#ff3b30", "#ff9500", "#ffcc00", "#34c759", "#2dd4bf", "#0a84ff", "#bf5af2", "#ffffff", "#000000"],
      ["#ff8a80", "#ffc078", "#ffe680", "#8fe3a5", "#8af0e0", "#80bfff", "#dca8ff", "#d1d5db", "#6b7280"],
      ["#b3261e", "#b36200", "#b38f00", "#1f7a3a", "#0f8a7a", "#0059b3", "#7e3ab3", "#9ca3af", "#374151"],
    ];
    function openPalette() {
      closeMenus();
      const sw = (c) => `<button type="button" class="markup-swatch${S.draw.color === c ? " is-active" : ""}" style="background: ${c};" aria-label="${c}" title="${c}" data-kp-pick="${c}"></button>`;
      const rec = recent();
      const p = el(`<div class="mode-menu kp-palette${PHONE ? " kp-sheet" : ""}" role="dialog" aria-label="Colours">
        <h4>Used last</h4>${rec.length ? `<div class="kp-palette-row">${rec.map(sw).join("")}</div>` : '<p class="kp-palette-empty">None yet</p>'}
        <h4>Colours</h4><div class="kp-palette-grid">${GRID_COLOURS.flat().map(sw).join("")}</div>
        <div class="kp-palette-custom"><input type="color" aria-label="Custom colour" value="${/^#[0-9a-f]{6}$/i.test(S.draw.color) ? S.draw.color : "#2dd4bf"}"><input type="text" aria-label="#rrggbb" value="${esc(S.draw.color)}" maxlength="7" spellcheck="false"><button type="button">Use</button></div></div>`);
      board.append(p);
      if (!PHONE) {
        const b = $(".kp-palette-swatch", board).getBoundingClientRect();
        const r = board.getBoundingClientRect();
        p.style.left = `${Math.min(b.left - r.left - 110, board.clientWidth - p.offsetWidth - 8)}px`;
        p.style.top = `${b.top - r.top - p.offsetHeight - 12}px`;
      }
      p.addEventListener("pointerdown", (e) => e.stopPropagation());
      const use = (c) => {
        if (!/^#[0-9a-f]{6}$/i.test(c)) return toast("A colour is #rrggbb, matched whole; anything else is 400 at Done.");
        remember(c.toLowerCase());
        setColor(c.toLowerCase());
        p.remove();
      };
      p.addEventListener("click", (e) => {
        const b = e.target.closest("[data-kp-pick]");
        if (b) use(b.dataset.kpPick);
      });
      const [colorIn, textIn] = $$("input", p);
      colorIn.oninput = () => (textIn.value = colorIn.value);
      $(".kp-palette-custom button", p).onclick = () => use(textIn.value.trim());
      textIn.onkeydown = (e) => {
        e.stopPropagation();
        if (e.key === "Enter") use(textIn.value.trim());
      };
      cfg.onPalette?.(p, api);
    }
    api.openPalette = openPalette;

    // ---------- the prompt bar: picks, sending, a busy turn ----------
    const SEND_BTN = FRAGS.sendButton;
    const STOP_BTN = FRAGS.stopButton;
    const PEN_GLYPH = svgIcon('<path d="M16.5 3.5l4 4L8 20H4v-4L16.5 3.5z"/>', 13);
    function renderBar() {
      const picks = S.picks.length
        ? `<div class="canvas-picks" aria-label="Picked elements">${S.picks
            .map(
              (p, i) =>
                `<span class="canvas-pick" data-testid="canvas-pick"${p.kind === "sketch" ? ` title="canvas/sketches/${esc(p.name)}"` : ""}><span class="canvas-pick-name">${p.kind === "sketch" ? `<span class="kp-pick-glyph">${PEN_GLYPH}</span>` : ""}${esc(p.name)}</span>${
                  p.note ? `<span class="canvas-pick-note">${esc(p.note)}</span>` : ""
                }<button type="button" class="canvas-pick-remove" aria-label="Remove this element" data-kp-unpick="${i}">×</button></span>`,
            )
            .join("")}</div>`
        : "";
      const old = $(".canvas-bar-field", barHost);
      const text = old ? old.value : "";
      barHost.innerHTML = `<div class="canvas-bar" data-testid="canvas-bar">${picks}<div class="canvas-bar-row"><button type="button" class="canvas-bar-chat" data-testid="canvas-chat" title="Back to the conversation">Chat</button><textarea class="canvas-bar-field" data-testid="canvas-bar-field" rows="1" placeholder="${
        S.busy ? "The agent is working; a message waits for it" : "Tell the agent what to change"
      }" aria-label="Tell the agent what to change" enterkeyhint="send" style="height: 34px;"></textarea>${S.busy ? STOP_BTN : SEND_BTN}</div></div>`;
      const f = $(".canvas-bar-field", barHost);
      f.value = text;
      const send = $(".canvas-bar-send", barHost);
      const sync = () => {
        if (!S.busy) send.disabled = !(f.value.trim() || S.picks.length);
      };
      sync();
      f.oninput = sync;
      f.onkeydown = (e) => {
        if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
          e.preventDefault();
          if (!S.busy) sendBar();
        }
      };
      send.onclick = () => (S.busy ? cfg.onStop?.(api) : sendBar());
      $$("[data-kp-unpick]", barHost).forEach((b) => (b.onclick = () => (S.picks.splice(+b.dataset.kpUnpick, 1), renderBar())));
      $(".canvas-bar-chat", barHost).onclick = () => toast("Chat closes the Files window and goes back to the conversation, as today.");
    }
    function sendBar() {
      const f = $(".canvas-bar-field", barHost);
      const text = f.value.trim();
      if (!text && !S.picks.length) return;
      const picks = S.picks;
      S.picks = [];
      f.value = "";
      if (cfg.onSend) return cfg.onSend({ text, picks }, api);
      renderBar();
      toast(picks.some((p) => p.kind === "sketch") ? "The sketch goes with the prompt: slides 10 and 11 play the agent's answer." : "Sent to the chat, as the prompt bar does today.");
    }
    api.sendBar = sendBar;
    api.setBusy = (on) => {
      S.busy = on;
      renderBar();
    };
    api.ask = (sketchId) => {
      const n = S.nodes.find((x) => x.id === sketchId);
      if (!n) return;
      S.picks = [{ kind: "sketch", id: n.id, name: n.file.split("/").pop() }];
      renderBar();
      $(".canvas-bar-field", barHost).focus({ preventScroll: true });
    };
    // The question the turn waits for, in the canvas's prompts (the real card).
    api.question = ({ text, options }) =>
      new Promise((resolve) => {
        const name = `qp_mock_${Date.now()}`;
        prompts.innerHTML = `<p class="canvas-prompts-title">The agent is waiting for your answer</p><section class="question-prompt-frame" data-test="question_prompt_section"><div class="question-prompt-card"><div class="question-prompt-head"><div class="question-prompt-head-left"><span class="question-prompt-icon" aria-hidden="true"></span><h3 class="question-prompt-title">Questions</h3></div></div><div class="question-prompt-body"><div><div class="question-prompt-qline"><p class="question-prompt-qtext">${esc(text)}</p></div><ul class="question-prompt-rows" aria-label="Options 1">${options
          .map(
            (o, i) =>
              `<li class="question-prompt-li"><label class="question-prompt-row"><input class="sr-only" type="radio" name="${name}" value="${i}"><span class="question-prompt-bubble">${String.fromCharCode(65 + i)}</span><span class="question-prompt-row-text">${esc(o.label)}<span class="muted"> - ${esc(o.description)}</span></span></label></li>`,
          )
          .join("")}<li class="question-prompt-li"><label class="question-prompt-row question-prompt-row--other"><input class="sr-only" type="radio" name="${name}" value="other"><span class="question-prompt-bubble">${String.fromCharCode(65 + options.length)}</span><input class="question-prompt-other-input" autocomplete="off" spellcheck="false" placeholder="Other…" aria-label="Other, type your answer" type="text" value=""></label></li></ul></div></div><div class="question-prompt-foot"><button type="button" class="question-prompt-skip">Skip<span class="question-prompt-kbd">Esc</span></button><button type="button" class="question-prompt-continue" disabled>Continue<span class="question-prompt-continue-ic" aria-hidden="true">↵</span></button></div></div></section>`;
        prompts.hidden = false;
        let pick = null;
        const cont = $(".question-prompt-continue", prompts);
        const other = $(".question-prompt-other-input", prompts);
        const mark = (row) => {
          $$(".question-prompt-row", prompts).forEach((r) => r.classList.toggle("question-prompt-row--active", r === row));
        };
        $$(".question-prompt-row", prompts).forEach((row) =>
          row.addEventListener("click", () => {
            const v = $("input[type=radio]", row).value;
            pick = v === "other" ? "other" : +v;
            mark(row);
            cont.disabled = pick === "other" ? !other.value.trim() : false;
          }),
        );
        other.oninput = () => {
          pick = "other";
          mark(other.closest(".question-prompt-row"));
          cont.disabled = !other.value.trim();
        };
        const done = (v) => {
          prompts.hidden = true;
          prompts.innerHTML = "";
          resolve(v);
        };
        cont.onclick = () => done(pick === "other" ? { other: other.value.trim() } : { index: pick });
        $(".question-prompt-skip", prompts).onclick = () => done(null);
        cfg.onQuestion?.(api);
      });
    api.choose = (i) => {
      const row = $$(".question-prompt-row", prompts)[i];
      row?.click();
      $(".question-prompt-continue", prompts)?.click();
    };
    api.notice = (html, undoText) => {
      if (!html) {
        notice.hidden = true;
        return;
      }
      notice.innerHTML = `<p>${html}</p>${undoText ? `<button type="button">Undo <span class="kp-kbd">Ctrl Z</span></button>` : ""}`;
      notice.hidden = false;
      const b = $("button", notice);
      if (b) b.onclick = () => (undo(), (notice.hidden = true));
    };

    renderBar();
    render();
    // A slide that set its own camera keeps it.
    requestAnimationFrame(() => S.camSet || fit(cfg.fitIds));
    ACTIVE = api;
    return api;
  }

  // ---------- the window around the board ----------

  function shell(boardFile) {
    const root = document.getElementById("root");
    const chrome = (PHONE ? FRAGS.root390 : FRAGS.root1280).split("canvas/shop.canvas").join(boardFile).split("shop.canvas").join(boardFile.split("/").pop());
    root.innerHTML = chrome.replace("<!--PANE-->", '<div class="canvas-pane" data-testid="canvas-view"></div>');
    return $(".canvas-pane");
  }

  // ---------- the pages ----------

  const T = (id, x, y, w, h, text, extra = {}) => ({ id, type: "text", x, y, w, h, text, ...extra });
  const E = (id, from, fromSide, to, toSide, lbl) => ({ id, from, fromSide, to, toSide, ...(lbl ? { label: lbl } : {}) });
  const diagram = () => [
    T("order", 0, 0, 160, 60, "Order", { color: "4" }),
    T("paid", 0, 140, 160, 60, "Paid?", { color: "2" }),
    T("ship", 320, 140, 160, 60, "Ship"),
    T("remind", 0, 300, 160, 60, "Remind", { color: "3" }),
  ];
  const diagramEdges = () => [E("e1", "order", "bottom", "paid", "top"), E("e2", "paid", "right", "ship", "left", "yes"), E("e3", "paid", "bottom", "remind", "top", "no"), E("e4", "remind", "right", "ship", "bottom")];
  const marks = (color = "#ff3b30") => [
    ring(40, 214, 122, 262, color),
    arrow(126, 238, 330, 250, color),
    label(338, 236, "Refund", color),
    handLine(236, 300, 272, 336, color, 31),
    handLine(272, 300, 236, 336, color, 32),
    label(232, 344, "drop", color, 16),
  ];
  const sketchNode = (id, file, shapes, over = []) => {
    const boxes = shapes.map(shapeBox);
    const x = Math.floor(Math.min(...boxes.map((b) => b.x)) - STROKE), y = Math.floor(Math.min(...boxes.map((b) => b.y)) - STROKE);
    const w = Math.ceil(Math.max(...boxes.map((b) => b.x + b.width)) + STROKE) - x, h = Math.ceil(Math.max(...boxes.map((b) => b.y + b.height)) + STROKE) - y;
    return { id, type: "sketch", file, x, y, w, h, shapes, over, ...(over.length ? { border: "invisible" } : {}) };
  };

  const at = (id) => `[data-node-id="${id}"]`;
  const PAGES = {
    // ----- #570, Stage 1: an Advanced Canvas board drawn as the plugin draws it -----
    "01-styles"() {
      const b = createBoard(shell("canvas/flow.canvas"), { path: "canvas/flow.canvas" });
      b.fit();
      setNotes([
        { at: at("start"), text: "#570, Stage 1: the eight shapes of styleAttributes.shape, drawn as the plugin draws them", side: "right" },
        { at: at("z2"), text: "zIndex: ranked as the plugin ranks on open, inside its layer; today, file order", side: "above" },
        { at: at("research"), text: "collapsed: drawn as its bar at the group's place; members and their edges hidden. Click it to look inside, writing nothing", side: "below" },
        { at: at("again"), text: "border: dashed; dotted and invisible too", side: "below" },
        { at: '.canvas-edge-label[data-edge-id="f4"]', text: "path dotted, arrow blunt; long and short dashes and the other arrows on the other edges", side: "below" },
        { at: at("orders"), text: "database: its cap stays inside its box", side: "left" },
        { at: at("release"), text: "background with backgroundStyle repeat, read as bytes; the star is an SVG with border invisible", side: "below" },
        { at: '[data-testid="canvas-mode-draw"]', text: "Every slide has the same board: Draw (#606), the menus, search, undo", side: "below" },
      ]);
      const actions = () => [
        { label: "Today's drawing", run: () => (b.setToday(!b.S.today), toast(b.S.today ? "As Coddy draws this file today: every node a rectangle, every edge solid, file order, no background, the group open." : "As the plugin draws it: the proposal.")) },
        { label: "Look into Research", run: () => b.peek("research") },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // ----- #570, Stage 2: selection and the menu -----
    "02-select"() {
      const b = createBoard(shell("canvas/shop.canvas"), { path: "canvas/shop.canvas" });
      b.fit();
      b.select(["checkout", "pay"]);
      b.nodeMenu("pay");
      setNotes([{ at: at("cart"), text: "#570, Stage 2: a click selects, Shift adds; the edges of the selection are highlighted", side: "above" }]);
      const actions = () => [
        { label: "Node menu", run: () => b.nodeMenu("pay") },
        { label: "Select connected edges", run: () => b.selectEdges("pay", "all") },
        { label: "Zoom to selection", run: () => b.zoomToSelection() },
        { label: "Copy link", run: () => b.copyLink("pay") },
        {
          label: "canvas_show card",
          run: () => {
            b.S.lastFrame = "page";
            b.select(["page"]);
            b.fitNode("page");
            toastHtml(`The <strong>canvas_show</strong> card in the chat set <code class="cv-req">#/s/${SESSION}/files?path=canvas/shop.canvas&amp;node=page</code> and moved its sequence number: the board fits the frame, and a second click on the card fits it again.`, 6000);
          },
        },
        { label: "Zoom out (unloads pages)", run: () => (b.zoomBy(0.45), toast("A frame drawn narrower than 320 px is unloaded once the zoom settles, never navigated, and reported hidden: \"zoom\"; it loads again above 384 (Decision 8).", 5000)) },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // ----- #570, Stage 2: search and Focus -----
    "03-search"() {
      const b = createBoard(shell("canvas/shop.canvas"), { path: "canvas/shop.canvas" });
      b.fit();
      b.search("check");
      b.setFocus(true);
      setNotes([
        { at: ".cv-search", text: `#570, Stage 2: ${MOD}+F searches what the board read: cards, labels, edges, frame titles, links, notes, folded members`, side: "right" },
        { at: ".canvas-node.is-selected, .canvas-frame.is-selected, .canvas-group.is-selected", text: "A result is selected and fitted; Focus dims the rest", side: "below" },
      ]);
      const actions = () => [
        { label: "Next result", run: () => b.moveHit(1) },
        { label: "Find a folded member", run: () => b.search("fraud checks") },
        { label: "Find the cut card", run: () => b.search("changelog") },
        { label: "Focus on or off", run: () => b.setFocus(!b.S.focus) },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // ----- #570, Stage 3: organise, with undo -----
    "05-organise"() {
      const b = createBoard(shell("canvas/shop.canvas"), { path: "canvas/shop.canvas" });
      b.fit();
      b.nodeMenu("flow");
      setNotes([{ at: at("research"), text: "Folded in the file: a click on the bar shows its members to you only", side: "above" }]);
      const actions = () => [
        { label: "Group menu", run: () => b.nodeMenu("flow") },
        { label: "Select Cart and Receipt", run: () => (b.select(["cart", "receipt"]), toast("Two nodes selected: right click one of them for Swap, Flip, Group the selection, Encapsulate.")) },
        { label: `Undo (${MOD}+Z)`, run: () => b.undo() },
        { label: "Read-only view", run: () => b.toggleReadOnly() },
        { label: "Another window edits the file", run: () => b.armConflict() },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // ----- #570, Stage 4: styles, colour and the start slide -----
    "06-style"() {
      const b = createBoard(shell("canvas/flow.canvas"), { path: "canvas/flow.canvas" });
      b.fit();
      b.select(["paid"]);
      const openShape = () => {
        const m = b.nodeMenu("paid");
        $$(".cv-menu-item", m)
          .find((r) => r.textContent.includes("Shape"))
          ?.click();
        setNotes([
          { at: ".cv-submenu", text: "#570, Stage 4: Shape, Border, Align text and Colour set styleAttributes and color; PATCH …/canvas/nodes merges each attribute", side: "above", free: true },
          { at: '.canvas-edge-label[data-edge-id="f6"]', text: "Right click an edge: Path, Arrow, Colour, Flip edge", side: "left" },
          { at: '[data-testid="canvas-mode-draw"]', text: "A node's shape comes from this menu; Draw (#606) draws free shapes on the board, here as everywhere", side: "below" },
        ]);
      };
      openShape();
      const actions = () => [
        { label: "Shape menu", run: openShape },
        { label: "Edge menu", run: () => b.edgeMenu("f6") },
        { label: `Undo (${MOD}+Z)`, run: () => b.undo() },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // ----- #570, Stage 4: present in place -----
    "13-present"() {
      const b = createBoard(shell("canvas/talk.canvas"), {
        path: "canvas/talk.canvas",
        onSlide: (id) =>
          setNotes([
            { at: ".cv-present", text: "#570, Stage 4: from metadata.startNode, walking as the plugin walks; ←/→, PageUp/PageDown and a click move", side: "above" },
            { at: `[data-node-id="${id}"] .canvas-group-label`, text: "Each slide fits its node; pan and zoom are off; walking writes nothing", side: "right" },
          ]),
      });
      b.fit();
      b.startPresentation();
      const actions = () => [
        { label: "Restart the walk", run: () => (b.endPresentation(), (b.S.meta.startNode = "s1"), b.select([]), b.startPresentation()) },
        {
          label: "Start at the selection",
          run: () => {
            b.endPresentation();
            delete b.S.meta.startNode;
            b.select(["s3"]);
            b.startPresentation();
            toastHtml("Here the board has no <code>metadata.startNode</code>: the walk starts at the selected slide, which is Coddy's addition. With nothing selected, a note says there is no start slide.", 6000);
          },
        },
        { label: "Full screen", run: () => (b.S.pres || b.startPresentation(), b.setFullscreen(true)) },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    "14-present-fullscreen"() {
      const b = createBoard(shell("canvas/talk.canvas"), {
        path: "canvas/talk.canvas",
        onSlide: () =>
          setNotes([
            { at: ".cv-present", text: "#570, Stage 4: the canvas pane in full screen, the same full screen as Draw's (#606); nothing moves in the DOM, so pages keep running. Esc leaves full screen first, then the presentation", side: "above" },
            { at: ".canvas-bar", text: "The prompt bar stays: ask the agent mid-talk", side: "above", dy: -50 },
          ]),
      });
      b.fit();
      b.startPresentation();
      b.next();
      b.next();
      b.setFullscreen(true);
      const actions = () => [
        { label: "Exit full screen", run: () => b.setFullscreen(false) },
        { label: "Full screen", run: () => (b.S.pres || b.startPresentation(), b.setFullscreen(true)) },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // ----- #570, Stage 4: export -----
    "15-export"() {
      const b = createBoard(shell("canvas/shop.canvas"), {
        path: "canvas/shop.canvas",
        onExport: () =>
          setNotes([
            { at: ".cv-export", text: "#570, Stage 4: SVG or PNG of the board or the selection, downloaded by the browser; nothing written, nothing in undo", side: "left" },
            { at: ".cv-export-size", text: "Frames as placeholders; pictures, sketches and diagrams as embedded PNG", side: "right" },
          ]),
      });
      b.fit();
      b.select(["cart", "checkout", "page"]);
      b.exportDialog();
      const actions = () => [{ label: "Open Export", run: () => b.exportDialog() }];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // ----- #570, Stage 5: nodes in notes -----
    "16-notes"() {
      const b = createBoard(shell("canvas/plan.canvas"), { path: "canvas/plan.canvas" });
      b.fit();
      setNotes([
        { at: ".cv-embed .cv-mini", text: "#570, Stage 5: ![[talk.canvas#s2]] shows that group in place, drawn small, no frames running", side: "below" },
        { at: '.cv-node-link[data-node="pay"]', text: "[[shop.canvas#pay]] opens that board fitted on the node; a missing node opens it fitted, with a note", side: "below" },
        { at: ".canvas-node-note .cv-frame-placeholder", text: "A frame embedded in a note: a placeholder with a link to its board", side: "right" },
      ]);
      const actions = () => [{ label: "Back to plan.canvas", run: () => b.switchBoard("canvas/plan.canvas") }];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // ----- #570 on a phone: the menu as a sheet, search by the zoom, presenting -----
    "17-phone"() {
      const b = createBoard(shell("canvas/shop.canvas"), { path: "canvas/shop.canvas" });
      b.fitNode("flow");
      setNotes([
        { at: ".cv-search-btn", text: "On touch, Search sits by the zoom", side: "below" },
        { at: at("checkout"), text: "#570, Stage 2 on a phone: a long press opens the node's menu as a sheet", side: "below" },
      ]);
      const actions = () => [
        { label: "Long press Checkout", run: () => (b.select(["checkout"]), b.nodeMenu("checkout")) },
        { label: "Search", run: () => b.search("check") },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    "18-phone-present"() {
      const b = createBoard(shell("canvas/talk.canvas"), {
        path: "canvas/talk.canvas",
        onSlide: () => setNotes([{ at: ".cv-present", text: noFs ? "Safari on iPhone: no full-screen button; a tap goes forward" : "#570, Stage 4 on a phone: the slide fitted, the controls along the bottom; a tap goes forward", side: "above" }]),
      });
      let noFs = false;
      b.fit();
      b.startPresentation();
      const restart = () => (b.setFullscreen(false), b.endPresentation(), b.startPresentation());
      const actions = () => [
        { label: "Restart the walk", run: restart },
        {
          label: "As on an iPhone",
          run: (e) => {
            noFs = !noFs;
            e.currentTarget.textContent = noFs ? "As on Android" : "As on an iPhone";
            b.setNoFullscreen(noFs);
            restart();
            toast(noFs ? "Safari on iPhone cannot put an element in full screen, so the controls show no Full screen button." : "On Android, Full screen puts the canvas pane in full screen: the board, the controls and the prompt bar.");
          },
        },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // Stage 1: create and edit nodes and edges.
    "04-create-edit"() {
      const pane = shell("canvas/shop.canvas");
      const b = createBoard(pane, {
        board: "shop",
        edit: true,
        conflictCard: "shipping",
        nodes: [
          T("brief", 0, 0, 260, 140, "**Brief**\nA shop for the workshop: a sign-in page first."),
          T("shipping", 0, 220, 260, 140, "## Shipping\nFree over **50 €**,\nnext day in town."),
          T("cart", 380, 220, 260, 140, "**Cart**\nAdd, remove, totals.", { color: "6" }),
          T("payment", 380, 440, 260, 140, "**Payment**\nCard or invoice."),
          T("notes", 760, 0, 260, 140, "**Release notes**\nEvery change since 1.0, one line each: the board read the first 20000 bytes.", { truncated: true }),
        ],
        edges: [E("e1", "shipping", "right", "cart", "left", "1"), E("e2", "cart", "bottom", "payment", "top")],
      });
      const first = () =>
        setNotes([
          { at: '[data-node-id="shipping"]', text: "Double click a card: its Markdown source, saved on blur; Esc cancels", side: "left" },
          { at: '[data-node-id="cart"]', text: "Hover a node: drag a side handle to another node for an edge", side: "right" },
          { at: ".canvas-edge-label", text: "Double click an edge to edit its label", side: "above", free: true },
          { at: '[data-node-id="notes"]', text: "A card cut at 20000 bytes is not edited in place: Open in Files", side: "below" },
          { at: ".canvas-mode", text: "Right click the empty board: New card, Add file…, Add link…", side: "below", dx: 40 },
        ]);
      first();
      const actions = () => [
        { label: "Edit a card", run: () => b.startEdit("shipping") },
        { label: "Another writer changes it", run: () => b.conflict("## Shipping\nFree over **60 €**,\nnext day in town.") },
        { label: "Board menu", run: () => b.boardMenu({ x: 560, y: 120 }) },
        { label: "Delete the cart", run: () => (b.select(["cart"]), b.deleteSel()) },
        { label: "Undo", run: () => b.undo() },
      ];
      mockBar(actions(), () => (PAGES["04-create-edit"].restart(), actions()));
    },
    // Stage 2: Draw.
    "07-draw"() {
      const pane = shell("canvas/shop.canvas");
      const b = createBoard(pane, {
        board: "shop",
        edit: true,
        draw: true,
        sketchNo: 1,
        nodes: [T("brief", 520, 0, 260, 140, "**Brief**\nA sign-in page for the shop.")],
        fitIds: null,
        onDraw: (on) =>
          on
            ? setNotes([
                { at: ".kp-draw-bar .markup-tools", text: "The markup window's tools on the board, plus Move (V) and the eraser (E)", side: "above" },
                { at: ".kp-palette-swatch, .kp-current-swatch", text: "The last swatch opens the palette: used last, a wider grid, a custom #rrggbb", side: "above", dx: -120 },
                { at: '[data-kp-draw="cancel"]', text: "Cancel over unsaved changes asks Keep or Discard", side: "above" },
                { at: '[data-kp-draw="done"]', text: "Done: the server writes sketches/<board>-<n>.svg and its node", side: "above", dx: -160 },
              ])
            : setNotes([
                { at: ".kp-sketch", text: "The sketch: strokes only, no card. Double click a stroke to edit it", side: "right" },
                { at: '[data-testid="canvas-mode-draw"]', text: "Draw again", side: "below" },
              ]),
      });
      b.startDraw({ shapes: signInSketch(0, 0), changes: 8, color: INK() });
      b.S.draw.stack = [];
      for (let i = 0; i < 8; i++) b.S.draw.stack.push(b.S.draw.shapes.slice(0, i));
      b.render();
      b.fit();
      const actions = () => [
        { label: "Move tool", run: () => b.setTool("move") },
        { label: "Eraser", run: () => b.setTool("eraser") },
        { label: "Open the palette", run: () => b.openPalette() },
        { label: "Cancel", run: () => b.leaveDraw() },
        { label: "Done", run: () => b.drawDone() },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // Stage 2: drawing over a diagram already on the board.
    "08-draw-over"() {
      const pane = shell("canvas/flow.canvas");
      const b = createBoard(pane, {
        board: "flow",
        edit: true,
        draw: true,
        nodes: [...diagram(), T("brief", 620, 0, 260, 140, "**Review**\nFriday: what the order flow misses.")],
        edges: diagramEdges(),
        onDraw: (on) =>
          on
            ? setNotes([
                { at: ".kp-draw-bar .markup-tools", text: "Draw works over cards, groups, pictures and frames: each locked under the strokes", side: "above" },
                { at: '[data-kp-draw="done"]', text: "Done sends the ids of the nodes the strokes cover", side: "above", dx: -160 },
              ])
            : null,
        onDone: (id, api) => {
          const n = api.nodeById(id);
          api.select([id]);
          setNotes([
            { at: ".kp-sketch-name", text: `The sketch lies over ${n.over.length} nodes, after them in nodes, with border: invisible`, side: "above", free: true },
            { at: '[data-node-id="ship"]', text: "Beside a stroke the card under it still takes the click", side: "right" },
          ]);
        },
      });
      setNotes([{ at: '[data-testid="canvas-mode-draw"]', text: "Draw over the diagram: Draw the review marks in the mockup bar, or draw yourself", side: "below" }]);
      const actions = () => [
        { label: "Draw the review marks", run: () => (b.S.draw ? (b.S.draw.shapes.push(...marks()), (b.S.draw.changes += 6), b.render()) : b.startDraw({ shapes: marks(), changes: 6, color: "#ff3b30" })) },
        { label: "Done", run: () => b.drawDone() },
        { label: "Undo", run: () => (b.S.draw ? b.drawUndo() : b.undo()) },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // Stage 2: full screen in Draw, over a live page.
    "09-draw-fullscreen"() {
      const pane = shell("canvas/shop.canvas");
      const b = createBoard(pane, {
        board: "shop",
        edit: true,
        draw: true,
        fullscreen: true,
        sketchNo: 2,
        nodes: [
          sketchNode("s1", "canvas/sketches/shop-1.svg", signInSketch(0, 40)),
          { id: "page", type: "frame", page: "shop", file: "site/index.html", title: "Shop", x: 400, y: 40, w: 640, h: 400 },
        ],
        onFullscreen: (on) =>
          setNotes(
            on
              ? [
                  { at: ".kp-fs-btn", text: "The canvas pane in full screen: board, toolbar and prompt bar; Escape leaves full screen first", side: "below", dx: -200 },
                  { at: ".canvas-frame", text: "Nothing moves in the DOM: the page under the marks keeps running", side: "above", free: true },
                ]
              : [{ at: ".kp-fs-btn", text: "Full screen next to the zoom controls, or F", side: "below", dx: -100 }],
          ),
      });
      b.startDraw({
        shapes: [ring(440, 112, 720, 168, "#ff3b30"), arrow(860, 40, 724, 128, "#ff3b30"), label(868, 18, "bigger, accent colour", "#ff3b30")],
        changes: 3,
        color: "#ff3b30",
      });
      b.S.draw.stack = [[], [], []];
      b.render();
      b.setFullscreen(true);
      const actions = () => [
        { label: "Full screen on or off", run: () => b.setFullscreen(!b.S.fullscreen) },
        { label: "Interact with the page", run: () => b.leaveDraw() },
        { label: "Done", run: () => b.drawDone() },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // Stage 2 on a phone.
    "19-draw-phone"() {
      const pane = shell("canvas/shop.canvas");
      const b = createBoard(pane, {
        board: "shop",
        edit: true,
        draw: true,
        sketchNo: 1,
        nodes: [T("brief", 0, 360, 300, 120, "**Brief**\nA sign-in page for the shop.")],
        onPalette: (p) => setNotes([{ at: p, text: "On a phone the palette opens as a sheet", side: "above", free: true }]),
      });
      b.startDraw({ shapes: signInSketch(0, 0), changes: 8, color: INK() });
      b.S.draw.stack = Array.from({ length: 8 }, (_, i) => b.S.draw.shapes.slice(0, i));
      b.render();
      b.fit();
      setNotes([
        { at: ".kp-current-swatch", text: "The current colour: a tap opens the palette as a sheet", side: "above", dx: -120 },
        { at: ".kp-draw-capture", text: "One finger draws; two pan and zoom", side: "inside", free: true },
      ]);
      const actions = () => [
        { label: "Open the palette", run: () => b.openPalette() },
        { label: "Done", run: () => b.drawDone() },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // Stage 3: Ask Coddy about a sketch.
    "10-ask"() {
      const pane = shell("canvas/shop.canvas");
      const dark = () => document.documentElement.dataset.theme !== "light";
      const sk1 = sketchNode("s1", "canvas/sketches/shop-1.svg", signInSketch(0, 0));
      const sk2 = sketchNode("s2", "canvas/sketches/shop-2.svg", flowSketch(0, 460));
      const b = createBoard(pane, {
        board: "shop",
        edit: true,
        draw: true,
        sketchNo: 3,
        nodes: [T("brief", -320, 0, 260, 140, "**Brief**\nA sign-in page and the order flow for the shop."), sk1, sk2],
        nodeMenu: (n, api) =>
          n.type === "sketch"
            ? [
                { label: "Ask Coddy", run: () => api.ask(n.id) },
                { label: "Edit sketch", key: "double click", run: () => api.startDraw({ editing: n.id }) },
                "-",
                { label: "Delete", key: "Del", run: () => (api.select([n.id]), api.deleteSel()) },
              ]
            : null,
        onSend: (msg, api) => turn(msg, api),
      });
      const kindOf = (id) => (id === "s1" ? "signin" : "flow");
      const QUESTIONS = {
        signin: {
          text: "I read a sign-in form: a title, email and password fields and a Sign in button. What should it become?",
          options: [
            { key: "page", label: "A live page", description: "fits a screen best" },
            { key: "mermaid", label: "A Mermaid diagram", description: "one card" },
            { key: "nodes", label: "A diagram of nodes", description: "boxes you can move" },
            { key: "picture", label: "A tidy picture", description: "an SVG file" },
          ],
        },
        flow: {
          text: "I read a flow: an order, a Paid? check, and Ship on yes. What should it become?",
          options: [
            { key: "mermaid", label: "A Mermaid diagram", description: "fits a flow best" },
            { key: "nodes", label: "A diagram of nodes", description: "boxes you can move" },
            { key: "page", label: "A live page", description: "a screen of it" },
            { key: "picture", label: "A tidy picture", description: "an SVG file" },
          ],
        },
      };
      const named = (t) => (/\bpage\b/i.test(t) ? "page" : /mermaid/i.test(t) ? "mermaid" : /diagram|nodes/i.test(t) ? "nodes" : /picture|svg/i.test(t) ? "picture" : null);
      async function turn({ text, picks }, api) {
        const sk = picks.find((p) => p.kind === "sketch");
        if (!sk) {
          api.renderBar();
          return toast("A turn without a sketch goes to the chat as today.");
        }
        api.setBusy(true);
        await sleep(900);
        const kind = kindOf(sk.id);
        let result = named(text);
        if (result) toast(`“${text}” names a result, so the agent skips the question.`);
        else {
          setNotes([
            { at: ".question-prompt-card", text: "The agent asks what to make, the best fit first; the free answer is the person's own", side: "above", free: true },
            { at: ".canvas-pick", text: "The sketch went as a chip: its path, bounds, and a PNG for a model that reads images", side: "above", free: true },
          ]);
          const q = QUESTIONS[kind];
          const a = await api.question(q);
          if (!a) {
            api.setBusy(false);
            setNotes([]);
            return toast("Skipped: the turn goes on in the chat without a result on the board.");
          }
          result = a.other ? named(a.other) || q.options[0].key : q.options[a.index].key;
        }
        await sleep(700);
        place(api, sk.id, kind, result);
        api.setBusy(false);
      }
      function place(api, sketchId, kind, result) {
        const s = api.nodeById(sketchId);
        const gx = s.x + s.w + 120, gy = s.y;
        const gid = newId("g");
        const add = [];
        let gw = 560, gh = 440, labelText = "";
        if (result === "page") {
          labelText = kind === "signin" ? "Sign-in page" : "Order status page";
          add.push({ id: newId("p"), type: "frame", page: kind === "signin" ? "login" : "status", file: kind === "signin" ? "site/login.html" : "site/order.html", title: kind === "signin" ? "Sign in" : "Order 1042", x: gx + 20, y: gy + 54, w: 520, h: 366 });
        } else if (result === "mermaid") {
          labelText = kind === "signin" ? "Sign-in flow" : "Order flow";
          gw = 340;
          gh = kind === "signin" ? 470 : 410;
          add.push({ id: newId("c"), type: "text", mermaid: kind === "signin" ? "mermaid-signin" : "mermaid", text: "```mermaid …```", x: gx + 20, y: gy + 30, w: 300, h: gh - 50 });
        } else if (result === "nodes") {
          labelText = kind === "signin" ? "Sign-in form" : "Order flow";
          if (kind === "signin") {
            const ids = ["Sign in to Acme", "Email", "Password", "Sign in"].map((t, i) => ({ id: newId("c"), type: "text", text: i === 0 ? `**${t}**` : t, x: gx + 20, y: gy + 30 + i * 100, w: 220, h: 60, ...(i === 3 ? { color: "6" } : {}) }));
            add.push(...ids);
            gw = 260;
            gh = 430;
            api.S.edges.push(...ids.slice(1).map((n, i) => ({ id: newId("e"), from: ids[i].id, fromSide: "bottom", to: n.id, toSide: "top" })));
          } else {
            const o = { id: newId("c"), type: "text", text: "Order", color: "4", x: gx + 20, y: gy + 30, w: 160, h: 60 };
            const p = { id: newId("c"), type: "text", text: "Paid?", color: "2", x: gx + 20, y: gy + 170, w: 160, h: 60 };
            const sh = { id: newId("c"), type: "text", text: "Ship", x: gx + 300, y: gy + 170, w: 160, h: 60 };
            add.push(o, p, sh);
            gw = 480;
            gh = 260;
            api.S.edges.push({ id: newId("e"), from: o.id, fromSide: "bottom", to: p.id, toSide: "top" }, { id: newId("e"), from: p.id, fromSide: "right", to: sh.id, toSide: "left", label: "yes" });
          }
        } else {
          labelText = kind === "signin" ? "Sign-in picture" : "Order flow picture";
          const pic = tidyPicture(kind === "signin" ? "signin" : "flow", dark());
          add.push({ id: newId("f"), type: "file", file: `canvas/pictures/${kind === "signin" ? "sign-in" : "order-flow"}.svg`, picture: svgDataUrl(pic.w, pic.h, pic.svg), x: gx + 20, y: gy + 30, w: pic.w, h: pic.h });
          gw = pic.w + 40;
          gh = pic.h + 50;
        }
        const pending = api.S.edges.splice(api.S.edges.length - (result === "nodes" ? (kind === "signin" ? 3 : 2) : 0));
        api.write(`canvas_edit: a group “${labelText}” right of the sketch, with an edge from it, in one write; the sketch is not changed`, () => {
          api.S.nodes.push({ id: gid, type: "group", label: labelText, x: gx, y: gy, w: gw, h: gh }, ...add);
          api.S.edges.push(...pending, { id: newId("e"), from: sketchId, fromSide: "right", to: gid, toSide: "left" });
        });
        api.fit();
        setNotes([
          { at: `[data-node-id="${gid}"] .canvas-group-label`, text: "The result goes next to the sketch, in a group placed by canvas_edit near, with an edge from it", side: "above", free: true },
          { at: `[data-node-id="${sketchId}"]`, text: "The sketch stays as it was: the record of what was asked", side: "below", free: true },
        ]);
      }
      setNotes([
        { at: '[data-node-id="s1"]', text: "Right click a sketch: Ask Coddy puts it in the prompt bar as a chip", side: "right", free: true },
        { at: ".canvas-bar", text: "Words that name a result (make it a page) skip the question", side: "above" },
      ]);
      const actions = () => [
        { label: "Ask about the sign-in sketch", run: () => (b.ask("s1"), ($(".canvas-bar-field").value = "the login form for the shop"), b.renderBar()) },
        { label: "Ask about the flow sketch", run: () => (b.ask("s2"), ($(".canvas-bar-field").value = "the order flow"), b.renderBar()) },
        { label: "Send", run: () => b.sendBar() },
        { label: "Pick the first answer", run: () => b.choose(0) },
        { label: "Undo", run: () => b.undo() },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // Stage 3: marks over a diagram; changing what they mark comes first.
    "11-marks"() {
      const pane = shell("canvas/flow.canvas");
      let conflict = false;
      const sk = sketchNode("s1", "canvas/sketches/flow-1.svg", marks(), ["paid", "ship", "remind", "order"]);
      const b = createBoard(pane, {
        board: "flow",
        edit: true,
        draw: true,
        sketchNo: 2,
        nodes: [...diagram(), sk],
        edges: diagramEdges(),
        nodeMenu: (n, api) =>
          n.type === "sketch"
            ? [
                { label: "Ask Coddy", run: () => api.ask(n.id) },
                { label: "Edit sketch", key: "double click", run: () => api.startDraw({ editing: n.id }) },
                "-",
                { label: "Delete", key: "Del", run: () => (api.select([n.id]), api.deleteSel()) },
              ]
            : null,
        onSend: (msg, api) => turn(msg, api),
      });
      const Q = {
        text: "Your marks on the diagram: add a Refund step on the no branch of Paid?, and drop the edge Remind → Ship. What should I do?",
        options: [
          { key: "change", label: "Change what it marks", description: "edit these 4 nodes" },
          { key: "nodes", label: "A new diagram of nodes", description: "beside it" },
          { key: "mermaid", label: "A Mermaid diagram", description: "one card" },
          { key: "picture", label: "A tidy picture", description: "an SVG file" },
        ],
      };
      async function turn({ picks }, api) {
        if (!picks.some((p) => p.kind === "sketch")) {
          api.renderBar();
          return toast("A turn without a sketch goes to the chat as today.");
        }
        api.setBusy(true);
        await sleep(900);
        setNotes([{ at: ".question-prompt-card", text: "For a sketch over nodes, changing what it marks comes first", side: "above", free: true }]);
        const a = await api.question(Q);
        if (!a) {
          api.setBusy(false);
          return toast("Skipped: nothing is written.");
        }
        const key = a.other ? "change" : Q.options[a.index].key;
        await sleep(700);
        api.setBusy(false);
        const S = api.S;
        if (key === "change") {
          if (conflict) {
            setNotes([]);
            return api.notice("<b>The agent:</b> Paid? changed in the file since the sketch was read, so the change came back as a <code>409</code> and nothing was written. Ask again to apply the marks to the new text.");
          }
          api.write("canvas_edit: Refund added on the no branch and the edge Remind → Ship removed, in one write, one undo step; the sketch stays", () => {
            S.nodes.push({ id: "refund", type: "text", text: "Refund", color: "1", x: 320, y: 300, w: 160, h: 60 });
            S.edges = S.edges.filter((e) => e.id !== "e4");
            S.edges.push({ id: "e5", from: "paid", fromSide: "bottom", to: "refund", toSide: "left", label: "no" });
          });
          api.notice("<b>Changed what it marks:</b> <code>Refund</code> added on the no branch of <code>Paid?</code>, the edge <code>Remind → Ship</code> removed: one write, one undo step. The sketch stays as the record; Delete removes it.", true);
          return setNotes([{ at: '[data-node-id="refund"]', text: "Changed in place under the write contract; one undo takes it back", side: "right" }]);
        }
        const s = api.nodeById("s1");
        const gx = 700, gy = -20, gid = newId("g");
        const nodes = [];
        const edges = [];
        let gw = 520, gh = 460, labelText = "Order flow";
        if (key === "nodes") {
          const at = (id, x, y, t, color) => nodes.push({ id: `${id}-${gid}`, type: "text", text: t, color, x: gx + x, y: gy + y, w: 160, h: 60 });
          at("o", 20, 40, "Order", "4");
          at("p", 20, 180, "Paid?", "2");
          at("s", 320, 180, "Ship");
          at("r", 20, 340, "Refund", "1");
          edges.push(E(newId("e"), `o-${gid}`, "bottom", `p-${gid}`, "top"), E(newId("e"), `p-${gid}`, "right", `s-${gid}`, "left", "yes"), E(newId("e"), `p-${gid}`, "bottom", `r-${gid}`, "top", "no"));
        } else if (key === "mermaid") {
          gw = 380;
          gh = 420;
          nodes.push({ id: newId("c"), type: "text", mermaid: "mermaid-refund", text: "```mermaid …```", x: gx + 20, y: gy + 30, w: 340, h: 370 });
        } else {
          const pic = tidyPicture("refund", document.documentElement.dataset.theme !== "light");
          nodes.push({ id: newId("f"), type: "file", file: "canvas/pictures/order-flow.svg", picture: svgDataUrl(pic.w, pic.h, pic.svg), x: gx + 20, y: gy + 30, w: pic.w, h: pic.h });
          gw = pic.w + 40;
          gh = pic.h + 50;
          labelText = "Order flow picture";
        }
        api.write(`canvas_edit: a group “${labelText}” right of the sketch with an edge from it; the diagram under the marks is not changed`, () => {
          S.nodes.push({ id: gid, type: "group", label: labelText, x: gx, y: gy, w: gw, h: gh }, ...nodes);
          S.edges.push(...edges, { id: newId("e"), from: s.id, fromSide: "right", to: gid, toSide: "left" });
        });
        api.fit();
      }
      setNotes([
        { at: '[data-node-id="s1"]', text: "A sketch over 4 nodes: right click a stroke, Ask Coddy", side: "right", free: true },
        { at: '[data-node-id="ship"]', text: "The PNG draws the diagram under the marks; the prompt names the nodes and edges", side: "right" },
      ]);
      const actions = () => [
        { label: "Ask Coddy on the marks", run: () => (b.ask("s1"), ($(".canvas-bar-field").value = "notes from the Friday review"), b.renderBar()) },
        { label: "Send", run: () => b.sendBar() },
        { label: "Change what it marks", run: () => b.choose(0) },
        { label: "Someone edits Paid? first", run: () => ((conflict = true), toast("Paid? now says “Paid in full?” in the file: the agent's change will come back as a 409.")) },
        { label: "Undo", run: () => b.undo() },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
    // Stage 4: links onto the board.
    "12-pull-links"() {
      const pane = shell("canvas/shop.canvas");
      const note = (id, file, x, y) => ({ id, type: "file", file, note: DATA.notes[file] || "", x, y, w: 400, h: 300 });
      const b = createBoard(pane, {
        board: "shop",
        nodes: [note("brief", "notes/brief.md", 0, 0), note("roadmap", "notes/roadmap.md", 560, 1360)],
        edges: [],
        onPull: () =>
          setNotes([
            { at: ".kp-notice", text: "One write and one undo step; the skipped links are named", side: "above" },
            { at: '[data-node-id="roadmap"]', text: "A note already on the board gets an edge, not a second node", side: "left" },
          ]),
      });
      b.fit();
      setNotes([{ at: '[data-node-id="brief"]', text: "Right click a note: Pull outgoing links, Pull backlinks, in the same menu as on every slide", side: "right" }]);
      const pricing = () => b.S.nodes.find((m) => m.file === "notes/pricing.md");
      const actions = () => [
        { label: "Pull outgoing links", run: () => b.pull("brief", "out") },
        { label: "Pull backlinks of pricing.md", run: () => (pricing() ? b.pull(pricing().id, "in") : toast("Pull the outgoing links first: pricing.md is not on the board yet.")) },
        { label: "Undo", run: () => (b.undo(), b.notice(null)) },
      ];
      mockBar(actions(), () => (location.reload(), actions()));
    },
  };
  PAGES["04-create-edit"].restart = () => location.reload();

  // ---------- start ----------
  setTheme(new URLSearchParams(location.search).get("theme") === "light" ? "light" : "dark");
  (PAGES[PAGE] || (() => {}))();
  // Until the page has opened on its step nothing waits for a timer.
  ACTIVE?.boot();
})();
