/* Kiosk mockups (issue #675, round 2): live prototypes for a Coddy canvas.
 *
 * Each slide page sets <body data-app data-step data-slide> and loads this
 * file. The screens are built from markup taken from the running web UI
 * (FRAGS) and its icons (ICONS) over Coddy's own stylesheet (coddy.css), so
 * they look as the product does; only the kiosk's additions are new. Nothing
 * here talks to a server: answers, timers and sessions are scripted. */
(() => {
  "use strict";

  const FRAGS = {"railChat":"<aside class=\"rail-column \" aria-label=\"Nav\"><div class=\"rail-pill \"><div class=\"rail-tip-host rail-brand-tip-host\"><a href=\"#/\" class=\"rail-brand\" aria-label=\"Coddy agent home\" data-testid=\"nav-home\"><span class=\"rail-brand-text\"><span class=\"rail-brand-title\">Coddy</span><span class=\"rail-brand-sub\">agent</span></span></a><span class=\"rail-tip\" role=\"tooltip\">New Chat</span></div><div class=\"rail-middle\"><div class=\"rail-tip-host\"><a href=\"#/history\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"History\" aria-pressed=\"false\" data-testid=\"nav-history\"><span class=\"rail-nav-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" aria-hidden=\"true\"><path d=\"M4 19.5A2.5 2.5 0 016.5 17H20\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M8 7h8M8 11h6\" stroke-linecap=\"round\"></path></svg></span></a><span class=\"rail-tip\" role=\"tooltip\">History</span></div><div class=\"rail-spacer rail-spacer-between\" aria-hidden=\"true\"></div><div class=\"rail-tip-host\"><a href=\"#/docs\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"Docs\" aria-pressed=\"false\" data-testid=\"nav-docs\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"9\"></circle><path d=\"M9.6 9.3a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.6\"></path><path d=\"M12 17.2h.01\"></path></svg></a><span class=\"rail-tip\" role=\"tooltip\">Docs</span></div><div class=\"rail-tip-host\"><a href=\"#/settings\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"Settings\" aria-pressed=\"false\" data-testid=\"nav-settings\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z\"></path><path d=\"M15 12a3 3 0 11-6 0 3 3 0 016 0z\"></path></svg></a><span class=\"rail-tip\" role=\"tooltip\">Settings</span></div><div class=\"rail-tip-host rail-env-host\"><button type=\"button\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow rail-env-btn \" aria-label=\"Environment: demo-host\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-testid=\"nav-environment\" data-env=\"local\" data-state=\"local\"><span class=\"rail-env-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><rect x=\"4.5\" y=\"5\" width=\"15\" height=\"10.5\" rx=\"1.5\"></rect><path d=\"M2.5 19h19\"></path></svg><span class=\"env-status rail-env-status\" aria-hidden=\"true\" data-state=\"local\"></span></span></button><span class=\"rail-tip\" role=\"tooltip\">Environment: demo-host</span></div></div></div></aside>","composerDocked":"<footer class=\"composer-wrap composer-wrap-docked\"><label class=\"sr-only\" for=\"composer\">Message</label><div class=\"composer-card\"><div class=\"composer-field-wrap\"><button type=\"button\" class=\"composer-enhance-btn\" aria-label=\"Improve prompt\" title=\"Improve prompt\" data-testid=\"composer-enhance-btn\" disabled=\"\"><svg class=\"composer-enhance-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\" width=\"12\" height=\"12\" aria-hidden=\"true\"><path d=\"M9.5 1l.7 1.8L12 3.5l-1.8.7L9.5 6l-.7-1.8L7 3.5l1.8-.7L9.5 1zM3.2 5.6l.5 1.2 1.2.5-1.2.5-.5 1.2-.5-1.2L1.5 7.3l1.2-.5.5-1.2zM8.9 6.6a1 1 0 011.5 0l.9.9a1 1 0 010 1.5l-5.3 5.3a1 1 0 01-1.5 0l-.9-.9a1 1 0 010-1.5l5.3-5.3zm.8 1.5l-4.6 4.6.5.5 4.6-4.6-.5-.5z\"></path></svg></button><div class=\"composer-stack\"><textarea id=\"composer\" rows=\"2\" enterkeyhint=\"send\" placeholder=\"Add a follow-up\" autocomplete=\"off\" style=\"height: 76px;\"></textarea></div></div><div class=\"composer-bar\"><div class=\"composer-tabs\" aria-label=\"Composer options\"><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-ask\" aria-label=\"Mode\" title=\"Mode\" aria-haspopup=\"menu\" aria-expanded=\"false\">Ask</button></div><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-llm\" aria-label=\"Model\" title=\"YAML backend (metadata.model)\" aria-haspopup=\"menu\" aria-expanded=\"false\">gemma-4-31b</button></div><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-permission perm-ask\" aria-label=\"Permissions\" title=\"When tools ask for approval in this session (new sessions start in: Ask first)\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-testid=\"composer-permission\">Ask first</button></div></div><div class=\"composer-bar-actions\"><div class=\"composer-context-tip-host\" tabindex=\"0\" aria-label=\"Context usage\" aria-expanded=\"false\" data-testid=\"composer-context-ring-host\"><div class=\"context-ring\" role=\"img\" aria-hidden=\"true\"><svg viewBox=\"0 0 28 28\" width=\"30\" height=\"30\" aria-hidden=\"true\"><circle class=\"context-ring-inner\" cx=\"14\" cy=\"14\" r=\"7\"></circle><circle class=\"context-ring-fg\" cx=\"14\" cy=\"14\" r=\"12\" stroke-dasharray=\"75.39822368615503\" stroke-dashoffset=\"71.26251330724492\"></circle></svg></div><span class=\"rail-tip composer-context-tip\" role=\"tooltip\">5.5% context used\nInput 1200\nOutput 80\nTotal 1280\nMax context 128000</span></div><button type=\"button\" class=\"composer-icon composer-run-icon composer-send-play composer-run-icon--play\" id=\"btn-send\" aria-label=\"Send\" disabled=\"\"><span class=\"composer-send-glyph\" aria-hidden=\"true\"><svg viewBox=\"0 0 12 12\" fill=\"currentColor\" width=\"17\" height=\"17\"><path d=\"M2 0L11 6L2 12Z\"></path></svg></span></button></div></div></div></footer>","scrollBottom":"<button type=\"button\" class=\"chat-scroll-bottom\" data-testid=\"chat-scroll-bottom\" data-visible=\"false\" aria-label=\"Scroll to the latest message\" aria-hidden=\"true\" inert=\"\" tabindex=\"-1\" title=\"Scroll to the latest message\"><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><path d=\"M8 3v9m0 0 4-4m-4 4-4-4\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path></svg></button>","userRow":"<div class=\"msg-user-stack\" data-row-id=\"u_1\"><div class=\"msg msg-user\"><div class=\"msg-user-body\" data-testid=\"user-message-body\"><span><span><span>Which plan includes single sign-on?</span></span></span></div></div><div class=\"msg-user-foot\"><button type=\"button\" class=\"msg-copy-icon-btn\" aria-label=\"Copy message\" data-testid=\"user-message-copy\" title=\"Copy message\"><svg class=\"msg-copy-icon-btn__glyph\" width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><path fill=\"currentColor\" d=\"M4 2.5A1.5 1.5 0 015.5 1h6A1.5 1.5 0 0113 2.5v8a1.5 1.5 0 01-1.5 1.5H10v.5A1.5 1.5 0 018.5 14h-6A1.5 1.5 0 011 12.5v-8A1.5 1.5 0 012.5 3H4v-.5zm1 0V3h4A1.5 1.5 0 0110.5 4.5v7H11v-8h-6v-.5zM2.5 4a.5.5 0 00-.5.5v8a.5.5 0 00.5.5h6a.5.5 0 00.5-.5v-8a.5.5 0 00-.5-.5h-6z\"></path></svg></button><button type=\"button\" class=\"msg-copy-icon-btn msg-user-edit\" aria-label=\"Edit message\" title=\"Edit message\" data-testid=\"user-message-edit\"><svg class=\"msg-copy-icon-btn__glyph\" width=\"16\" height=\"16\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M3 12a9 9 0 1 0 9-9c-2.5 0-4.9 1-6.7 2.8L3 8\"></path><path d=\"M3 3v5h5\"></path></svg></button><time class=\"msg-user-time\" datetime=\"2026-10-29T13:51:24Z\" title=\"Thu, Oct 29, 2026, 02:51:24 PM GMT+01:00\">2:51 PM</time></div></div>","toolRow":"<div class=\"thinking-row coddy-tool-call-row\" data-kind=\"read\" data-status=\"completed\" data-row-id=\"tc_call_read_1\"><details class=\"thinking-details coddy-tool-details\" data-testid=\"tool-details-call_read_1\"><summary class=\"thinking-summary\" aria-label=\"Tool summary\"><span class=\"thinking-left\"><span class=\"coddy-chevron thinking-chevron\" aria-hidden=\"true\"><svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg></span><span class=\"thinking-head\"><span class=\"thinking-label\">reading a file</span><span class=\"thinking-trail\"><span class=\"tool-summary-target\" data-testid=\"tool-summary-target\" title=\"docs/pricing.md\">docs/pricing.md</span><span class=\"thinking-dur\" aria-hidden=\"true\">5ms</span></span></span></span></summary><div class=\"thinking-body coddy-tool-call-body coddy-tool-call-body--connected-result\" aria-label=\"Tool call details\"><div class=\"permission-preview\"><div class=\"permission-preview-bar permission-preview-bar--standalone\"><button type=\"button\" class=\"permission-preview-location files-open-path\" title=\"docs/pricing.md\">docs/pricing.md</button></div></div><div class=\"tool-call-result-card\" aria-label=\"Tool result\"><div data-testid=\"tool-result-viewport\" class=\"tool-call-result-content\"><pre class=\"tool-result-pre\"># Pricing\n\n| Plan | Single sign-on | Price |\n|---|---|---|\n| Team | no | 8 euros a user a month |\n| Business | SAML and OIDC | 13 euros a user a month |\n| Enterprise | SAML, OIDC and SCIM | on request |\n</pre></div></div></div></details></div>","assistantRow":"<div class=\"msg-assistant-stack\" data-row-id=\"as_1\"><div class=\"msg msg-assistant\" title=\"Thu, Oct 29, 2026, 02:51:24 PM GMT+01:00\"><div class=\"md\"><p><strong>Business</strong> and <strong>Enterprise</strong> include single sign-on, with SAML and OIDC.</p>\n<ul>\n<li><strong>Business</strong> adds it for 5 euros a user a month.</li>\n<li><strong>Enterprise</strong> includes it, together with SCIM provisioning.</li>\n</ul>\n<p>Want me to compare the two plans side by side?</p></div></div></div>","liveRow":"<div class=\"msg-assistant-stack typing-dots-slot\" data-testid=\"live-line-slot\" aria-hidden=\"true\"><div class=\"typing-dots\"><span class=\"typing-dots-dot\"></span><span class=\"typing-dots-dot\"></span><span class=\"typing-dots-dot\"></span><span class=\"typing-dots-status\"><span class=\"typing-dots-turn\"><span class=\"typing-dots-turn-item\">&nbsp;</span></span><span class=\"typing-dots-status-text\"><span class=\"typing-dots-status-verb\">&nbsp;</span></span></span></div></div>","chatHeader":"<header class=\"chat-header\"><div class=\"chat-title\" id=\"chat-title\"><button type=\"button\" class=\"chat-title-btn is-editable\" aria-label=\"Chat title\">Which plan includes single sign-on?</button></div><div class=\"chat-views\" role=\"toolbar\" aria-label=\"Views of this chat\" data-testid=\"chat-views\"><span class=\"chat-view-tip-host\"><button type=\"button\" class=\"chat-view-btn chat-view-btn--icon\" data-testid=\"chat-views-files\" aria-pressed=\"false\" aria-label=\"Workspace files (Ctrl+Shift+F)\"><span class=\"chat-view-face\"><svg class=\"chat-view-icon\" width=\"18\" height=\"18\" viewBox=\"0 0 16 16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.3\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M1.75 4.25c0-.83.67-1.5 1.5-1.5h3l1.5 1.75h5c.83 0 1.5.67 1.5 1.5v6.25c0 .83-.67 1.5-1.5 1.5h-9.5c-.83 0-1.5-.67-1.5-1.5z\"></path></svg></span></button><span class=\"chat-view-tip\" role=\"tooltip\">Workspace files (Ctrl+Shift+F)</span></span><span class=\"chat-view-tip-host\"><button type=\"button\" class=\"chat-view-btn chat-view-btn--tasks\" data-testid=\"chat-views-tasks\" aria-pressed=\"false\" aria-label=\"Background tasks: none yet\"><span class=\"chat-view-face\"><span class=\"bgtask-dot bgtask-dot--muted\" aria-hidden=\"true\"></span><span class=\"chat-view-label\" aria-hidden=\"true\">Tasks</span></span></button><span class=\"chat-view-tip\" role=\"tooltip\">Background tasks: none yet</span></span></div></header>","railPhone":"<aside class=\"rail-column \" aria-label=\"Nav\"><div class=\"rail-pill \"><div class=\"rail-tip-host rail-brand-tip-host\"><a href=\"#/\" class=\"rail-brand\" aria-label=\"Coddy agent home\" data-testid=\"nav-home\"><span class=\"rail-brand-text\"><span class=\"rail-brand-title\">Coddy</span><span class=\"rail-brand-sub\">agent</span></span></a><span class=\"rail-tip\" role=\"tooltip\">New Chat</span></div><div class=\"rail-middle\"><div class=\"rail-tip-host\"><a href=\"#/history\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"History\" aria-pressed=\"false\" data-testid=\"nav-history\"><span class=\"rail-nav-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" aria-hidden=\"true\"><path d=\"M4 19.5A2.5 2.5 0 016.5 17H20\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M8 7h8M8 11h6\" stroke-linecap=\"round\"></path></svg></span></a><span class=\"rail-tip\" role=\"tooltip\">History</span></div><div class=\"rail-spacer rail-spacer-between\" aria-hidden=\"true\"></div><div class=\"rail-tip-host\"><a href=\"#/docs\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"Docs\" aria-pressed=\"false\" data-testid=\"nav-docs\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"9\"></circle><path d=\"M9.6 9.3a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.6\"></path><path d=\"M12 17.2h.01\"></path></svg></a><span class=\"rail-tip\" role=\"tooltip\">Docs</span></div><div class=\"rail-tip-host\"><a href=\"#/settings\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"Settings\" aria-pressed=\"false\" data-testid=\"nav-settings\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z\"></path><path d=\"M15 12a3 3 0 11-6 0 3 3 0 016 0z\"></path></svg></a><span class=\"rail-tip\" role=\"tooltip\">Settings</span></div><div class=\"rail-tip-host rail-env-host\"><button type=\"button\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow rail-env-btn \" aria-label=\"Environment: demo-host\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-testid=\"nav-environment\" data-env=\"local\" data-state=\"local\"><span class=\"rail-env-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><rect x=\"4.5\" y=\"5\" width=\"15\" height=\"10.5\" rx=\"1.5\"></rect><path d=\"M2.5 19h19\"></path></svg><span class=\"env-status rail-env-status\" aria-hidden=\"true\" data-state=\"local\"></span></span></button><span class=\"rail-tip\" role=\"tooltip\">Environment: demo-host</span></div></div></div></aside>","railSettings":"<aside class=\"rail-column \" aria-label=\"Nav\"><div class=\"rail-pill \"><div class=\"rail-tip-host rail-brand-tip-host\"><a href=\"#/\" class=\"rail-brand\" aria-label=\"Coddy agent home\" data-testid=\"nav-home\"><span class=\"rail-brand-text\"><span class=\"rail-brand-title\">Coddy</span><span class=\"rail-brand-sub\">agent</span></span></a><span class=\"rail-tip\" role=\"tooltip\">New Chat</span></div><div class=\"rail-middle\"><div class=\"rail-tip-host\"><a href=\"#/history\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"History\" aria-pressed=\"false\" data-testid=\"nav-history\"><span class=\"rail-nav-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" aria-hidden=\"true\"><path d=\"M4 19.5A2.5 2.5 0 016.5 17H20\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M8 7h8M8 11h6\" stroke-linecap=\"round\"></path></svg></span></a><span class=\"rail-tip\" role=\"tooltip\">History</span></div><div class=\"rail-spacer rail-spacer-between\" aria-hidden=\"true\"></div><div class=\"rail-tip-host\"><a href=\"#/docs\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow \" aria-label=\"Docs\" aria-pressed=\"false\" data-testid=\"nav-docs\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><circle cx=\"12\" cy=\"12\" r=\"9\"></circle><path d=\"M9.6 9.3a2.5 2.5 0 0 1 4.8.9c0 1.7-2.4 2.2-2.4 3.6\"></path><path d=\"M12 17.2h.01\"></path></svg></a><span class=\"rail-tip\" role=\"tooltip\">Docs</span></div><div class=\"rail-tip-host\"><a href=\"#/settings\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow is-active\" aria-label=\"Settings\" aria-pressed=\"true\" data-testid=\"nav-settings\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z\"></path><path d=\"M15 12a3 3 0 11-6 0 3 3 0 016 0z\"></path></svg></a></div><div class=\"rail-tip-host rail-env-host\"><button type=\"button\" class=\"rail-hit rail-hit-icon rail-nav-hit rail-nav-hit-narrow rail-env-btn \" aria-label=\"Environment: demo-host\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-testid=\"nav-environment\" data-env=\"local\" data-state=\"local\"><span class=\"rail-env-icon\"><svg class=\"rail-svg rail-nav-hit-svg\" width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><rect x=\"4.5\" y=\"5\" width=\"15\" height=\"10.5\" rx=\"1.5\"></rect><path d=\"M2.5 19h19\"></path></svg><span class=\"env-status rail-env-status\" aria-hidden=\"true\" data-state=\"local\"></span></span></button><span class=\"rail-tip\" role=\"tooltip\">Environment: demo-host</span></div></div></div></aside>","settingsHeadList":"<div class=\"sessions-head\"><span>Settings</span><button type=\"button\" class=\"sessions-close\" aria-label=\"Close settings\" data-testid=\"settings-drawer-close\">×</button></div>","settingsNavWrap":"<div class=\"settings-nav-wrap\"><div class=\"settings-nav-search\"><div class=\"settings-search-box\"><input class=\"settings-search-input\" data-testid=\"settings-search\" role=\"combobox\" autocomplete=\"off\" aria-autocomplete=\"list\" aria-controls=\"_r_0_\" aria-expanded=\"false\" placeholder=\"Search settings\" aria-label=\"Search settings\" type=\"search\" value=\"\"><kbd class=\"settings-search-kbd\" aria-hidden=\"true\">/</kbd></div></div><button type=\"button\" class=\"settings-nav-arrow settings-nav-arrow-left\" aria-label=\"Scroll sections left\" data-testid=\"settings-nav-left\" disabled=\"\">‹</button><nav class=\"settings-nav\" aria-label=\"Settings sections\"><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-appearance\">Appearance</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-sessions_manager\">Sessions</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-status\">System</button><button type=\"button\" class=\"settings-nav-item is-active\" data-testid=\"settings-tab-providers\" aria-current=\"page\">LLM providers</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-models\">Logical models</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-toolsets\">Toolsets</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-agent\">ReAct loop</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-supervisor\">Session goal</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-compaction\">Context compaction</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-memory\">Memory</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-decisions\">Command safety (decisions)</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-tools\">Tools and permissions</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-mcp_servers\">MCP servers</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-skills\">Skills</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-subagents\">Subagents</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-hooks\">Hooks</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-scheduler\">Scheduler</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-gateways\">Gateways</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-logger\">Logger</button><button type=\"button\" class=\"settings-nav-item\" data-testid=\"settings-tab-system\">Prompts</button></nav><button type=\"button\" class=\"settings-nav-arrow settings-nav-arrow-right\" aria-label=\"Scroll sections right\" data-testid=\"settings-nav-right\" disabled=\"\">›</button></div>","settingsFooter":"<div class=\"scheduler-drawer-footer settings-footer-actions\"><span class=\"settings-save-status\" data-testid=\"settings-save-status\"></span><button type=\"button\" class=\"settings-btn settings-btn-icon\" data-testid=\"settings-reload\" title=\"Reload from server\" aria-label=\"Reload configuration from server\"><svg class=\"settings-footer-icon-svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><polyline points=\"23 4 23 10 17 10\"></polyline><polyline points=\"1 20 1 14 7 14\"></polyline><path d=\"M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15\"></path></svg></button><button type=\"button\" class=\"settings-btn settings-btn-primary settings-btn-icon\" data-testid=\"settings-save\" title=\"Save all sections\" aria-label=\"Save all configuration sections\"><svg class=\"settings-footer-icon-svg\" width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z\"></path><polyline points=\"17 21 17 13 7 13 7 21\"></polyline><polyline points=\"7 3 7 8 15 8\"></polyline></svg></button><span class=\"sr-only\" role=\"status\"></span></div>","settingsMaster":"<div class=\"settings-master\"><p class=\"settings-field-desc\">API credentials and transport selection for upstream LLM vendors.</p><ul class=\"settings-master-list\"><li class=\"settings-master-row\"><button type=\"button\" class=\"settings-master-item\" data-testid=\"settings-master-item-0\">neuraldeep</button><button type=\"button\" class=\"settings-btn settings-btn-icon settings-btn-danger\" aria-label=\"Remove neuraldeep\" title=\"Remove\"><svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M3 6h18\"></path><path d=\"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2\"></path><path d=\"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6\"></path><path d=\"M10 11v6M14 11v6\"></path></svg></button></li></ul><button type=\"button\" class=\"settings-btn settings-master-add\" data-testid=\"settings-master-add\">Add</button></div>","heroBehind":"<main class=\"main is-empty\"><div class=\"hero\" id=\"hero\"><h1 class=\"hero-title\"><span class=\"hero-title-muted\">What do you want to <span class=\"hero-title-accent\" data-testid=\"hero-title-accent\">ship</span>?</span></h1><div class=\"hero-composer\"><footer class=\"composer-wrap\"><label class=\"sr-only\" for=\"composer\">Message</label><div class=\"workspace-bar workspace-bar--pick\" role=\"group\" aria-label=\"Where this chat works\" data-testid=\"workspace-bar\"><div class=\"workspace-bar-picks\"><button type=\"button\" class=\"workspace-bar-item workspace-bar-repo workspace-bar-pick\" data-testid=\"composer-workspace-chip\" title=\"/srv/kiosk/reception\" aria-haspopup=\"menu\" aria-expanded=\"false\"><svg class=\"workspace-bar-icon\" viewBox=\"0 0 16 16\" width=\"14\" height=\"14\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.3\" aria-hidden=\"true\"><path d=\"M1.75 3.25h4.1l1.5 1.5h6.9c.28 0 .5.22.5.5v7.5c0 .28-.22.5-.5.5H1.75a.5.5 0 0 1-.5-.5v-9c0-.28.22-.5.5-.5Z\" stroke-linejoin=\"round\"></path></svg><span class=\"workspace-bar-text\">reception</span></button></div></div><div class=\"composer-card composer-card--joined\"><div class=\"composer-field-wrap\"><button type=\"button\" class=\"composer-enhance-btn\" aria-label=\"Improve prompt\" title=\"Improve prompt\" data-testid=\"composer-enhance-btn\" disabled=\"\"><svg class=\"composer-enhance-icon\" viewBox=\"0 0 16 16\" fill=\"currentColor\" width=\"12\" height=\"12\" aria-hidden=\"true\"><path d=\"M9.5 1l.7 1.8L12 3.5l-1.8.7L9.5 6l-.7-1.8L7 3.5l1.8-.7L9.5 1zM3.2 5.6l.5 1.2 1.2.5-1.2.5-.5 1.2-.5-1.2L1.5 7.3l1.2-.5.5-1.2zM8.9 6.6a1 1 0 011.5 0l.9.9a1 1 0 010 1.5l-5.3 5.3a1 1 0 01-1.5 0l-.9-.9a1 1 0 010-1.5l5.3-5.3zm.8 1.5l-4.6 4.6.5.5 4.6-4.6-.5-.5z\"></path></svg></button><div class=\"composer-stack\"><textarea id=\"composer\" rows=\"5\" enterkeyhint=\"send\" placeholder=\"Plan, Build, / for skills, @ for files\" autocomplete=\"off\" style=\"height: 132px;\"></textarea></div></div><div class=\"composer-bar\"><div class=\"composer-tabs\" aria-label=\"Composer options\"><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-agent\" aria-label=\"Mode\" title=\"Mode\" aria-haspopup=\"menu\" aria-expanded=\"false\">Agent</button></div><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-llm\" aria-label=\"Model\" title=\"YAML backend (metadata.model)\" aria-haspopup=\"menu\" aria-expanded=\"false\">gemma-4-31b</button></div><div class=\"mode\"><button type=\"button\" class=\"composer-tab mode-btn mode-permission perm-ask\" aria-label=\"Permissions\" title=\"When tools ask for approval in this session (new sessions start in: Ask first)\" aria-haspopup=\"menu\" aria-expanded=\"false\" data-testid=\"composer-permission\">Ask first</button></div></div><div class=\"composer-bar-actions\"><div class=\"composer-context-tip-host\" tabindex=\"0\" aria-label=\"Context usage\" aria-expanded=\"false\" data-testid=\"composer-context-ring-host\"><div class=\"context-ring\" role=\"img\" aria-hidden=\"true\"><svg viewBox=\"0 0 28 28\" width=\"30\" height=\"30\" aria-hidden=\"true\"><circle class=\"context-ring-inner\" cx=\"14\" cy=\"14\" r=\"7\"></circle></svg></div><span class=\"rail-tip composer-context-tip\" role=\"tooltip\">No context usage yet\nMax context 128000</span></div><button type=\"button\" class=\"composer-icon composer-run-icon composer-send-play composer-run-icon--play\" id=\"btn-send\" aria-label=\"Send\" disabled=\"\"><span class=\"composer-send-glyph\" aria-hidden=\"true\"><svg viewBox=\"0 0 12 12\" fill=\"currentColor\" width=\"17\" height=\"17\"><path d=\"M2 0L11 6L2 12Z\"></path></svg></span></button></div></div></div></footer></div><div class=\"hero-footer\"><a href=\"https://github.com/coddy-project/coddy-agent\" target=\"_blank\" rel=\"noopener\">GitHub</a><span class=\"hero-footer-sep\" aria-hidden=\"true\">|</span><a href=\"/docs/\" target=\"_blank\" rel=\"noopener\">API docs</a><span class=\"hero-footer-sep\" aria-hidden=\"true\">|</span><span class=\"hero-footer-version\">dev</span></div></div></main>","backdropOpen":"<div class=\"backdrop is-open\" aria-hidden=\"false\"></div>","settingsHeadDetail":"<div class=\"sessions-head\"><span class=\"settings-head-titlegroup\"><button type=\"button\" class=\"settings-head-back\" aria-label=\"Back to LLM providers\" title=\"Back to LLM providers\" data-testid=\"settings-head-back\"><svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M19 12H5\"></path><path d=\"M12 19l-7-7 7-7\"></path></svg></button><span class=\"settings-head-section\">Provider settings</span></span><button type=\"button\" class=\"sessions-close\" aria-label=\"Close settings\" data-testid=\"settings-drawer-close\">×</button></div>","formGroup":"<fieldset class=\"settings-fieldset settings-form-group\" data-testid=\"settings-group-provider\" data-settings-anchor=\"group:providers:provider\"><legend><span class=\"settings-legend-line\">Provider settings</span></legend><div class=\"settings-form-group-body\"><div class=\"settings-field\" data-settings-anchor=\"providers:name\"><div class=\"settings-row\"><span class=\"settings-label settings-label-with-hint\"><span class=\"settings-label-text\">Provider id</span><button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About Provider id\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span><input class=\"settings-input\" placeholder=\"my-provider\" pattern=\"^[a-zA-Z][a-zA-Z0-9_\\-]*$\" aria-label=\"Provider id\" type=\"text\" value=\"neuraldeep\"></div></div><div class=\"settings-field\" data-settings-anchor=\"providers:type\"><div class=\"settings-row\"><span class=\"settings-label settings-label-with-hint\"><span class=\"settings-label-text\">Provider type</span><button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About Provider type\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span><div class=\"settings-combobox\"><input class=\"settings-input settings-combobox-input\" role=\"combobox\" aria-expanded=\"false\" aria-autocomplete=\"list\" aria-label=\"Provider type\" type=\"text\" value=\"openai\"><button type=\"button\" class=\"settings-combobox-toggle\" tabindex=\"-1\" aria-label=\"Toggle options\"><span class=\"coddy-chevron coddy-chevron--down\" aria-hidden=\"true\"><svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg></span></button></div></div></div><div class=\"settings-field\" data-settings-anchor=\"providers:api_base\"><div class=\"settings-row\"><span class=\"settings-label settings-label-with-hint\"><span class=\"settings-label-text\">API base URL</span><button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About API base URL\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span><input class=\"settings-input\" placeholder=\"https://api.openai.com/v1\" aria-label=\"API base URL\" type=\"text\" value=\"http://127.0.0.1:19741/v1\"></div></div><div class=\"settings-field\" data-settings-anchor=\"providers:api_key\"><div class=\"settings-row\"><span class=\"settings-label settings-label-with-hint\"><span class=\"settings-label-text\">API key</span><button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About API key\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span><input class=\"settings-input\" placeholder=\"If empty, reads from ${NEURALDEEP_API_KEY} at run time, or set a literal key (YAML may use ${VAR} at load)\" aria-label=\"API key\" type=\"text\" value=\"stub\"></div></div></div></fieldset>","collapsible":"<fieldset class=\"settings-fieldset settings-fieldset--collapsible\" data-testid=\"settings-group-advanced\" data-settings-anchor=\"group:providers:advanced\"><legend><button type=\"button\" class=\"settings-fieldset-toggle\" aria-expanded=\"false\" aria-controls=\"_r_a_\" data-testid=\"settings-group-advanced-toggle\"><span class=\"coddy-chevron\" aria-hidden=\"true\"><svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg></span><span>Advanced settings</span></button></legend><div id=\"_r_a_\" class=\"settings-form-group-body\" hidden=\"\"><div class=\"settings-field\" data-settings-anchor=\"providers:api_key_command\"><div class=\"settings-row\"><span class=\"settings-label settings-label-with-hint\"><span class=\"settings-label-text\">API key command</span><button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About API key command\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span><input class=\"settings-input\" placeholder=\"pass show coddy/api-key\" aria-label=\"API key command\" type=\"text\" value=\"\"></div></div><div class=\"settings-field\" data-settings-anchor=\"providers:proxy\"><div class=\"settings-switch-field\"><button type=\"button\" id=\"_r_c_-switch\" role=\"switch\" aria-checked=\"true\" class=\"skill-switch\" aria-labelledby=\"_r_c_-label\" data-testid=\"proxy-setting-direct\"><span class=\"skill-switch-thumb\"></span></button><span class=\"settings-switch-field-label-cell\"><label id=\"_r_c_-label\" for=\"_r_c_-switch\" class=\"settings-switch-field-label\">Ignore system proxy</label><button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About Ignore system proxy\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span></div><div class=\"settings-row\"><span class=\"settings-label settings-label-with-hint\"><span class=\"settings-label-text\">Proxy URL</span><button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About Proxy URL\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span><input class=\"settings-input\" disabled=\"\" placeholder=\"Direct connection\" aria-label=\"Proxy URL\" data-testid=\"proxy-setting-url\" type=\"text\" value=\"\"></div></div><div class=\"settings-field\" data-settings-anchor=\"providers:timeout_ms\"><div class=\"settings-row\"><span class=\"settings-label settings-label-with-hint\"><span class=\"settings-label-text\">Request timeout ms</span><button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About Request timeout ms\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span><input class=\"settings-input\" aria-label=\"Request timeout ms\" type=\"number\" value=\"0\"></div></div></div></fieldset>","switchField":"<div class=\"settings-switch-field\"><button type=\"button\" id=\"_r_7_-switch\" role=\"switch\" aria-checked=\"false\" class=\"skill-switch\" aria-labelledby=\"_r_7_-label\"><span class=\"skill-switch-thumb\"></span></button><span class=\"settings-switch-field-label-cell\"><label id=\"_r_7_-label\" for=\"_r_7_-switch\" class=\"settings-switch-field-label\">Enabled</label><button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About Enabled\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span></div>","arrayFieldset":"<fieldset class=\"settings-fieldset\"><legend><span class=\"settings-legend-line\">Admins<button type=\"button\" class=\"field-hint\" data-testid=\"field-hint\" aria-label=\"About Admins\"><svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg></button></span></legend><ul class=\"settings-array\"></ul><button type=\"button\" class=\"settings-btn\">Add</button></fieldset>","sessionsTableWrap":"<div class=\"sessions-manager-tablewrap\"><table class=\"sessions-manager-table\"><thead><tr><th class=\"sessions-manager-col-pick\" scope=\"col\"><input aria-label=\"Select every listed conversation\" data-testid=\"sessions-manager-select-all\" type=\"checkbox\"></th><th scope=\"col\" aria-sort=\"none\"><button type=\"button\" class=\"sessions-manager-sort\" data-testid=\"sessions-manager-sort-title\" title=\"Sort by Conversation\"><span>Conversation</span></button></th><th scope=\"col\">Model</th><th class=\"sessions-manager-col-num\" scope=\"col\" aria-sort=\"none\"><button type=\"button\" class=\"sessions-manager-sort\" data-testid=\"sessions-manager-sort-messages\" title=\"Sort by Msgs\"><span>Msgs</span></button></th><th class=\"sessions-manager-col-num\" scope=\"col\" aria-sort=\"none\"><button type=\"button\" class=\"sessions-manager-sort\" data-testid=\"sessions-manager-sort-tokens\" title=\"Sort by Tokens\"><span>Tokens</span></button></th><th scope=\"col\" aria-sort=\"none\"><button type=\"button\" class=\"sessions-manager-sort\" data-testid=\"sessions-manager-sort-created\" title=\"Sort by Created\"><span>Created</span></button></th><th scope=\"col\" aria-sort=\"descending\"><button type=\"button\" class=\"sessions-manager-sort\" data-testid=\"sessions-manager-sort-updated\" title=\"Sort by Updated\"><span>Updated</span><span class=\"sessions-manager-sort-caret\" aria-hidden=\"true\">▼</span></button></th></tr></thead><tbody><tr data-testid=\"sessions-manager-row-sess_capturekiosk01\"><td class=\"sessions-manager-col-pick\"><input aria-label=\"Select Which plan includes single sign-on?\" data-testid=\"sessions-manager-pick-sess_capturekiosk01\" type=\"checkbox\"></td><td class=\"sessions-manager-col-title\"><span class=\"sessions-manager-title-line\"><span title=\"Which plan includes single sign-on?\">Which plan includes single sign-on?</span></span><span class=\"sessions-manager-sub\"><span class=\"sessions-manager-cwd\" title=\"/srv/kiosk/reception\">reception</span><button type=\"button\" class=\"sessions-manager-tag-add\" data-testid=\"sessions-manager-tag-add-sess_capturekiosk01\" aria-label=\"Add a tag\" title=\"Add a tag\" aria-haspopup=\"dialog\">+</button></span></td><td class=\"sessions-manager-col-model\"><span title=\"neuraldeep/gemma-4-31b\">neuraldeep/gemma-4-31b</span></td><td class=\"sessions-manager-col-num\">4</td><td class=\"sessions-manager-col-num\" title=\"1200 in, 80 out, 1280 total\">1.3k</td><td title=\"Oct 29, 2026, 2:51 PM\">10/29/26</td><td title=\"Oct 29, 2026, 2:51 PM\">10/29/26</td></tr></tbody></table></div>"};
  const ICONS = {"send":"<svg viewBox=\"0 0 12 12\" fill=\"currentColor\" width=\"17\" height=\"17\"><path d=\"M2 0L11 6L2 12Z\"></path></svg>","hint":"<svg width=\"14\" height=\"14\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"8\" cy=\"8\" r=\"6.5\" stroke=\"currentColor\" stroke-width=\"1.3\"></circle><path d=\"M8 7.2v4\" stroke=\"currentColor\" stroke-width=\"1.4\" stroke-linecap=\"round\"></path><circle cx=\"8\" cy=\"4.9\" r=\"0.85\" fill=\"currentColor\"></circle></svg>","chevron":"<svg viewBox=\"0 0 14 14\" width=\"14\" height=\"14\" fill=\"none\" focusable=\"false\"><polyline points=\"5.5,4 8.5,7 5.5,10\" stroke=\"currentColor\" stroke-width=\"1.6\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></polyline></svg>","back":"<svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.9\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M19 12H5\"></path><path d=\"M12 19l-7-7 7-7\"></path></svg>","trash":"<svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><path d=\"M3 6h18\"></path><path d=\"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2\"></path><path d=\"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6\"></path><path d=\"M10 11v6M14 11v6\"></path></svg>","copy":"<svg class=\"msg-copy-icon-btn__glyph\" width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\" aria-hidden=\"true\"><path fill=\"currentColor\" d=\"M4 2.5A1.5 1.5 0 015.5 1h6A1.5 1.5 0 0113 2.5v8a1.5 1.5 0 01-1.5 1.5H10v.5A1.5 1.5 0 018.5 14h-6A1.5 1.5 0 011 12.5v-8A1.5 1.5 0 012.5 3H4v-.5zm1 0V3h4A1.5 1.5 0 0110.5 4.5v7H11v-8h-6v-.5zM2.5 4a.5.5 0 00-.5.5v8a.5.5 0 00.5.5h6a.5.5 0 00.5-.5v-8a.5.5 0 00-.5-.5h-6z\"></path></svg>"};
  const svg = (inner, size = 16) =>
    `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${inner}</svg>`;
  Object.assign(ICONS, {
    clock: svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    logout: svg('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>'),
    play: svg('<path d="M7 4l12 8-12 8z"/>', 14),
    qr: svg('<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM21 14v.01M14 21h.01M17 21h4v-4"/>'),
    link: svg('<path d="M10 13a5 5 0 0 0 7.07 0l2.83-2.83a5 5 0 0 0-7.07-7.07L11.5 4.5"/><path d="M14 11a5 5 0 0 0-7.07 0L4.1 13.83a5 5 0 0 0 7.07 7.07L12.5 19.5"/>'),
    newlink: svg('<path d="M3 12a9 9 0 0 1 15.5-6.3L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15.5 6.3L3 16"/><path d="M3 21v-5h5"/>'),
    eye: svg('<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
    stop: svg('<rect x="6" y="6" width="12" height="12" rx="2"/>'),
    plane: svg('<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>', 22),
    info: svg('<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>', 22),
    alarm: svg('<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2"/><path d="M5 3L2 6M22 6l-3-3"/>', 22),
  });

  // ---------- small helpers ----------

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const esc = (s) =>
    String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  const el = (markup) => {
    const t = document.createElement("template");
    t.innerHTML = markup.trim();
    return t.content.firstElementChild;
  };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const clock = () => {
    const d = new Date();
    return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  };

  const body = document.body;
  const APP = body.dataset.app;
  const STEP = body.dataset.step;
  const SLIDE = body.dataset.slide || "";
  // Timers of the product, shown as they are; the mockup runs them faster.
  const SPEED = 6;

  // ---------- theme, notes and the mockup bar ----------

  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme === "light" ? "light" : "dark";
    const b = $(".mk-theme");
    if (b) b.textContent = theme === "light" ? "Dark theme" : "Light theme";
    placeNotes();
  }

  let notes = [];
  function setNotes(list) {
    notes = list;
    placeNotes();
  }
  function placeNotes() {
    let layer = $(".mk-notes");
    if (!layer) {
      layer = el('<div class="mk-notes" aria-hidden="true"></div>');
      body.append(layer);
    }
    layer.textContent = "";
    for (const n of notes) {
      const target = typeof n.at === "string" ? $(n.at) : n.at;
      if (!target || !target.isConnected) continue;
      const r = target.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) continue;
      const cx = Math.min(Math.max(r.left + Math.min(r.width / 2, 24), 0), innerWidth - 1);
      const cy = Math.min(Math.max(r.top + Math.min(r.height / 2, 12), 0), innerHeight - 1);
      if (r.bottom < 0 || r.top > innerHeight) continue;
      const hit = document.elementFromPoint(cx, cy);
      if (!hit || !(target.contains(hit) || hit.contains(target))) continue;
      const note = el(`<div class="mk-note">${esc(n.text)}</div>`);
      layer.append(note);
      const w = note.offsetWidth;
      const h = note.offsetHeight;
      let x = r.left;
      let y = r.bottom + 6;
      let side = n.side;
      if (side === "left" && r.left - w - 8 < 6) side = "below";
      if (side === "right" && r.right + 8 + w > innerWidth - 6) side = "below";
      if (side === "above") y = r.top - h - 6;
      if (side === "right") {
        x = r.right + 8;
        y = r.top + (r.height - h) / 2;
      }
      if (side === "left") {
        x = r.left - w - 8;
        y = r.top + (r.height - h) / 2;
      }
      if (n.side === "inside") {
        x = r.left + 8;
        y = r.top + 8;
      }
      x = Math.max(6, Math.min(x + (n.dx || 0), innerWidth - w - 6));
      y = Math.max(6, Math.min(y + (n.dy || 0), innerHeight - h - 6));
      note.style.left = `${x}px`;
      note.style.top = `${y}px`;
    }
  }
  addEventListener("resize", placeNotes);
  addEventListener("scroll", placeNotes, true);
  setInterval(placeNotes, 600);

  function mockBar(actions, restart) {
    const bar = el(`<div class="mk-bar" role="region" aria-label="Mockup controls" data-collapsed="true">
      <div class="mk-bar-head"><span class="mk-bar-tag">Mockup</span>
        <button type="button" class="mk-bar-fold" aria-label="Show or hide the mockup controls">▴</button></div>
      <div class="mk-bar-body">
        <span class="mk-bar-title">${esc(SLIDE)}</span>
        <div class="mk-bar-row">
          <button type="button" class="mk-btn mk-theme">Light theme</button>
          <button type="button" class="mk-btn mk-notes-btn" aria-pressed="true">Notes</button>
          <button type="button" class="mk-btn mk-restart">Restart</button>
        </div>
        <div class="mk-bar-row mk-actions"></div>
        <span class="mk-bar-hint">Everything is clickable. Timers run ${SPEED}× faster than the product's; data is made up.</span>
      </div></div>`);
    body.append(bar);
    $(".mk-bar-fold", bar).onclick = () => {
      const c = bar.dataset.collapsed !== "true";
      bar.dataset.collapsed = String(c);
      $(".mk-bar-fold", bar).textContent = c ? "▴" : "▾";
    };
    $(".mk-theme", bar).onclick = () =>
      setTheme(document.documentElement.dataset.theme === "light" ? "dark" : "light");
    $(".mk-notes-btn", bar).onclick = (e) => {
      const on = body.dataset.notes === "off";
      body.dataset.notes = on ? "on" : "off";
      e.currentTarget.setAttribute("aria-pressed", String(on));
    };
    const row = $(".mk-actions", bar);
    const fill = (list) => {
      row.textContent = "";
      for (const a of list) {
        const b = el(`<button type="button" class="mk-btn">${esc(a.label)}</button>`);
        b.onclick = a.run;
        row.append(b);
      }
    };
    $(".mk-restart", bar).onclick = () => fill(restart());
    fill(actions);
  }

  // ---------- shared Coddy components ----------

  // Field hints: the tip is fixed above the (i), as FieldHint draws it.
  function showHint(h) {
    $(".field-hint-tip")?.remove();
    if (!h) return;
    const r = h.getBoundingClientRect();
    const tip = el(`<div class="field-hint-tip is-top" role="tooltip">${esc(h.dataset.hint)}</div>`);
    body.append(tip);
    tip.style.left = `${Math.max(8, Math.min(r.left - 12, innerWidth - tip.offsetWidth - 8))}px`;
    tip.style.top = `${Math.max(8, r.top - tip.offsetHeight - 6)}px`;
  }
  document.addEventListener("mouseover", (e) => showHint(e.target.closest?.(".field-hint[data-hint]")));
  document.addEventListener("focusin", (e) => showHint(e.target.closest?.(".field-hint[data-hint]")));
  document.addEventListener("click", (e) => {
    if (e.target.closest?.(".field-hint[data-hint]")) showHint(e.target.closest(".field-hint[data-hint]"));
    if (!e.target.closest?.(".settings-combobox")) $$(".settings-combobox-list").forEach((l) => l.remove());
  });

  let toastTimer = 0;
  function toast(text) {
    $(".kiosk-toast")?.remove();
    const t = el(`<div class="kiosk-toast" role="status">${esc(text)}</div>`);
    body.append(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.remove(), 3200);
  }

  // The web UI's confirmation dialog (components/ConfirmDialog.tsx).
  function confirmDialog({ title, message, confirm, variant = "primary" }) {
    return new Promise((resolve) => {
      const icon =
        variant === "danger"
          ? svg('<path d="M3 6h18"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/><path d="M14 11v6"/>', 22)
          : ICONS.info;
      const d = el(`<div class="confirm-dialog-backdrop"><div class="confirm-dialog" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <div class="confirm-dialog-body"><span class="confirm-dialog-icon confirm-dialog-icon--${variant}" aria-hidden="true">${icon}</span>
        <div class="confirm-dialog-text"><h2 class="confirm-dialog-title">${esc(title)}</h2><p class="confirm-dialog-message">${esc(message)}</p></div></div>
        <div class="confirm-dialog-actions"><button type="button" class="confirm-dialog-btn confirm-dialog-btn--cancel">Cancel</button>
        <button type="button" class="confirm-dialog-btn confirm-dialog-btn--${variant}">${esc(confirm)}</button></div></div></div>`);
      const done = (v) => {
        d.remove();
        removeEventListener("keydown", onKey, true);
        resolve(v);
      };
      const onKey = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          done(false);
        }
      };
      addEventListener("keydown", onKey, true);
      d.addEventListener("mousedown", (e) => e.target === d && done(false));
      $(".confirm-dialog-btn--cancel", d).onclick = () => done(false);
      $(`.confirm-dialog-btn--${variant}`, d).onclick = () => done(true);
      body.append(d);
      // On a board every page is a frame: a focus that scrolls into view
      // scrolls the board too, so no focus here ever scrolls.
      $(`.confirm-dialog-btn--${variant}`, d).focus({ preventScroll: true });
    });
  }

  // Rows of the transcript, in the markup MessageList renders.
  function userRow(text) {
    return el(`<div class="msg-user-stack"><div class="msg msg-user"><div class="msg-user-body" data-testid="user-message-body"><span><span><span>${esc(text)}</span></span></span></div></div>
      <div class="msg-user-foot"><time class="msg-user-time">${clock()}</time></div></div>`);
  }
  function toolRow({ kind = "read", label, target, status = "completed", dur = "", result = "" }) {
    const failed = status === "failed";
    return el(`<div class="thinking-row coddy-tool-call-row" data-kind="${kind}" data-status="${status}">
      <details class="thinking-details coddy-tool-details"><summary class="thinking-summary" aria-label="Tool summary"><span class="thinking-left">
      <span class="coddy-chevron thinking-chevron" aria-hidden="true">${ICONS.chevron}</span><span class="thinking-head"><span class="thinking-label">${esc(label)}</span>
      <span class="thinking-trail${failed ? " thinking-trail--failed" : ""}"><span class="tool-summary-target" title="${esc(target)}">${esc(target)}</span>${failed ? '<span class="tool-failed-marker">(failed)</span>' : ""}${dur ? `<span class="thinking-dur" aria-hidden="true">${esc(dur)}</span>` : ""}</span></span></span></summary>
      <div class="thinking-body coddy-tool-call-body coddy-tool-call-body--connected-result" aria-label="Tool call details"><div class="tool-call-result-card" aria-label="Tool result"><div class="tool-call-result-content"><pre class="tool-result-pre">${esc(result)}</pre></div></div></div></details></div>`);
  }
  function assistantRow() {
    return el('<div class="msg-assistant-stack"><div class="msg msg-assistant"><div class="md"></div></div></div>');
  }
  function liveRow(verb = "Thinking") {
    return el(`<div class="msg-assistant-stack typing-dots-slot" aria-hidden="true"><div class="typing-dots"><span class="typing-dots-dot"></span><span class="typing-dots-dot"></span><span class="typing-dots-dot"></span>
      <span class="typing-dots-status"><span class="typing-dots-status-text"><span class="typing-dots-status-verb">${esc(verb)}</span></span></span></div></div>`);
  }
  function systemRow(text) {
    return el(`<div class="msg-system-stack msg-system-stack-notice"><div class="msg msg-system msg-system-notice"><div class="msg-system-label">System</div><pre class="msg-system-body">${esc(text)}</pre></div>
      <div class="msg-system-foot"><time class="msg-system-time">${clock()}</time></div></div>`);
  }
  // Streams blocks of Markdown-rendered HTML the way an answer arrives.
  async function stream(md, blocks, scroller, alive) {
    for (const b of blocks) {
      if (!alive()) return;
      const host = b.list ? md.lastElementChild?.tagName === "UL" ? md.lastElementChild : md.appendChild(document.createElement("ul")) : md;
      const node = document.createElement(b.list ? "li" : b.tag || "p");
      host.append(node);
      const plain = b.html.replace(/<[^>]+>/g, "");
      for (let i = 0; i <= plain.length; i += 3) {
        if (!alive()) return;
        node.textContent = plain.slice(0, i);
        scroller?.();
        await sleep(14);
      }
      node.innerHTML = b.html;
      scroller?.();
    }
  }

  // ---------- the kiosk's data (made up, neutral) ----------

  const PROFILE = {
    name: "reception",
    title: "Reception",
    sub: "Ask about our products",
    lead: "Ask about our",
    accent: "products",
    welcome: "Plans, prices, setup and support hours. Answers come from our product docs.",
    notice: "No sign-in. Conversations are kept for 14 days, then deleted.",
    maxTurns: 20,
    maxMinutes: 30,
    link: "7kq2m9x4tq",
  };
  const SUGGEST = ["Which plan includes single sign-on?", "What are your support hours?", "Can you install it for me?"];

  const SCRIPT = [
    {
      match: /sso|sign[- ]?on|saml|oidc/i,
      tools: [{ kind: "read", label: "reading a file", target: "docs/pricing.md", dur: "5ms", result: "# Pricing\n\n| Plan | Single sign-on | Price |\n|---|---|---|\n| Team | no | 8 euros a user a month |\n| Business | SAML and OIDC | 13 euros a user a month |\n| Enterprise | SAML, OIDC and SCIM | on request |" }],
      blocks: [
        { html: "<strong>Business</strong> and <strong>Enterprise</strong> include single sign-on, with SAML and OIDC." },
        { list: true, html: "<strong>Business</strong> adds it for 5 euros a user a month." },
        { list: true, html: "<strong>Enterprise</strong> includes it, together with SCIM provisioning." },
        { html: "Want me to compare the two plans side by side?" },
      ],
    },
    {
      match: /price|cost|plan|euro|pay|compare|cheap/i,
      tools: [{ kind: "read", label: "reading a file", target: "docs/pricing.md", dur: "4ms", result: "# Pricing\n…" }],
      blocks: [
        { html: "Three plans, billed a user a month:" },
        { list: true, html: "<strong>Team</strong> - 8 euros, no single sign-on." },
        { list: true, html: "<strong>Business</strong> - 13 euros, SAML and OIDC." },
        { list: true, html: "<strong>Enterprise</strong> - on request, with SCIM provisioning." },
      ],
    },
    {
      match: /hour|open|support|contact|phone|call|email/i,
      tools: [{ kind: "grep", label: "searching files", target: '"support hours" in docs', dur: "11ms", result: "docs/support.md:3: Support hours: Monday to Friday, 9:00-18:00 CET" }],
      blocks: [
        { html: "Support answers <strong>Monday to Friday, 9:00-18:00 CET</strong>." },
        { html: "Outside those hours, write to <code>support@example.com</code>; the first answer comes the next working day." },
      ],
    },
    {
      match: /install|run|delete|remove|command|shell|terminal|server|deploy/i,
      tools: [{ kind: "execute", label: "running a command", target: "./install.sh", status: "failed", result: "Refused: run_command is not allowed in this kiosk (disallowed_tools)." }],
      blocks: [
        { html: "I can't run commands or change anything here: this kiosk only reads our product docs." },
        { html: "The install guide is in <code>docs/setup.md</code>; ask me about any step of it." },
      ],
    },
  ];
  const FALLBACK = {
    tools: [{ kind: "grep", label: "searching files", target: "docs", dur: "9ms", result: "No matches." }],
    blocks: [{ html: "Our product docs say nothing about that. Ask me about plans, prices, setup or support hours." }],
  };
  const SETTINGS_CMD = /^\s*\/(model|mode|toolset|agent|permissions|reasoning|workspace|new|goal)\b/i;

  // ---------- Stage 3: the kiosk screen ----------

  function kioskApp(root, opts = {}) {
    const operator = !!opts.operator;
    const S = {
      stage: "welcome",
      turns: 0,
      minutes: PROFILE.maxMinutes,
      busy: false,
      gen: 0,
      idleOpen: false,
      dead: false,
      touched: false,
      loop: false,
    };
    let idleTimer = 0;
    let countTimer = 0;

    function shell(mainInner, mainClass = "main") {
      const rail = operator ? FRAGS.railChat : "";
      return `<div class="shell${operator ? "" : " kiosk-shell"}" style="--rail-shell-track-width: ${operator ? 84 : 0}px;">${rail}
        <div class="shell-main"><div class="backdrop" aria-hidden="true"></div><main class="${mainClass}">${mainInner}</main></div></div>`;
    }

    function renderWelcome() {
      S.stage = "welcome";
      stopIdle();
      root.innerHTML = shell(
        `<div class="hero" id="hero"><h1 class="hero-title"><span class="hero-title-muted">${esc(PROFILE.lead)} <span class="hero-title-accent">${esc(PROFILE.accent)}</span>?</span></h1>
        <div class="hero-composer"><div class="kiosk-welcome" data-testid="kiosk-welcome">
          <p class="kiosk-welcome-lead">${esc(PROFILE.welcome)}</p>
          <button type="button" class="confirm-dialog-btn confirm-dialog-btn--primary kiosk-start">Start</button>
          <p class="kiosk-welcome-notice">${esc(PROFILE.notice)}</p></div></div>
        <div class="hero-footer"><span>Example Ltd · reception desk</span></div></div>`,
        "main is-empty",
      );
      $(".kiosk-start", root).onclick = () => startSession();
      setNotes([
        { at: ".hero-title", text: "No rail, Settings or sessions: the page is the profile's alone", side: "above" },
        { at: ".kiosk-welcome-lead", text: "The welcome comes from the profile", side: "right" },
        { at: ".kiosk-start", text: "Start makes a visitor: a cookie bound to one new session", side: "right" },
        { at: ".kiosk-welcome-notice", text: "The notice says how long conversations are kept (Decision 5)", side: "below" },
      ]);
    }

    function startSession(seed) {
      S.turns = 0;
      S.minutes = PROFILE.maxMinutes;
      S.gen++;
      renderChat();
      if (seed) seedConversation();
      armIdle();
    }

    function leftLabel() {
      if (innerWidth < 600) return `${S.turns}/${PROFILE.maxTurns} · ${S.minutes} min`;
      return `${S.turns} of ${PROFILE.maxTurns} turns · ${S.minutes} min left`;
    }

    function renderChat() {
      S.stage = "chat";
      const banner = operator
        ? `<div class="subagent-readonly-notice kiosk-try-banner" role="note"><span class="subagent-readonly-copy"><span class="subagent-readonly-text">Trying the kiosk profile <strong>${esc(PROFILE.name)}</strong>: this chat runs as a visitor's would, on the profile's folder, model, tools and limits.</span></span>
           <button type="button" class="subagent-readonly-link kiosk-back-settings">Back to Settings</button></div>`
        : "";
      root.innerHTML = shell(`<div class="chat-stack" style="--chat-composer-reserve: 150px;">
        <div class="chat-scroll" id="messages" aria-live="polite">
          <div class="chat-scroll-sticky-head"><div class="chat-title-column"><header class="chat-header">
            <div class="chat-title" id="chat-title"><span class="chat-title-btn">${esc(PROFILE.title)}<span class="kiosk-title-sub">${esc(PROFILE.sub)}</span></span></div>
            <div class="chat-views" role="toolbar" aria-label="Session">
              <span class="chat-view-tip-host"><span class="chat-view-btn chat-view-btn--tasks kiosk-left" role="status"><span class="chat-view-face">${ICONS.clock}<span class="chat-view-label">${leftLabel()}</span></span></span></span>
              <span class="chat-view-tip-host"><button type="button" class="chat-view-btn chat-view-btn--tasks kiosk-end"><span class="chat-view-face">${ICONS.logout}<span class="chat-view-label">${innerWidth < 600 ? "End" : "End session"}</span></span></button></span>
            </div></header></div></div>
          <div class="messages-inner">${banner}</div>
          <div class="chat-scroll-tail" aria-hidden="true"></div>
        </div>
        <div class="chat-bottom"><div class="chat-bottom-inner">${composerMarkup()}</div></div></div>`);
      wireComposer();
      $(".kiosk-end", root).onclick = endSession;
      const back = $(".kiosk-back-settings", root);
      if (back && opts.onBack) back.onclick = opts.onBack;
      chatNotes();
    }

    function composerMarkup() {
      return `<footer class="composer-wrap composer-wrap-docked"><label class="sr-only" for="composer">Message</label><div class="composer-card">
        <div class="composer-field-wrap"><div class="composer-stack"><textarea id="composer" rows="2" enterkeyhint="send" placeholder="Ask a question" autocomplete="off" style="height: 64px;"></textarea></div></div>
        <div class="composer-bar"><div class="composer-tabs" aria-label="Composer options"><span class="kiosk-hint">Answers come from our product docs</span></div>
        <div class="composer-bar-actions"><button type="button" class="composer-icon composer-run-icon composer-send-play composer-run-icon--play" id="btn-send" aria-label="Send" disabled><span class="composer-send-glyph" aria-hidden="true">${ICONS.send}</span></button></div></div>
        </div></footer>`;
    }

    function chatNotes() {
      const list = [
        { at: ".kiosk-left", text: "Turns and minutes left; End session clears everything for the next visitor", side: "left" },
        { at: ".composer-card", text: "No model, mode or permission chip, no attachments: the profile pins them", side: "above" },
      ];
      if (operator) list.push({ at: ".kiosk-try-banner", text: "Try: the operator checks a profile before publishing it", side: "below" });
      setNotes(list);
    }

    function wireComposer() {
      const ta = $("#composer", root);
      const send = $("#btn-send", root);
      const sync = () => {
        send.disabled = !ta.value.trim() || S.busy;
      };
      ta.addEventListener("input", sync);
      ta.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
          e.preventDefault();
          if (!send.disabled) submit();
        }
      });
      send.onclick = submit;
      function submit() {
        const text = ta.value.trim();
        if (!text) return;
        ta.value = "";
        sync();
        ask(text);
      }
    }

    function list() {
      return $(".messages-inner", root);
    }
    function scrollEnd() {
      const sc = $(".chat-scroll", root);
      if (sc) sc.scrollTop = sc.scrollHeight;
      document.scrollingElement.scrollTop = document.scrollingElement.scrollHeight;
    }

    async function ask(text, quick) {
      if (S.dead || S.busy || S.stage !== "chat") return;
      const gen = S.gen;
      const alive = () => gen === S.gen && S.stage === "chat";
      list().append(userRow(text));
      scrollEnd();
      if (SETTINGS_CMD.test(text)) {
        list().append(systemRow(`${text.trim().split(/\s+/)[0]} is not available here: this kiosk sets the model, mode, tools and folder.`));
        scrollEnd();
        return;
      }
      S.busy = true;
      S.turns++;
      updateLeft();
      const live = liveRow();
      list().append(live);
      scrollEnd();
      const plan = SCRIPT.find((s) => s.match.test(text)) || FALLBACK;
      await sleep(quick ? 0 : 500);
      for (const t of plan.tools) {
        if (!alive()) return;
        const row = toolRow({ ...t, status: t.status === "failed" ? "failed" : "in_progress", dur: "" });
        live.before(row);
        scrollEnd();
        await sleep(quick ? 0 : 700);
        row.replaceWith(toolRow(t));
      }
      if (!alive()) return;
      live.remove();
      const a = assistantRow();
      list().append(a);
      if (quick) {
        for (const b of plan.blocks) {
          const host = b.list ? ($(".md", a).lastElementChild?.tagName === "UL" ? $(".md", a).lastElementChild : $(".md", a).appendChild(document.createElement("ul"))) : $(".md", a);
          const n = document.createElement(b.list ? "li" : "p");
          n.innerHTML = b.html;
          host.append(n);
        }
      } else {
        await stream($(".md", a), plan.blocks, scrollEnd, alive);
      }
      if (!alive()) return;
      S.busy = false;
      scrollEnd();
      armIdle();
      if (S.turns >= PROFILE.maxTurns) renderLimit("turns");
    }

    function updateLeft() {
      const l = $(".kiosk-left .chat-view-label", root);
      if (l) l.textContent = leftLabel();
      const host = $(".kiosk-left", root);
      if (host) host.dataset.low = String(PROFILE.maxTurns - S.turns <= 2 || S.minutes <= 3);
    }

    function seedConversation() {
      ask(SUGGEST[0], true);
    }

    function renderLimit(why) {
      S.stage = "limit";
      stopIdle();
      const bottom = $(".chat-bottom-inner", root);
      const reason =
        why === "time"
          ? `This session has used its <strong>${PROFILE.maxMinutes} minutes</strong>.`
          : `This session has used its <strong>${PROFILE.maxTurns} turns</strong>.`;
      bottom.innerHTML = `<div class="subagent-readonly-notice kiosk-limit" role="note"><span class="subagent-readonly-copy"><span class="subagent-readonly-text">${reason} Start again for a new one; this conversation is cleared from the screen.</span></span>
        <button type="button" class="confirm-dialog-btn confirm-dialog-btn--primary kiosk-again">Start again</button></div>`;
      $(".kiosk-again", root).onclick = () => startSession();
      updateLeft();
      setNotes([
        { at: ".kiosk-limit", text: "Past max_turns or max_session the composer gives way to Start again", side: "above" },
        { at: ".kiosk-left", text: "The server counts; a turn past the limit is refused", side: "below", dx: -60 },
      ]);
    }

    async function endSession() {
      const ok = await confirmDialog({
        title: "End this session?",
        message: "The conversation is cleared from this screen and the welcome comes back for the next visitor.",
        confirm: "End session",
        variant: "danger",
      });
      if (!ok) return;
      S.gen++;
      S.busy = false;
      renderWelcome();
      toast("Session ended. The screen is ready for the next visitor.");
    }

    // Idle: after idle.warn without input a countdown covers the screen; at
    // idle.reset the server ends the session and the welcome comes back.
    const WARN_MS = 20000; // idle.warn is 4 min; the mockup waits 20 s after the last touch
    const RESET_S = 60;
    function armIdle() {
      clearTimeout(idleTimer);
      if (S.dead || S.stage !== "chat" || operator || !S.touched) return;
      idleTimer = setTimeout(openIdle, WARN_MS);
    }
    function stopIdle() {
      clearTimeout(idleTimer);
      clearInterval(countTimer);
      $(".kiosk-idle")?.remove();
      S.idleOpen = false;
    }
    function openIdle() {
      if (S.dead || S.stage !== "chat" || S.busy || S.idleOpen) return;
      S.idleOpen = true;
      let left = RESET_S;
      const fmt = (s) => `0:${String(s).padStart(2, "0")}`;
      const d = el(`<div class="confirm-dialog-backdrop kiosk-idle"><div class="confirm-dialog" role="alertdialog" aria-modal="true" aria-label="Still there?">
        <div class="confirm-dialog-body"><span class="confirm-dialog-icon confirm-dialog-icon--primary" aria-hidden="true">${ICONS.alarm}</span>
        <div class="confirm-dialog-text"><h2 class="confirm-dialog-title">Still there?</h2>
        <span class="kiosk-idle-count" aria-live="polite">${fmt(left)}</span>
        <p class="confirm-dialog-message">Nothing has happened for 4 minutes. When the count reaches zero, this session ends and the screen is cleared for the next visitor.</p></div></div>
        <div class="confirm-dialog-actions"><button type="button" class="confirm-dialog-btn confirm-dialog-btn--primary">I'm still here</button></div></div></div>`);
      body.append(d);
      const dismiss = () => {
        S.loop = false;
        S.touched = true;
        stopIdle();
        armIdle();
        chatNotes();
      };
      d.addEventListener("pointerdown", dismiss);
      d.addEventListener("keydown", dismiss);
      // The idle slide plays on its own: it takes the focus only from itself,
      // never from the frame a person works in.
      if (document.hasFocus()) $(".confirm-dialog-btn", d).focus({ preventScroll: true });
      setNotes([
        { at: ".kiosk-idle .confirm-dialog", text: "idle.warn (4 min) without input: any tap dismisses", side: "above" },
        { at: ".kiosk-idle-count", text: "At idle.reset (5 min) the server ends the session", side: "right" },
      ]);
      countTimer = setInterval(() => {
        left -= 1;
        const c = $(".kiosk-idle-count");
        if (c) c.textContent = fmt(Math.max(0, left));
        if (left <= 0) {
          stopIdle();
          S.gen++;
          S.busy = false;
          renderWelcome();
          toast("The session ended after 5 minutes without input. Storage cleared.");
          if (S.loop) {
            // The idle slide plays the loop again until somebody touches it.
            setTimeout(() => {
              if (!S.loop || S.dead || S.stage !== "welcome") return;
              startSession(true);
              setTimeout(openIdle, 2500);
            }, 5000);
          }
        }
      }, 1000 / SPEED);
    }
    const onActivity = (e) => {
      if (S.dead || e.target.closest?.(".mk-bar")) return;
      S.touched = true;
      S.loop = false;
      if (!S.idleOpen) armIdle();
    };
    for (const ev of ["pointerdown", "keydown", "input"]) addEventListener(ev, onActivity, true);

    function goOffline() {
      if ($(".kiosk-offline")) return;
      const o = el('<div class="kiosk-offline" role="alert"><div class="kiosk-offline-card"><span class="kiosk-spinner" aria-hidden="true"></span><span>Connection lost. Reconnecting…</span></div></div>');
      body.append(o);
      setTimeout(() => {
        o.remove();
        toast("Back online. The page reloaded its session.");
      }, 3500);
    }

    const api = {
      welcome: renderWelcome,
      chat: () => startSession(true),
      idle: () => {
        S.loop = true;
        startSession(true);
        setTimeout(openIdle, 1400);
      },
      limit: () => {
        startSession(true);
        setTimeout(() => {
          S.turns = PROFILE.maxTurns;
          renderLimit("turns");
        }, 900);
      },
      lastTurn: () => {
        if (S.stage !== "chat") return;
        S.turns = PROFILE.maxTurns - 1;
        updateLeft();
        toast("One turn left. Ask anything to reach the limit.");
      },
      timeUp: () => {
        if (S.stage !== "chat") return;
        S.minutes = 0;
        updateLeft();
        renderLimit("time");
      },
      idleNow: () => {
        if (S.stage !== "chat") startSession(true);
        setTimeout(openIdle, 300);
      },
      offline: goOffline,
      stop: () => {
        S.dead = true;
        S.gen++;
        stopIdle();
        for (const ev of ["pointerdown", "keydown", "input"]) removeEventListener(ev, onActivity, true);
      },
    };
    return api;
  }

  // ---------- Stages 1, 2 and 5: the operator's Settings, Kiosk ----------

  function hintBtn(label, text) {
    return `<button type="button" class="field-hint" data-testid="field-hint" aria-label="About ${esc(label)}" data-hint="${esc(text)}">${ICONS.hint}</button>`;
  }
  function textField(key, label, value, hint, placeholder = "") {
    return `<div class="settings-field" data-k="${key}"><div class="settings-row"><span class="settings-label settings-label-with-hint"><span class="settings-label-text">${esc(label)}</span>${hint ? hintBtn(label, hint) : ""}</span>
      <input class="settings-input" aria-label="${esc(label)}" type="text" placeholder="${esc(placeholder)}" value="${esc(value)}"></div></div>`;
  }
  function comboField(key, label, value, options, hint) {
    return `<div class="settings-field" data-k="${key}"><div class="settings-row"><span class="settings-label settings-label-with-hint"><span class="settings-label-text">${esc(label)}</span>${hint ? hintBtn(label, hint) : ""}</span>
      <div class="settings-combobox" data-options="${esc(JSON.stringify(options))}"><input class="settings-input settings-combobox-input" role="combobox" aria-expanded="false" aria-label="${esc(label)}" type="text" value="${esc(value)}">
      <button type="button" class="settings-combobox-toggle" tabindex="-1" aria-label="Toggle options"><span class="coddy-chevron coddy-chevron--down" aria-hidden="true">${ICONS.chevron}</span></button></div></div></div>`;
  }
  function switchField(key, label, on, hint) {
    return `<div class="settings-field" data-k="${key}"><div class="settings-switch-field"><button type="button" role="switch" aria-checked="${on}" class="skill-switch" aria-label="${esc(label)}"><span class="skill-switch-thumb"></span></button>
      <span class="settings-switch-field-label-cell"><label class="settings-switch-field-label">${esc(label)}</label>${hint ? hintBtn(label, hint) : ""}</span></div></div>`;
  }
  function arrayRow(label, v) {
    return `<li class="settings-array-row"><div class="settings-array-row-field"><input class="settings-input" aria-label="${esc(label)}" type="text" value="${esc(v)}"></div>
      <button type="button" class="settings-btn settings-btn-icon settings-btn-danger settings-array-remove" aria-label="Remove" title="Remove">${ICONS.trash}</button></li>`;
  }
  function arrayField(key, label, values, hint) {
    return `<fieldset class="settings-fieldset" data-k="${key}"><legend><span class="settings-legend-line">${esc(label)}${hint ? hintBtn(label, hint) : ""}</span></legend>
      <ul class="settings-array">${values.map((v) => arrayRow(label, v)).join("")}</ul><button type="button" class="settings-btn settings-array-add" data-label="${esc(label)}">Add</button></fieldset>`;
  }
  function group(title, inner, hint, extra = "") {
    return `<fieldset class="settings-fieldset settings-form-group" ${extra}><legend><span class="settings-legend-line">${esc(title)}${hint ? hintBtn(title, hint) : ""}</span></legend><div class="settings-form-group-body">${inner}</div></fieldset>`;
  }

  const PROFILES = {
    reception: {
      kind: "interactive",
      workspace: "~/kiosk/reception",
      model: "neuraldeep/gemma-4-31b",
      mode: "ask",
      instructions: ["~/kiosk/reception/AGENTS.md"],
      rules: "~/kiosk/reception/rules",
      skills: "~/kiosk/reception/skills",
      toolsets: ["docs"],
      tools: ["read", "grep", "glob", "coddy_docs_search", "question"],
      denied: ["run_command", "mcp__*"],
      mcp: [],
      deny_files: ["~/kiosk/policy/deny.json"],
      telegram: ["-1001234567890"],
      pachca: [],
      chats: "1 Telegram chat",
    },
    "release-wall": {
      kind: "display",
      workspace: "~/kiosk/release-wall",
      model: "neuraldeep/gemma-4-31b",
      mode: "ask",
      instructions: [],
      rules: "",
      skills: "",
      toolsets: [],
      tools: [],
      denied: [],
      mcp: [],
      deny_files: [],
      telegram: [],
      pachca: [],
      chats: "no chats",
      link: "w3p8c1zr5m",
    },
  };

  function qrSvg(seed) {
    // A made-up pattern in a QR code's shape: the mockup's, not scannable.
    let x = 0;
    for (const c of seed) x = (x * 31 + c.charCodeAt(0)) >>> 0;
    const n = 25;
    let cells = "";
    const finder = (r, c) => (r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7);
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        let on;
        if (finder(r, c)) {
          const rr = r < 7 ? r : r - (n - 7);
          const cc = c < 7 ? c : c - (n - 7);
          on = rr === 0 || rr === 6 || cc === 0 || cc === 6 || (rr >= 2 && rr <= 4 && cc >= 2 && cc <= 4);
        } else {
          x = (x * 1103515245 + 12345) >>> 0;
          on = (x >>> 16) % 2 === 0;
        }
        if (on) cells += `<rect x="${c}" y="${r}" width="1" height="1"/>`;
      }
    }
    return `<svg viewBox="0 0 ${n} ${n}" fill="#111" shape-rendering="crispEdges" role="img" aria-label="QR code of the link">${cells}</svg>`;
  }

  function operatorApp(root) {
    const state = {
      view: "list", // list | detail | try
      profile: "reception",
      links: { reception: PROFILE.link, "release-wall": PROFILES["release-wall"].link },
      web: { reception: true, "release-wall": true },
      qrOpen: null,
      dirty: false,
      sessions: [
        { id: "s1", title: "Which plan includes single sign-on?", profile: "reception", surface: "Web link", started: "2 min ago", turns: "3 / 20", state: "running" },
        { id: "s2", title: "Telegram chat -1001234567890", profile: "reception", surface: "Telegram", started: "6 min ago", turns: "5 / 20", state: "idle" },
        { id: "s3", title: "Release 1.4 notes", profile: "release-wall", surface: "Display link", started: "25 min ago", turns: "-", state: "running" },
      ],
    };
    let kiosk = null;

    function navWithKiosk() {
      let nav = FRAGS.settingsNavWrap.replace(/ is-active/g, "").replace(/ aria-current="page"/g, "");
      nav = nav.replace(
        /(<button[^>]*data-testid="settings-tab-gateways"[^>]*>Gateways<\/button>)/,
        '$1<button type="button" class="settings-nav-item is-active" data-testid="settings-tab-kiosk" aria-current="page">Kiosk</button>',
      );
      return nav;
    }

    function drawer(head, scroll) {
      return `<div class="settings-dock-cluster"><aside class="sessions settings drawer" aria-label="Settings" data-testid="settings-screen" data-variant="drawer">
        ${head}<div class="settings-stack"><div class="settings-tabs-layout">${navWithKiosk()}<div class="settings-scroll" data-settings-tab="kiosk"><div class="settings-body">${scroll}</div></div></div>
        ${FRAGS.settingsFooter}</div></aside></div>`;
    }

    function page(inner) {
      root.innerHTML = `<div class="shell" style="--rail-shell-track-width: 84px;">${FRAGS.railSettings}<div class="shell-main">${FRAGS.backdropOpen}${inner}${FRAGS.heroBehind}</div></div>`;
      wireDrawer();
      const item = $('[data-testid="settings-tab-kiosk"]', root);
      const nav = $(".settings-nav", root);
      if (item && nav) nav.scrollTop = item.offsetTop - nav.clientHeight / 2;
    }

    function linkRow(name) {
      const on = state.web[name];
      const link = `/kiosk/${state.links[name]}/`;
      return `<div class="kiosk-link-row"><code class="kiosk-link-code" data-off="${!on}">${esc(link)}</code>
        <button type="button" class="settings-btn kiosk-copy" data-p="${name}">${ICONS.copy}<span>Copy link</span></button>
        <button type="button" class="settings-btn kiosk-qr-btn" data-p="${name}" aria-pressed="${state.qrOpen === name}">${ICONS.qr}<span>QR code</span></button>
        <button type="button" class="settings-btn settings-btn-danger kiosk-newlink" data-p="${name}">${ICONS.newlink}<span>New link</span></button></div>
        ${state.qrOpen === name ? `<div class="kiosk-qr">${qrSvg(state.links[name])}<p>Scan to open <code>https://help.example.com${esc(link)}</code> on a device. The proxy in front of Coddy decides who reaches it.</p></div>` : ""}`;
    }

    function renderList() {
      state.view = "list";
      const profiles = Object.keys(PROFILES);
      const rows = state.sessions
        .map(
          (s) => `<tr data-id="${s.id}"><td><div class="sessions-manager-title-line" title="${esc(s.title)}">${esc(s.title)}</div><div class="sessions-manager-sub">${esc(s.profile)} · ${esc(s.surface)} · ${esc(s.started)}${s.turns !== "-" ? ` · ${esc(s.turns)} turns` : ""}</div></td>
          <td class="kiosk-col-state"><span class="system-pill" data-state="${s.state}">${s.state}</span></td>
          <td><div class="kiosk-sessions-actions"><button type="button" class="settings-btn kiosk-watch-btn" data-id="${s.id}" title="Watch" aria-label="Watch ${esc(s.title)}">${ICONS.eye}</button><button type="button" class="settings-btn settings-btn-danger kiosk-end-btn" data-id="${s.id}" title="End" aria-label="End ${esc(s.title)}">${ICONS.stop}</button></div></td></tr>`,
        )
        .join("");
      page(
        drawer(
          '<div class="sessions-head"><span>Settings</span><button type="button" class="sessions-close" aria-label="Close settings">×</button></div>',
          `<div class="settings-master"><p class="settings-field-desc">Locked-down profiles: one folder, one model, the tools you allow, published as a web link or bound messenger chats.</p>
          <ul class="settings-master-list">${profiles
            .map((p) => `<li class="settings-master-row"><button type="button" class="settings-master-item" data-p="${p}">${esc(p)}</button><button type="button" class="settings-btn settings-btn-icon settings-btn-danger" aria-label="Remove ${esc(p)}" title="Remove">${ICONS.trash}</button></li>`)
            .join("")}</ul><button type="button" class="settings-btn settings-master-add">Add</button></div>
          ${group(
            "Links",
            profiles
              .map((p) => `<div class="kiosk-profile-line"><span class="kiosk-profile-name">${esc(p)} <span class="kiosk-profile-meta">· ${esc(PROFILES[p].kind)} · ${esc(PROFILES[p].chats)}</span></span>${linkRow(p)}</div>`)
              .join(""),
            "A random link per profile. New link revokes the old one: its address answers 404 and its sessions end.",
          )}
          <fieldset class="settings-fieldset kiosk-live"><legend><span class="settings-legend-line">Live sessions${hintBtn("Live sessions", "Kiosk sessions on every surface: the web links, the bound Telegram and Pachca chats, the display links.")}</span></legend>
          <div class="sessions-manager-tablewrap"><table class="sessions-manager-table"><thead><tr><th scope="col">Session</th><th scope="col">State</th><th scope="col"><span class="sr-only">Actions</span></th></tr></thead>
          <tbody>${rows || '<tr><td colspan="3">No kiosk session is running.</td></tr>'}</tbody></table></div></fieldset>`,
        ),
      );
      $$(".settings-master-item", root).forEach((b) => (b.onclick = () => renderDetail(b.dataset.p)));
      $(".settings-master-add", root).onclick = () => toast("Add makes a profile with a new random link and the default tools.");
      wireLinks();
      $$(".kiosk-watch-btn", root).forEach((b) => (b.onclick = () => watch(b.dataset.id)));
      $$(".kiosk-end-btn", root).forEach(
        (b) =>
          (b.onclick = async () => {
            const s = state.sessions.find((x) => x.id === b.dataset.id);
            const ok = await confirmDialog({ title: "End this kiosk session?", message: `"${s.title}" ends now; the visitor sees the welcome again.`, confirm: "End", variant: "danger" });
            if (!ok) return;
            state.sessions = state.sessions.filter((x) => x !== s);
            renderList();
            toast("Session ended. It stays in History for 14 days, marked as a kiosk session.");
          }),
      );
      setNotes([
        { at: '[data-testid="settings-tab-kiosk"]', text: "A new Kiosk section: profiles as a list, like the providers", side: "above" },
        { at: ".kiosk-link-row", text: "Copy link, a QR code and New link per profile", side: "above" },
        { at: ".kiosk-live", text: "Live kiosk sessions of every surface: Watch reads one, End ends it", side: "above" },
      ]);
    }

    function profileForm(name) {
      const p = PROFILES[name];
      return `<div class="settings-detail"><div class="settings-schema-root">
        ${group(
          "Profile",
          textField("name", "Name", name, "The profile's id in config.yaml.") +
            comboField("kind", "Kind", p.kind, ["interactive", "display"], "Interactive takes questions; display only shows a session or a board.") +
            textField("workspace", "Workspace", p.workspace, "Every visitor's session runs in this folder; the visitor cannot move it.") +
            comboField("model", "Model", p.model, ["neuraldeep/gemma-4-31b", "neuraldeep/qwen3.8-coder", "openai/gpt-5.6-terra"], "One of your models. The visitor cannot switch it.") +
            comboField("mode", "Mode", p.mode, ["agent", "plan", "ask"], "The mode every kiosk turn runs in."),
        )}
        ${group(
          "Agent files",
          arrayField("instructions", "Instructions", p.instructions, "Read after the workspace's own AGENTS.md and DESIGN.md. Outside the workspace, so a turn cannot edit them.") +
            textField("rules", "Rules folder", p.rules, "A rules folder of the profile's own.") +
            textField("skills", "Skills folder", p.skills, "A skills folder of the profile's own."),
          "What the model reads. Advice, not a lock: a prohibition is enforced only by the lists and the prohibition files.",
        )}
        ${group(
          "Tools",
          arrayField("toolsets", "Toolsets", p.toolsets, "Toolsets of your configuration whose tools are allowed.") +
            arrayField("tools", "Allowed tools", p.tools, "Names or patterns, as in subagent definitions.") +
            arrayField("disallowed_tools", "Denied tools", p.denied, "Wins over the two lists above. The configuration, model, worktree, scheduler, background and preview tools are always denied.") +
            arrayField("mcp", "MCP servers", p.mcp, "Servers of <home>/mcp.json a kiosk turn may use."),
        )}
        ${group(
          "Prohibitions and the visitor",
          arrayField("deny_files", "Prohibition files", p.deny_files, "Hook files: their PreToolUse and UserPromptSubmit hooks run for every kiosk turn, fail closed.") +
            switchField("uploads", "Visitors may attach files", false) +
            switchField("web_mentions", "Visitors may mention web pages", false) +
            comboField("approvals", "Approvals", "refuse", ["refuse", "operator"], "Refuse every approval, or offer it to your surfaces and refuse when nobody answers in time."),
        )}
        ${group(
          "Other settings",
          switchField("inherit", "Inherit my configuration", true, "Off: Coddy's defaults, none of your own agent files, rules, skills, hooks or MCP servers.") +
            arrayField("settings", "Sections set by hand", ["compaction", "tools"], "These sections are the kiosk's own. Providers and models always come from your configuration."),
        )}
        ${group(
          "Publish",
          switchField("web", "Web link", state.web[name], "Served under /kiosk/<link>/ with no credential; everything else keeps yours.") +
            `<div class="settings-field">${linkRow(name)}</div>` +
            arrayField("telegram", "Telegram chats", p.telegram, "Chats of the bot bound to this profile, or all. Who may write to the bot stays in Gateways.") +
            arrayField("pachca", "Pachca chats", p.pachca, "Chats of the Pachca bot bound to this profile."),
          "",
          'data-anchor="publish"',
        )}
        ${group(
          "Timers and limits",
          textField("idle.warn", "Idle warning", "4m", "The countdown covers the screen after this long without input.") +
            textField("idle.reset", "Idle reset", "5m", "The server ends the session; the welcome comes back.") +
            textField("max_session", "Longest session", "30m") +
            textField("max_turns", "Most turns", "20") +
            textField("max_live", "Visitors at once", "3", "Visitors at once on this profile, on every surface."),
        )}</div></div>`;
    }

    function renderDetail(name, opts = {}) {
      state.view = "detail";
      state.profile = name;
      page(
        drawer(
          `<div class="sessions-head"><span class="settings-head-titlegroup"><button type="button" class="settings-head-back" aria-label="Back to Kiosk" title="Back to Kiosk">${ICONS.back}</button><span class="settings-head-section">Kiosk profile · ${esc(name)}</span></span>
           <button type="button" class="settings-btn kiosk-head-try" title="Open a session under this profile in your own web UI">${ICONS.play}<span>Try</span></button>
           <button type="button" class="sessions-close" aria-label="Close settings">×</button></div>`,
          profileForm(name),
        ),
      );
      $(".settings-head-back", root).onclick = renderList;
      $(".kiosk-head-try", root).onclick = renderTry;
      wireForm();
      wireLinks();
      if (opts.scrollTo) {
        const t = $(`[data-anchor="${opts.scrollTo}"]`, root);
        if (t) $(".settings-scroll", root).scrollTop = t.offsetTop - 8;
      }
      const n = [
        { at: ".kiosk-head-try", text: "Try: a session under this profile in your own web UI", side: "below", dx: -150 },
        { at: '[data-k="workspace"]', text: "Folder, model and mode: the visitor cannot switch them", side: "right" },
        { at: '[data-k="disallowed_tools"]', text: "Denied tools win; patterns as in subagent definitions", side: "right" },
        { at: '[data-k="deny_files"]', text: "Prohibition files are hooks: enforced, fail closed", side: "right" },
        { at: '[data-k="web"]', text: "Published as a web link, Telegram or Pachca chats", side: "right" },
      ];
      setNotes(opts.publish ? n.slice(4).concat([{ at: ".kiosk-qr", text: "The QR code opens the link on a phone or tablet", side: "right" }]) : n);
    }

    function renderTry() {
      state.view = "try";
      kiosk?.stop();
      root.innerHTML = "";
      kiosk = kioskApp(root, {
        operator: true,
        onBack: () => {
          kiosk.stop();
          renderDetail(state.profile);
        },
      });
      kiosk.chat();
    }

    function setDirty(v) {
      state.dirty = v;
      const save = $('[data-testid="settings-save"]', root);
      if (save) save.classList.toggle("is-dirty", v);
      const st = $('[data-testid="settings-save-status"]', root);
      if (st) st.textContent = v ? "Unsaved changes" : "";
    }

    function wireDrawer() {
      $$(".settings-nav-item", root).forEach((b) => {
        if (b.dataset.testid === "settings-tab-kiosk") {
          b.onclick = renderList;
          return;
        }
        b.onclick = () => {
          $$(".settings-nav-item", root).forEach((x) => {
            x.classList.remove("is-active");
            x.removeAttribute("aria-current");
          });
          b.classList.add("is-active");
          $(".settings-body", root).innerHTML = `<p class="kiosk-off-section">${esc(b.textContent)} is not changed by the kiosk. Pick <strong>Kiosk</strong> to go back.</p>`;
          setNotes([]);
        };
      });
      $$(".sessions-close", root).forEach((b) => (b.onclick = () => toast("The drawer stays open in this mockup.")));
      const save = $('[data-testid="settings-save"]', root);
      if (save)
        save.onclick = () => {
          if (!state.dirty) return toast("Nothing to save.");
          setDirty(false);
          toast("Saved. Kiosk sessions take the change on their next turn.");
        };
      const reload = $('[data-testid="settings-reload"]', root);
      if (reload)
        reload.onclick = () => {
          if (state.view === "detail") renderDetail(state.profile);
          else renderList();
          toast("Reloaded from the server.");
        };
    }

    function wireForm() {
      const scroll = $(".settings-scroll", root);
      scroll.addEventListener("input", () => setDirty(true));
      scroll.addEventListener("click", (e) => {
        const sw = e.target.closest('[role="switch"]');
        if (sw) {
          const on = sw.getAttribute("aria-checked") !== "true";
          sw.setAttribute("aria-checked", String(on));
          setDirty(true);
          if (sw.closest('[data-k="web"]')) {
            state.web[state.profile] = on;
            const code = $(".kiosk-link-code", root);
            if (code) code.dataset.off = String(!on);
            toast(on ? "The web link is served again." : "Off: the link answers 404 once you save.");
          }
          return;
        }
        const add = e.target.closest(".settings-array-add");
        if (add) {
          const ul = add.previousElementSibling;
          ul.append(el(arrayRow(add.dataset.label, "")));
          ul.lastElementChild.querySelector("input").focus({ preventScroll: true });
          setDirty(true);
          return;
        }
        const rm = e.target.closest(".settings-array-remove");
        if (rm) {
          rm.closest("li").remove();
          setDirty(true);
          return;
        }
        const tg = e.target.closest(".settings-combobox-toggle, .settings-combobox-input");
        if (tg) {
          const box = tg.closest(".settings-combobox");
          const open = $(".settings-combobox-list", box);
          $$(".settings-combobox-list", root).forEach((l) => l.remove());
          if (open) return;
          const input = $("input", box);
          const opts = JSON.parse(box.dataset.options);
          const listEl = el(`<ul class="settings-combobox-list" role="listbox">${opts
            .map((o) => `<li role="option" class="settings-combobox-option${o === input.value ? " is-current" : ""}" data-v="${esc(o)}">${esc(o)}</li>`)
            .join("")}</ul>`);
          box.append(listEl);
          listEl.addEventListener("mousedown", (ev) => {
            const li = ev.target.closest("li");
            if (!li) return;
            ev.preventDefault();
            input.value = li.dataset.v;
            listEl.remove();
            setDirty(true);
          });
        }
      });
    }

    function wireLinks() {
      $$(".kiosk-copy", root).forEach(
        (b) =>
          (b.onclick = () => {
            const link = `https://help.example.com/kiosk/${state.links[b.dataset.p]}/`;
            navigator.clipboard?.writeText(link).catch(() => {});
            $("span", b).textContent = "Copied";
            setTimeout(() => ($("span", b).textContent = "Copy link"), 1600);
          }),
      );
      $$(".kiosk-qr-btn", root).forEach(
        (b) =>
          (b.onclick = () => {
            state.qrOpen = state.qrOpen === b.dataset.p ? null : b.dataset.p;
            if (state.view === "detail") renderDetail(state.profile, { scrollTo: "publish", publish: true });
            else renderList();
          }),
      );
      $$(".kiosk-newlink", root).forEach(
        (b) =>
          (b.onclick = async () => {
            const p = b.dataset.p;
            const live = state.sessions.filter((s) => s.profile === p && s.surface !== "Telegram").length;
            const ok = await confirmDialog({
              title: "Make a new link?",
              message: `/kiosk/${state.links[p]}/ stops working at once and answers 404${live ? `; its ${live} live session${live > 1 ? "s end" : " ends"}` : ""}. Update the proxy and any printed QR code.`,
              confirm: "New link",
              variant: "danger",
            });
            if (!ok) return;
            state.links[p] = Math.random().toString(36).slice(2, 12).padEnd(10, "x");
            state.sessions = state.sessions.filter((s) => !(s.profile === p && s.surface !== "Telegram"));
            if (state.view === "detail") renderDetail(state.profile, { scrollTo: "publish", publish: state.qrOpen === p });
            else renderList();
            toast(`New link: /kiosk/${state.links[p]}/. The old one answers 404.`);
          }),
      );
    }

    // Watch: the session read-only, over the operator's shell.
    function watch(id) {
      const s = state.sessions.find((x) => x.id === id);
      root.innerHTML = `<div class="shell" style="--rail-shell-track-width: 84px;">${FRAGS.railChat}<div class="shell-main"><div class="backdrop" aria-hidden="true"></div><main class="main"></main></div></div>`;
      displayTranscript($("main", root), {
        title: s.title,
        meta: `${s.profile} · ${s.surface}`,
        notice: "You are watching a kiosk session. Nothing you do here reaches the visitor.",
        action: "Stop watching",
        onAction: renderList,
        script: s.surface === "Display link" ? RELEASE : RECEPTION_LIVE,
      });
      setNotes([
        { at: ".subagent-readonly-notice", text: "Watch reads the session through the turn mirror and never writes", side: "above" },
      ]);
    }

    return {
      stop: () => kiosk?.stop(),
      list: renderList,
      profile: () => renderDetail("reception"),
      publish: () => {
        state.qrOpen = "reception";
        renderDetail("reception", { scrollTo: "publish", publish: true });
      },
      live: renderList,
      try: renderTry,
    };
  }

  // ---------- Stage 5: a display link, and Watch ----------

  const RECEPTION_LIVE = [
    { user: "Which plan includes single sign-on?" },
    { tool: { kind: "read", label: "reading a file", target: "docs/pricing.md", dur: "5ms", result: "# Pricing…" } },
    { answer: SCRIPT[0].blocks },
    { pause: 2500 },
    { user: "And the support hours?" },
    { tool: SCRIPT[2].tools[0] },
    { answer: SCRIPT[2].blocks },
  ];
  const RELEASE = [
    { user: "Draft the release notes for 1.4 from the merged pull requests." },
    { tool: { kind: "execute", label: "running a command", target: "gh pr list --state merged --base main", dur: "1.2s", result: "#672 skills: read marketplaces without installing\n#611 browser: connect Chrome, Firefox and Yandex\n#670 gateway: send an album's items back to back" } },
    { tool: { kind: "read", label: "reading a file", target: "CHANGELOG.md", dur: "4ms", result: "## 1.3…" } },
    {
      answer: [
        { tag: "h3", html: "Coddy 1.4" },
        { list: true, html: "<strong>Browser.</strong> Coddy for Browser connects Chrome, Firefox and Yandex Browser." },
        { list: true, html: "<strong>Skills.</strong> Marketplaces are read without installing; update touches only what is installed." },
        { list: true, html: "<strong>Telegram.</strong> An album's pictures arrive as one message." },
      ],
    },
    { pause: 3000 },
    { user: "Add the upgrade steps." },
    { tool: { kind: "read", label: "reading a file", target: "docs/getting-started/update.md", dur: "3ms", result: "# Updating…" } },
    { answer: [{ tag: "h3", html: "Upgrading" }, { html: "Run <code>coddy update</code>, or upgrade the package your system installed it from." }] },
  ];

  function displayTranscript(main, o) {
    let gen = 0;
    main.innerHTML = `<div class="chat-stack" style="--chat-composer-reserve: 110px;"><div class="chat-scroll" id="messages" aria-live="polite">
      <div class="chat-scroll-sticky-head"><div class="chat-title-column"><header class="chat-header">
        <div class="chat-title"><span class="chat-title-btn">${esc(o.title)}<span class="kiosk-title-sub">${esc(o.meta)}</span></span></div>
        <div class="chat-views" role="toolbar"><span class="display-head-meta"><span class="system-pill display-state" data-state="running"><span class="display-live-dot"></span> live</span></span></div></header></div></div>
      <div class="messages-inner"></div><div class="chat-scroll-tail" aria-hidden="true"></div></div>
      <div class="chat-bottom"><div class="chat-bottom-inner"><div class="subagent-readonly-notice" role="note"><span class="subagent-readonly-copy"><span class="subagent-readonly-text">${esc(o.notice)}</span></span>
      ${o.action ? `<button type="button" class="subagent-readonly-link">${esc(o.action)}</button>` : ""}</div></div></div></div>`;
    if (o.action) $(".subagent-readonly-link", main).onclick = () => {
      gen++;
      o.onAction();
    };
    const listEl = $(".messages-inner", main);
    const scroll = () => {
      const sc = $(".chat-scroll", main);
      sc.scrollTop = sc.scrollHeight;
    };
    async function play() {
      const g = ++gen;
      const alive = () => g === gen && main.isConnected;
      while (alive()) {
        listEl.textContent = "";
        for (const step of o.script) {
          if (!alive()) return;
          if (step.pause) await sleep(step.pause);
          if (step.user) {
            listEl.append(userRow(step.user));
            scroll();
            await sleep(900);
          }
          if (step.tool) {
            const live = liveRow("Working");
            listEl.append(live);
            await sleep(500);
            const row = toolRow({ ...step.tool, status: "in_progress", dur: "" });
            live.before(row);
            scroll();
            await sleep(1100);
            row.replaceWith(toolRow(step.tool));
            live.remove();
          }
          if (step.answer) {
            const a = assistantRow();
            listEl.append(a);
            await stream($(".md", a), step.answer, scroll, alive);
            await sleep(600);
          }
        }
        await sleep(6000);
      }
    }
    play();
    return {
      drop() {
        const pill = $(".display-state", main);
        pill.dataset.state = "stopped";
        pill.lastChild.textContent = " reconnecting…";
        setTimeout(() => {
          pill.dataset.state = "running";
          pill.lastChild.textContent = " live";
        }, 3500);
      },
      restart: play,
    };
  }

  function displayApp(root) {
    root.innerHTML = '<div class="shell kiosk-shell" style="--rail-shell-track-width: 0px;"><div class="shell-main"><div class="backdrop" aria-hidden="true"></div><main class="main"></main></div></div>';
    const d = displayTranscript($("main", root), {
      title: "Release 1.4 notes",
      meta: "release-wall · the session the operator named",
      notice: "View only: this screen follows a session the operator chose. It takes no input, keeps the screen awake and reconnects by itself.",
      script: RELEASE,
    });
    setNotes([
      { at: ".display-state", text: "Live turns through the turn mirror; no idle reset", side: "below", dx: -180 },
      { at: ".subagent-readonly-notice", text: "No composer: the prefix serves no state-changing request", side: "above" },
    ]);
    return d;
  }

  // ---------- Stage 4: a Telegram chat bound to the kiosk ----------

  function telegramApp(root) {
    let gen = 0;
    root.innerHTML = `<div class="tg"><div class="tg-head"><button class="tg-back" aria-label="Back">‹</button><span class="tg-avatar">C</span>
      <div><div class="tg-title">Coddy Reception</div><div class="tg-sub">bot</div></div></div>
      <div class="tg-list" role="log"></div>
      <div class="tg-commands"><button type="button">/model</button><button type="button">/clear</button><button type="button">Install it for me</button></div>
      <div class="tg-input"><input type="text" placeholder="Message" aria-label="Message"><button type="button" class="tg-send" aria-label="Send">${ICONS.plane}</button></div></div>`;
    const listEl = $(".tg-list", root);
    const input = $(".tg-input input", root);
    const t = () => clock();
    const scroll = () => (listEl.scrollTop = listEl.scrollHeight);
    function msg(cls, html) {
      const m = el(`<div class="tg-msg ${cls}"><span class="tg-text">${html}</span><span class="tg-time">${t()}</span></div>`);
      listEl.append(m);
      scroll();
      return m;
    }
    function service(text) {
      listEl.append(el(`<div class="tg-service">${esc(text)}</div>`));
      scroll();
    }
    async function reply(text) {
      const g = gen;
      if (/^\/(model|mode|toolset|agent|permissions|reasoning)\b/i.test(text)) {
        await sleep(400);
        msg("in", "Settings commands are off in this chat: the kiosk sets the model, mode and tools.");
        return;
      }
      if (/^\/clear\b/i.test(text)) {
        gen++;
        await sleep(300);
        service("New session. Nothing of the previous one is kept here.");
        return;
      }
      const plan = SCRIPT.find((s) => s.match.test(text)) || FALLBACK;
      const m = msg("in", `<span class="tg-tool">${esc(plan.tools[0].label)} ${esc(plan.tools[0].target)}…</span>`);
      await sleep(900);
      if (g !== gen) return;
      const failed = plan.tools[0].status === "failed";
      const head = `<span class="tg-tool">${failed ? "✕" : "✓"} ${esc(plan.tools[0].label)} ${esc(plan.tools[0].target)}${failed ? " - not allowed here" : ""}</span>`;
      const plain = plan.blocks.map((b) => (b.list ? "• " : "") + b.html.replace(/<\/?strong>/g, "").replace(/<\/?code>/g, "")).join("\n");
      for (let i = 0; i <= plain.length; i += 6) {
        if (g !== gen) return;
        $(".tg-text", m).innerHTML = head + esc(plain.slice(0, i));
        scroll();
        await sleep(30);
      }
      $(".tg-text", m).innerHTML = head + esc(plain);
    }
    function send(text) {
      if (!text.trim()) return;
      msg("out", esc(text));
      reply(text);
    }
    $(".tg-send", root).onclick = () => {
      send(input.value);
      input.value = "";
    };
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        send(input.value);
        input.value = "";
      }
    });
    $$(".tg-commands button", root).forEach((b) => (b.onclick = () => send(b.textContent)));
    function seed() {
      listEl.textContent = "";
      service("This chat is bound to the kiosk profile \"reception\".");
      msg("out", "/start");
      msg("in", "Hi! I answer questions about our products: plans, prices, setup and support hours.");
      msg("out", "Which plan includes single sign-on?");
      msg("in", `<span class="tg-tool">✓ reading a file docs/pricing.md</span>Business and Enterprise include single sign-on, with SAML and OIDC.\n• Business adds it for 5 euros a user a month.\n• Enterprise includes it, together with SCIM provisioning.`);
    }
    seed();
    setNotes([
      { at: ".tg-head", text: "A bot chat bound to the profile: every sender gets the kiosk, admins too (Decision 10)", side: "below" },
      { at: ".tg-commands", text: "Try them: /model is refused, a denied tool is refused, /clear starts a new session", side: "above" },
    ]);
    return {
      seed,
      idleReset() {
        gen++;
        service("The previous session ended after 5 minutes without a message. This is a new one.");
      },
    };
  }

  // ---------- start ----------

  const root = document.getElementById("root");
  let current = null;
  function start() {
    $$(".confirm-dialog-backdrop, .kiosk-toast, .kiosk-offline, .kiosk-watch, .field-hint-tip").forEach((n) => n.remove());
    root.textContent = "";
    current?.stop?.();
    current = null;
    if (APP === "visitor") {
      const k = kioskApp(root);
      current = k;
      (k[STEP] || k.welcome)();
      return [
        { label: "Skip to idle", run: k.idleNow },
        { label: "Last turn", run: k.lastTurn },
        { label: "Time runs out", run: k.timeUp },
        { label: "Lose connection", run: k.offline },
      ];
    }
    if (APP === "operator") {
      const o = operatorApp(root);
      current = o;
      (o[STEP] || o.list)();
      return [
        { label: "Profile form", run: o.profile },
        { label: "Kiosk list", run: o.list },
        { label: "Try", run: o.try },
      ];
    }
    if (APP === "telegram") {
      const tg = telegramApp(root);
      return [{ label: "Idle reset", run: tg.idleReset }];
    }
    if (APP === "display") {
      const d = displayApp(root);
      return [{ label: "Drop the connection", run: d.drop }];
    }
    return [];
  }
  mockBar(start(), start);
  setTheme(new URLSearchParams(location.search).get("theme") === "light" ? "light" : "dark");
})();
